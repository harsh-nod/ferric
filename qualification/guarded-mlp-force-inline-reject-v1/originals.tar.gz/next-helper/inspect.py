"""Run the qualified canonical reader and join only one fixed provider source."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import sys
import time
import types

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
ROOT = E / 'guarded-mlp-helper-source-join-v228-v2'
CPU = E / 'guarded-mlp-semantic-inspect-cpu-v228-v1'
BACKEND = E / 'guarded-mlp-force-inline-reject-cpu-v228-v1'
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v9'
SOURCE = BACKEND / 'fe2o3/crates/fe2o3-device/src/finite_join/wave_mlp_tiles_v2.rs'
SUPERVISOR = BACKEND / 'supervisor.py'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def coordinate(raw, offset):
    prefix = raw[:offset].decode('utf-8')
    return [prefix.count('\n') + 1, len(prefix.rsplit('\n', 1)[-1]) + 1]


def main(arm):
    require(__debug__ and sys.dont_write_bytecode and arm in ('fixed', 'early')
            and Path(__file__).resolve() == ROOT / 'inspect.py', 'closed invocation')
    require(os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03',
            'MI350 owner')
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    priority = os.getpriority(os.PRIO_PROCESS, 0)
    require(priority in (0, 10), 'nice envelope')
    if priority == 0:
        os.nice(10)
    for kind, cap in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30),
                      (resource.RLIMIT_FSIZE, 1 << 30)):
        soft, hard = resource.getrlimit(kind)
        value = min([cap] + [x for x in (soft, hard) if x != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (value, value))
    body = SUPERVISOR.read_bytes()
    require(hashlib.sha256(body).hexdigest() == '8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc',
            'qualified owned supervisor')
    h = types.ModuleType('owned_inspection_supervisor')
    h.__file__ = str(SUPERVISOR)
    exec(compile(body, str(SUPERVISOR), 'exec'), h.__dict__)
    out = ROOT / (arm + '-run')
    require(not os.path.lexists(out), 'fresh diagnostic output')
    out.mkdir(mode=0o700)
    h.ROOT, h.OUT, h.TARGET, h.TMP = ROOT, out / 'evidence', out / 'target', out / 'tmp'
    h.OUT.mkdir(); h.TMP.mkdir()
    h.CPU_LIMIT = 120
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'owned subreaper')
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)
    cpu_pin = h.pin(CPU / 'evidence/complete.json')
    require(cpu_pin['sha256'] == '5999eb6b23579e9be205b7627cc97f98eb58b471c552ff355239285c84a13877',
            'qualified canonical reader receipt')
    cpu = json.loads((CPU / 'evidence/complete.json').read_bytes())
    reader = cpu['artifacts']['reader']['pin']
    require(h.pin(Path(reader['path'])) == reader, 'exact qualified reader executable')
    backend_pin = h.pin(BACKEND / 'evidence/complete.json')
    require(backend_pin['sha256'] == 'c9bc292d82f5018e04692e7ed7b866f7ac578d35863f210313bc6e5efd176294',
            'qualified changed provider')
    evidence = PAIR / (arm + '-run/evidence')
    terminal = json.loads((evidence / 'result.json').read_bytes())
    phase = terminal['phases'][0]
    require(terminal['compile_accepted'] is False and terminal['postcheck_errors'] == []
            and len(terminal['phases']) == 1 and phase['exit_code'] == 1 and phase['natural_exit']
            and phase['reaped'] and phase['process_group_absent'] and not phase['timed_out']
            and not phase['forced_cleanup'] and phase['exception'] is None
            and phase['storage_failure'] is None, 'actual clean failed compile')
    stderr = (evidence / 'compile.stderr').read_text()
    require(h.pin(evidence / 'compile.stderr') == phase['stderr'], 'original diagnostic identity')
    identities = re.findall(r'helper_identity=([0-9a-f]{64}); adjusted_argument=', stderr)
    require(len(identities) == 1, 'one actual full helper identity')
    captures = terminal['diagnostic_files']
    mir, mapping = (captures[name] for name in ('semantic-mir-v1.bin', 'semantic-source-map-v1.json'))
    for row in (mir, mapping):
        require(h.pin(Path(row['path'])) == row, 'original canonical capture')
    source_pin = h.pin(SOURCE)
    require(source_pin['sha256'] == 'd1e318f0a504acc3b35d11bf70083b871411cbe7975f48308419a29df5287ad6',
            'fixed reviewed source only')
    for name in ('sources-before.json', 'sources-after.json'):
        require(json.loads((evidence / name).read_bytes())[str(SOURCE)] == source_pin,
                'actual compile source provenance')
    paths = [ROOT / 'inspect.py', SUPERVISOR, SOURCE, Path(reader['path']),
             CPU / 'evidence/complete.json', BACKEND / 'evidence/complete.json',
             Path(mir['path']), Path(mapping['path'])]
    paths += [evidence / name for name in ('result.json', 'compile.stderr', 'sources-before.json', 'sources-after.json')]
    h.sources = lambda: {str(path): h.pin(path) for path in paths}
    before = h.sources()
    h.save('sources-before.json', before)
    env = dict(PATH='/usr/bin:/bin', HOME=str(out), TMPDIR=str(h.TMP),
               HIP_VISIBLE_DEVICES='', ROCR_VISIBLE_DEVICES='', CUDA_VISIBLE_DEVICES='')
    argv = [reader['path'], mir['path'], mapping['path'], mir['sha256'], mapping['sha256'], identities[0]]
    phases, error, origins, decoded = [], None, {}, None
    deadline = time.monotonic() + 180
    signal.setitimer(signal.ITIMER_REAL, 130)
    try:
        h.run('inspect', argv, env, phases, deadline, before, 60, ROOT)
        decoded = json.loads((h.OUT / 'inspect.stdout').read_bytes())
        require(decoded['canonical_decode_verified'] and not decoded['execution_authority']
                and not decoded['production_admission'] and decoded['helper']['identity'] == identities[0],
                'canonical diagnostic interpretation only')
        raw = SOURCE.read_bytes()
        for key in ('call_site', 'expansion'):
            origin = decoded['helper'][key]
            require(origin['display_path'] == str(SOURCE) and origin['file_bytes'] == len(raw)
                    and not origin['source_file_contents_verified'], 'fixed source label and extent')
            start, end = origin['byte_range']
            require(0 <= start < end <= len(raw) and coordinate(raw, start) == origin['start']
                    and coordinate(raw, end) == origin['end'], 'exact source byte/coordinate join')
            origins[key] = dict(origin, span_utf8=raw[start:end].decode('utf-8'),
                                source_file_contents_verified=True, verified_source=source_pin)
    except BaseException as failure:
        error = repr(failure)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    after = h.sources()
    h.save('sources-after.json', after)
    require(before == after, 'inspection source/tool mutation')
    result = dict(schema='ferric-canonical-helper-source-join-v2', passed=error is None,
                  error=error, arm=arm, reader_receipt=cpu_pin, backend_receipt=backend_pin,
                  compile_result=before[str(evidence / 'result.json')], phases=phases,
                  inspection=h.pin(h.OUT / 'inspect.stdout') if phases else None,
                  helper=decoded['helper'] if decoded else None, origins=origins,
                  source_contents_join_verified=error is None, gpu_execution=False,
                  numerical_acceptance=False, performance_claim=False, production_authority=False)
    h.save('result.json', result)
    print(json.dumps(dict(passed=error is None, error=error, result=h.pin(h.OUT / 'result.json'),
                          helper=identities[0], origins=origins)), flush=True)
    return 0 if error is None else 1


if __name__ == '__main__':
    require(len(sys.argv) == 2, 'one arm')
    raise SystemExit(main(sys.argv[1]))
