"""Review the exact provider delta and compute its closed, length-framed identity."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
E = ROOT.parent
BASE = E/"guarded-mlp-semantic-capture-backend-cpu-v228-v1/fe2o3/crates/fe2o3-device"
CURRENT = ROOT/"fe2o3/crates/fe2o3-device"
DOMAIN = b"FE2O3/WORKGROUP-SYNC-PROVIDER-SOURCE-CLOSURE/V1\0"
OLD = "037e472ea24d7337f88028ed65cb3d6ea6e0c0681538e6121ab78240c44ef675"
MODULE = "src/finite_join/wave_mlp_tiles_v2.rs"
TESTS = "src/finite_join/wave_mlp_tiles_v2_tests.rs"

def pin(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    before = path.lstat()
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    assert before.st_size <= 16 << 20
    raw = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) == (
        after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
    return raw

def closure(root):
    paths = [root/"Cargo.toml"]
    if (root/"build.rs").exists(): paths.append(root/"build.rs")
    for path in (root/"src").rglob("*"):
        assert not path.is_symlink()
        if path.is_file(): paths.append(path)
        else: assert path.is_dir()
    bodies = {p.relative_to(root).as_posix():read(p) for p in paths}
    digest = hashlib.sha256(DOMAIN)
    for name, body in sorted(bodies.items()):
        for field in (name.encode(),body):
            digest.update(len(field).to_bytes(8,"little")); digest.update(field)
    return digest.hexdigest(),bodies

def main():
    assert __debug__ and os.getuid() == os.geteuid() == 9661 and os.uname().nodename == "smci350-rck-g03-b19-03"
    assert ROOT.name == "guarded-mlp-force-inline-reject-cpu-v228-v1"
    assert not (ROOT/"source-review.json").exists()
    old_id,old = closure(BASE)
    new_id,new = closure(CURRENT)
    assert old_id == OLD and set(old) == set(new)
    changed = {name for name in old if old[name] != new[name]}
    assert changed == {MODULE,TESTS}
    anchor = b"impl MlpNormTileV2<'_, '_> {\n    pub fn lane(&self) -> usize {\n        self.lane\n    }\n"
    assert old[MODULE].count(anchor) == 1
    assert old[MODULE].replace(anchor,anchor+b'    #[cfg_attr(target_arch = "amdgpu", rustc_force_inline)]\n') == new[MODULE]
    marker = b"#[test]\nfn norm_reject_preserves_payload_and_uses_ordinary_error_retirement()"
    end = b"#[test]\nfn fixed_layout_and_terminal_census_are_distinct_from_v1()"
    assert new[TESTS].count(marker) == new[TESTS].count(end) == 1
    start = new[TESTS].index(marker); finish = new[TESTS].index(end)
    assert new[TESTS][:start]+new[TESTS][finish:] == old[TESTS]
    join_path = E/"guarded-mlp-helper-source-join-v228-v1/source-join.json"
    join_raw = read(join_path)
    assert pin(join_raw)["sha256"] == "029038b3a12d3cc0dc72d2f9479c4668c5ccf9b4423a4520fe46077d96354899"
    joined = json.loads(join_raw)
    assert joined["passed"] and joined["source_contents_join_verified"]
    assert pin(old[MODULE]) == {key:joined["source"][key] for key in ("bytes","sha256")}
    result = dict(schema="ferric-mlp-force-inline-reject-source-review-v1",
        base_source_closure=old_id,candidate_source_closure=new_id,
        source_join=dict(path=str(join_path),**pin(join_raw)),
        original_files={name:pin(body) for name,body in old.items()},
        candidate_files={name:pin(body) for name,body in new.items()},
        changed_files=sorted(changed),annotation_only_production_delta=True,
        reject_body_and_signature_unchanged=True,new_host_test_definitions=1,
        cpu_tests_executed=False,gpu_compilation=False,gpu_execution=False,
        compiler_acceptance=False,production_authority=False)
    assert closure(BASE)[0] == old_id and closure(CURRENT)[0] == new_id
    with (ROOT/"source-review.json").open("x") as f:
        json.dump(result,f,indent=2,sort_keys=True);f.write("\n")
    print(json.dumps(dict(old=old_id,new=new_id,files=len(new),receipt=pin(read(ROOT/"source-review.json")))),flush=True)

if __name__ == "__main__":
    main()
