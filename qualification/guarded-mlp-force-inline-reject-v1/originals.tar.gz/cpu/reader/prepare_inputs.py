"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-semantic-capture-backend-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-semantic-inspect-cpu-v228-v1'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == '699c8e48b8ce20f1a1f4f52a5f2f9e3e7329bc4ae23857a63398f0bb81c25337'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / 'run_cpu.py', ROOT / 'supervisor.py']
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5811
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
E = ROOT.parent
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v8'
CAPTURE_FILES = {
    'captures/fixed/result.json': (PAIR / 'fixed-run/evidence/result.json', '91192072e44394fc8e808936572bdc5b3b37092aae37632365436f99caade77d'),
    'captures/fixed/compile.stderr': (PAIR / 'fixed-run/evidence/compile.stderr', 'ff1e3d1ad6117129e3acad5c2f7e6b32c52ea7af01df2da719d40f8559a2d2d7'),
    'captures/fixed/semantic-mir-v1.bin': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '72dfdc23aabf0eaac4f2809371131a853874f51609bf1e380476ce95eb0a1667'),
    'captures/fixed/semantic-source-map-v1.json': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '1c33e74ee9d15837276a82b687d40aa065957cc645df49b746f0c4cc379ef5a5'),
    'captures/early/result.json': (PAIR / 'early-run/evidence/result.json', '5206dc0347e1093ea04a983a73bb763bbf70def98ed9fd8e31fb75dbee693ceb'),
    'captures/early/compile.stderr': (PAIR / 'early-run/evidence/compile.stderr', '3942d375c48f1f8c05a1f321283b5058c01144c54b91a5b0ae776f48a00c7580'),
    'captures/early/semantic-mir-v1.bin': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'e29daedb54bb4428533a48a9342e1a1964ab3756b95fd875537fcb5803597f69'),
    'captures/early/semantic-source-map-v1.json': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '57d9ee61bc355f3debfb3c4828b87bfef487c04325b2af95db11e989f38fbc6e'),
}
HELPER = '00b15eaa5a80fc7f25e19c1c333fcde91f768f51097ae1c2c4f27ced27c66af0'

for name, (path, digest) in CAPTURE_FILES.items():
    assert path.resolve(strict=True) == path and not path.is_symlink()
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    files[name] = dict(bytes=len(raw), sha256=digest)
assert len(files) == 5819
value = dict(schema='ferric-guarded-mlp-semantic-inspect-cpu-input-v1',
             base_complete_sha256=hashlib.sha256(body).hexdigest(),
             files=files, tool_pins=receipt['tool_pins'])
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
