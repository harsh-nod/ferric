"""Canonical semantic inspection qualification; no GPU or production authority."""

import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import sys
import time
import types


ROOT = Path(__file__).resolve().parent
E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
EXPECTED_ROOT = E / 'guarded-mlp-semantic-inspect-cpu-v228-v1'
SOURCE = ROOT / 'fe2o3'
OUT, TARGET, TMP = (ROOT / name for name in ('evidence', 'target', 'tmp'))
BASE_CPU = E / 'guarded-mlp-semantic-capture-backend-cpu-v228-v1'
BASE_COMPLETE_SHA = '699c8e48b8ce20f1a1f4f52a5f2f9e3e7329bc4ae23857a63398f0bb81c25337'
BASE_SOURCES_SHA = 'dafa7feab3abe50763aa65509be51fb44db37f5844ff97574d34920428555d7c'
READER_SOURCE = 'fe2o3/crates/fe2o3-mir-model/src/bin/fe2o3-semantic-capture-inspect.rs'
READER_NAME = 'fe2o3-semantic-capture-inspect'
SUPERVISOR_SHA = '8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc'
WHOLE_WALL, LEAF_WALL, CLEANUP_RESERVE = 3600, 1800, 50
PHASES = ('rustc-version', 'metadata', 'reader-tests-build', 'reader-list',
          'reader-ignored', 'reader-tests', 'reader-build', 'inspect-fixed', 'inspect-early')
TESTS = tuple('tests::' + name for name in (
    'exact_canonical_roundtrip_reports_one_helper_without_authority',
    'truncated_trailing_and_noncanonical_mir_are_rejected',
    'digest_extent_identity_and_schema_mismatches_are_rejected',
    'map_files_are_bounded_sorted_unique_and_strict',
    'oversized_inputs_are_rejected_before_decode',
    'source_origin_requires_full_identity_and_bounded_extent',
    'relative_file_and_argument_count_are_refused',
))
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v8'
CAPTURE_FILES = {
    'captures/fixed/result.json': (PAIR / 'fixed-run/evidence/result.json', '91192072e44394fc8e808936572bdc5b3b37092aae37632365436f99caade77d'),
    'captures/fixed/compile.stderr': (PAIR / 'fixed-run/evidence/compile.stderr', 'ff1e3d1ad6117129e3acad5c2f7e6b32c52ea7af01df2da719d40f8559a2d2d7'),
    'captures/fixed/semantic-mir-v1.bin': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '72dfdc23aabf0eaac4f2809371131a853874f51609bf1e380476ce95eb0a1667'),
    'captures/fixed/semantic-source-map-v1.json': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '1c33e74ee9d15837276a82b687d40aa065957cc645df49b746f0c4cc379ef5a5'),
    'captures/early/result.json': (PAIR / 'early-run/evidence/result.json', '5206dc0347e1093ea04a983a73bb763bbf70def98ed9fd8e31fb75dbee693ceb'),
    'captures/early/compile.stderr': (PAIR / 'early-run/evidence/compile.stderr', '3942d375c48f1f8c05a1f321283b5058c01144c54b91a5b0ae776f48a00c7580'),
    'captures/early/semantic-mir-v1.bin': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'e29daedb54bb4428533a48a9342e1a1964ab3756b95fd875537fcb5803597f69'),
    'captures/early/semantic-source-map-v1.json': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '57d9ee61bc355f3debfb3c4828b87bfef487c04325b2af95db11e989f38fbc6e'),
}
HELPER = '00b15eaa5a80fc7f25e19c1c333fcde91f768f51097ae1c2c4f27ced27c66af0'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load_exact(name, path, digest):
    require(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink(),
            'helper must be canonical ordinary source')
    before = path.stat()
    require(before.st_size <= 1 << 20, 'helper size bound')
    body = path.read_bytes()
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
            and hashlib.sha256(body).hexdigest() == digest, 'helper source pin mismatch')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(body, str(path), 'exec'), module.__dict__)
    return module


def compact(rows):
    return {name: {key: row[key] for key in ('bytes', 'sha256')} for name, row in rows.items()}


def selected_reader(h, path, testing):
    rows = h.build_records(path)
    artifact = h.select_artifact(rows, 'fe2o3-mir-model', READER_NAME, 'bin', testing)
    row = artifact['cargo_artifact']
    require(row['target']['kind'] == ['bin'] and row['target']['crate_types'] == ['bin']
            and row['target']['src_path'] == str(ROOT / READER_SOURCE)
            and row['filenames'].count(artifact['pin']['path']) == 1,
            'closed reader Cargo target/filename required')
    if not testing:
        require(artifact['pin']['path'] == str(TARGET / 'debug' / READER_NAME), 'final reader path')
    return artifact


def main():
    started = time.monotonic()
    deadline = started + WHOLE_WALL
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 2
            and re.fullmatch(r'[0-9a-f]{64}', sys.argv[1]), 'python3 -B run_cpu.py INPUT_SHA')
    require(ROOT == EXPECTED_ROOT and ROOT.resolve(strict=True) == ROOT
            and not any(os.path.lexists(p) for p in (OUT, TARGET, TMP)), 'fresh exact outputs required')
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == 'smci350-rck-g03-b19-03', 'host/UID mismatch')
    require(shutil.disk_usage(ROOT).free >= 40 << 30, '40 GiB setup floor')
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    priority = os.getpriority(os.PRIO_PROCESS, 0)
    require(priority in (0, 10), 'unexpected nice level')
    if priority == 0:
        os.nice(10)
    for kind, cap in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30),
                      (resource.RLIMIT_FSIZE, 1 << 30)):
        soft, hard = resource.getrlimit(kind)
        value = min([cap] + [x for x in (soft, hard) if x != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (value, value))
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'subreaper setup')
    h = load_exact('backend_owned_supervisor', ROOT / 'supervisor.py', SUPERVISOR_SHA)
    h.ROOT, h.SOURCE, h.OUT, h.TARGET, h.TMP = ROOT, SOURCE, OUT, TARGET, TMP
    h.ROLES = {'reader': ('fe2o3-mir-model', READER_NAME, 'bin')}
    original_sources = h.sources
    def sources():
        return dict(original_sources(), **{'supervisor.py': h.pin(ROOT / 'supervisor.py')},
                    **{name: h.pin(path) for name, (path, _) in CAPTURE_FILES.items()})
    h.sources = sources
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - CLEANUP_RESERVE - time.monotonic()))
    OUT.mkdir(mode=0o700)
    TMP.mkdir(mode=0o700)
    before = final = input_pin = base_complete_pin = base_source_pin = base_dependencies_pin = config = None
    tool_pins, external, external_after, local, artifacts, tests = {}, {}, {}, {}, {}, {}
    inventory, ignored, phases, errors, failure = [], [], [], [], None
    inspections = {}
    source_delta = {}
    try:
        input_pin = h.pin(ROOT / 'input-manifest.json')
        require(input_pin['sha256'] == sys.argv[1], 'literal input mismatch')
        inputs = json.loads((ROOT / 'input-manifest.json').read_bytes())
        require(set(inputs) == {'schema', 'base_complete_sha256', 'files', 'tool_pins'}
                and inputs['schema'] == 'ferric-guarded-mlp-semantic-inspect-cpu-input-v1'
                and inputs['base_complete_sha256'] == BASE_COMPLETE_SHA, 'input lineage/fields')
        before = sources()
        require(len(before) == 5819 and inputs['files'] == compact(before), 'closed exact source map')
        h.save('sources-before.json', before)
        require(all(before[name]['sha256'] == digest for name, (_, digest) in CAPTURE_FILES.items()),
                'original V8 capture/terminal/stream pins')
        base_complete_pin = h.pin(BASE_CPU / 'evidence/complete.json')
        base_source_pin = h.pin(BASE_CPU / 'evidence/sources-after.json')
        require(base_complete_pin['sha256'] == BASE_COMPLETE_SHA
                and base_source_pin['sha256'] == BASE_SOURCES_SHA, 'actual base CPU/source pins')
        base = json.loads((BASE_CPU / 'evidence/complete.json').read_bytes())
        base_sources = json.loads((BASE_CPU / 'evidence/sources-after.json').read_bytes())
        require(base['passed'] is True and base['failure'] is None and base['postcheck_errors'] == []
                and base['source_unchanged'] is True
                and base['raw']['sources-after.json'] == base_source_pin,
                'actual source-generation receipt join')
        expected = {name: row for name, row in base_sources.items() if name.startswith('fe2o3/')}
        actual = {name: row for name, row in before.items() if name.startswith('fe2o3/')}
        require(len(expected) == 5808 and set(actual) == set(expected) | {READER_SOURCE},
                'fresh workspace roster differs from qualified backend')
        require(all(compact(actual)[name] == compact(expected)[name] for name in expected),
                'qualified backend sources must be byte unchanged')
        source_delta = {READER_SOURCE: dict(before=None, after=compact(actual)[READER_SOURCE])}
        base_dependencies_pin = h.pin(BASE_CPU / 'evidence/dependencies-after.json')
        require(base['raw']['dependencies-after.json'] == base_dependencies_pin,
                'actual base dependency receipt join')
        base_dependencies = json.loads((BASE_CPU / 'evidence/dependencies-after.json').read_bytes())
        config = h.configurations()
        tool_pins = {name: h.pin(h.TOOLCHAIN / name) for name in ('rustc', 'rustdoc', 'rustfmt', 'cargo')}
        tool_pins['prlimit'] = h.pin(Path('/usr/bin/prlimit'))
        for name, size in h.SHARED_LIBRARIES.items():
            path = h.TOOLCHAIN_LIB / name
            require(path.resolve(strict=True) == path, 'tool library alias')
            tool_pins[name] = h.pin(path)
            require(tool_pins[name]['bytes'] == size, 'tool library extent')
        require(tool_pins == inputs['tool_pins'] == base['tool_pins'], 'exact qualified tool pins')
        env = dict(HOME='/home/harmenon', PATH=str(h.TOOLCHAIN) + ':/usr/bin:/bin',
                   CARGO_HOME='/home/harmenon/.cargo', CARGO_TARGET_DIR=str(TARGET),
                   LD_LIBRARY_PATH=str(TARGET / 'debug/deps') + ':' + str(h.TOOLCHAIN_LIB),
                   TMPDIR=str(TMP), RUSTC=str(h.TOOLCHAIN / 'rustc'), RUSTDOC=str(h.TOOLCHAIN / 'rustdoc'),
                   CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
                   CARGO_CACHE_AUTO_CLEAN_FREQUENCY='never', MALLOC_ARENA_MAX='2', RUST_BACKTRACE='1',
                   CARGO_PROFILE_DEV_OPT_LEVEL='0', CARGO_PROFILE_DEV_DEBUG='0',
                   CARGO_PROFILE_DEV_DEBUG_ASSERTIONS='true', CARGO_PROFILE_DEV_OVERFLOW_CHECKS='true',
                   CARGO_PROFILE_TEST_OPT_LEVEL='0', CARGO_PROFILE_TEST_DEBUG='0',
                   CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
                   ROCR_VISIBLE_DEVICES='', HIP_VISIBLE_DEVICES='', CUDA_VISIBLE_DEVICES='')
        def leaf(label, argv, seconds=LEAF_WALL, package=False):
            cwd = SOURCE / 'crates/fe2o3-mir-model' if package else ROOT
            selected_env = dict(env)
            if package:
                selected_env['CARGO_MANIFEST_DIR'] = str(cwd)
            h.run(label, argv, selected_env, phases, deadline, before, seconds, cwd)
        cargo = str(h.TOOLCHAIN / 'cargo')
        common = ['--offline', '--locked', '--manifest-path', str(SOURCE / 'Cargo.toml')]
        leaf('rustc-version', [str(h.TOOLCHAIN / 'rustc'), '--version', '--verbose'], 60)
        leaf('metadata', [cargo, 'metadata', *common, '--format-version', '1'], 120)
        external, local = h.metadata_contract()
        require(external == base_dependencies, 'dependency bodies differ from qualified backend')
        h.save('dependencies-before.json', external)
        leaf('reader-tests-build', [cargo, 'test', *common, '--jobs', '2', '-p', 'fe2o3-mir-model',
                                   '--bin', READER_NAME, '--no-run', '--message-format=json'])
        artifacts['test'] = selected_reader(h, OUT / 'reader-tests-build.stdout', True)
        executable = artifacts['test']['pin']['path']
        leaf('reader-list', [executable, '--list', '--format=terse'], 120, True)
        leaf('reader-ignored', [executable, '--ignored', '--list', '--format=terse'], 120, True)
        inventory = h.inventory(OUT / 'reader-list.stdout')
        ignored = h.inventory(OUT / 'reader-ignored.stdout')
        require(inventory == sorted(TESTS) and ignored == [], 'exact seven nonignored reader tests')
        leaf('reader-tests', [executable, '--test-threads=1'], package=True)
        tests['reader'] = h.outcomes(OUT / 'reader-tests.stdout', TESTS, len(inventory))
        leaf('reader-build', [cargo, 'build', *common, '--jobs', '2', '-p', 'fe2o3-mir-model',
                             '--bin', READER_NAME, '--message-format=json'])
        artifacts['reader'] = selected_reader(h, OUT / 'reader-build.stdout', False)
        for arm in ('fixed', 'early'):
            prefix = 'captures/' + arm + '/'
            semantic_path, semantic_hash = CAPTURE_FILES[prefix + 'semantic-mir-v1.bin']
            map_path, map_hash = CAPTURE_FILES[prefix + 'semantic-source-map-v1.json']
            result = json.loads(CAPTURE_FILES[prefix + 'result.json'][0].read_bytes())
            stderr = CAPTURE_FILES[prefix + 'compile.stderr'][0].read_text()
            require(result['compile_accepted'] is False and result['postcheck_errors'] == []
                    and len(result['phases']) == 1
                    and result['phases'][0]['exit_code'] == 1
                    and result['phases'][0]['natural_exit'] is True
                    and result['phases'][0]['reaped'] is True
                    and result['phases'][0]['process_group_absent'] is True
                    and stderr.count('helper_identity=' + HELPER + '; adjusted_argument=0;') == 1,
                    'original helper refusal and terminal result required')
            leaf('inspect-' + arm, [artifacts['reader']['pin']['path'], str(semantic_path), str(map_path),
                                    semantic_hash, map_hash, HELPER], 120)
            value = json.loads((OUT / ('inspect-' + arm + '.stdout')).read_bytes())
            require(value['schema'] == 'fe2o3-semantic-capture-inspection-v1'
                    and value['canonical_decode_verified'] is True
                    and value['execution_authority'] is False and value['production_admission'] is False
                    and value['semantic_file_sha256'] == semantic_hash
                    and value['source_map_file_sha256'] == map_hash
                    and value['helper']['identity'] == HELPER, 'exact capture inspection output')
            argument = value['helper']['arguments'][0]
            require(argument['adjusted_argument'] == argument['source_argument'] == argument['local'] == 0
                    and argument['ownership'] == 'UniqueBorrow' and argument['abi_mode'] == 'Direct'
                    and argument['type']['type'] == 19 and argument['type']['shape'] == 'Pointer'
                    and argument['type']['pointer']['kind'] == 'Reference'
                    and argument['type']['pointer']['mutability'] == 'Mutable'
                    and argument['type']['pointer']['pointee']['type'] == 30
                    and argument['type']['pointer']['pointee']['shape'] == 'Aggregate'
                    and argument['type']['pointer']['pointee']['rust_type_kind'] == 'Ordinary',
                    'typed helper contract must agree with actual compiler refusal')
            inspections[arm] = value
        require([row['label'] for row in phases] == list(PHASES), 'closed nine phases')
    except BaseException as error:
        failure = repr(error)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    def check(label, action):
        try:
            remaining = deadline - 5 - time.monotonic()
            require(remaining > 0, 'postcheck deadline')
            signal.setitimer(signal.ITIMER_REAL, remaining)
            action()
        except BaseException as error:
            errors.append(label + ': ' + repr(error))
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
    def source_check():
        nonlocal final
        final = sources()
        h.save('sources-after.json', final)
        require(final == before, 'source/lock mutation')
    check('sources', source_check)
    if input_pin is not None:
        check('input', lambda: require(h.pin(ROOT / 'input-manifest.json') == input_pin, 'input drift'))
    if config is not None:
        check('configuration', lambda: require(h.configurations() == config, 'configuration drift'))
    for label, expected in tool_pins.items():
        check('tool ' + label, lambda expected=expected: require(h.pin(Path(expected['path'])) == expected, 'tool drift'))
    for label, expected in [('base complete', base_complete_pin), ('base sources', base_source_pin),
                            ('base dependencies', base_dependencies_pin)]:
        if expected is not None:
            check(label, lambda expected=expected: require(h.pin(Path(expected['path'])) == expected, 'base drift'))
    for directory, expected in external.items():
        def dependency_check(directory=directory, expected=expected):
            path = Path(directory)
            actual = {str(p.relative_to(path)): h.pin(p) for p in h.files_below(path, packed=False)}
            external_after[directory] = actual
            require(actual == expected, 'external dependency drift')
        check('dependency ' + directory, dependency_check)
    check('dependency ledger', lambda: h.save('dependencies-after.json', external_after))
    for label, artifact in artifacts.items():
        check('artifact ' + label, lambda artifact=artifact: require(
            h.pin(Path(artifact['pin']['path'])) == artifact['pin'], 'selected artifact drift'))
    raw = {}
    def raw_check():
        nonlocal raw
        raw = {p.name: h.pin(p) for p in sorted(OUT.iterdir()) if p.is_file()}
        for row in phases:
            for key in ('command', 'stdout', 'stderr'):
                require(raw[Path(row[key]['path']).name] == row[key], 'raw phase join')
    check('raw evidence', raw_check)
    failure = failure or ('postcheck failed' if errors else None)
    if time.monotonic() >= deadline:
        failure = failure or 'whole deadline exceeded'
    result = dict(schema='ferric-guarded-mlp-semantic-inspect-cpu-v1', passed=failure is None,
                  failure=failure, postcheck_errors=errors,
                  source_delta=source_delta, diagnostic_only=True, inspections=inspections,
                  admission_changed=False, semantic_predicates_changed=False,
                  controller=h.pin(ROOT / 'run_cpu.py'), supervisor=h.pin(ROOT / 'supervisor.py'),
                  input_manifest=input_pin,
                  base_cpu_complete=base_complete_pin, base_cpu_sources=base_source_pin,
                  base_cpu_dependencies=base_dependencies_pin,
                  input_sources=before, final_sources=final, source_unchanged=before is not None and final == before,
                  phases=phases, artifacts=artifacts, tests=tests, inventory=inventory, ignored=ignored,
                  reader_tests=sorted(TESTS),
                  full_compiler_tests_executed=False, tool_pins=tool_pins, raw=raw,
                  local_dependencies=local, configurations=config, elapsed_seconds=time.monotonic() - started,
                  final_artifact_phase='reader-build', test_artifact_phase='reader-tests-build',
                  limits=dict(whole_seconds=WHOLE_WALL, leaf_seconds=LEAF_WALL,
                              cleanup_reserve_seconds=CLEANUP_RESERVE, cpu_seconds=h.CPU_LIMIT,
                              address_space_bytes=h.AS_LIMIT, file_bytes=h.FILE_LIMIT,
                              cache_bytes=h.CACHE_LIMIT, stream_bytes=h.STREAM_LIMIT,
                              initial_free_bytes=h.START_FREE, live_free_bytes=h.LIVE_FREE,
                              affinity=[8, 9], nice=10, cargo_jobs=2),
                  gpu_execution=False, compiler_hsaco_reproduced=False, production_authority=False)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - time.monotonic()))
    try:
        h.save('complete.json' if failure is None else 'failed.json', result)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    print(json.dumps(dict(passed=failure is None, failure=failure, phases=len(phases),
                          tests={k: {n: v[n] for n in ('passed', 'failed', 'ignored')}
                                 for k, v in tests.items()}, output=str(OUT)), sort_keys=True))
    return 0 if failure is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
