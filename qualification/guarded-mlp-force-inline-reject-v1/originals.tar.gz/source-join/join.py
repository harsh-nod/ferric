"""Join decoded helper spans to a fixed, previously pinned provider source."""
import hashlib
import json
import os
from pathlib import Path

E = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220")
ROOT = E / "guarded-mlp-helper-source-join-v228-v1"
CPU = E / "guarded-mlp-semantic-inspect-cpu-v228-v1"
PAIR = E / "guarded-mlp-early-stop-compile-v228-v8"
SOURCE = E / "guarded-mlp-segment-cpu-v228-v5/fe2o3/crates/fe2o3-device/src/finite_join/wave_mlp_tiles_v2.rs"
SOURCE_SHA = "f292dd381b827946b037a39b05548ed2a8819420686f2069b5432845530992b6"
RECEIPT_SHA = "5999eb6b23579e9be205b7627cc97f98eb58b471c552ff355239285c84a13877"
HELPER = "00b15eaa5a80fc7f25e19c1c333fcde91f768f51097ae1c2c4f27ced27c66af0"
FILE_ID = "94c691d176560fd17cff9bdbe7fb39385dd93fa4f0b157150ef07889f4807aec"
OUTPUT_SHA = {"fixed":"6cee4c001726159016674c151e8addc8f04af57eea3b6c6597610ee89dd453b1",
              "early":"6262d7134910fe921d8c96623ffc2194cf67f7d1c8d637d895b41b453e8a04f4"}

def read(path, digest=None):
    before = path.lstat()
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    assert before.st_size <= 16 << 20
    raw = path.read_bytes()
    stamp = lambda s: (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert stamp(before) == stamp(path.lstat())
    actual = hashlib.sha256(raw).hexdigest()
    assert digest is None or actual == digest
    return raw, dict(path=str(path),bytes=len(raw),sha256=actual)

def coordinate(raw, offset):
    prefix = raw[:offset].decode("utf-8")
    return [prefix.count("\n")+1, len(prefix.rsplit("\n",1)[-1])+1]

def main():
    assert __debug__ and ROOT == Path(__file__).resolve().parent
    assert os.getuid() == os.geteuid() == 9661 and os.uname().nodename == "smci350-rck-g03-b19-03"
    assert not (ROOT/"source-join.json").exists()
    os.umask(0o077)
    raw, source_pin = read(SOURCE, SOURCE_SHA)
    body, receipt_pin = read(CPU/"evidence/complete.json", RECEIPT_SHA)
    cpu = json.loads(body)
    assert cpu["passed"] and cpu["failure"] is None and cpu["postcheck_errors"] == []
    assert cpu["source_unchanged"] and cpu["tests"]["reader"]["passed"] == 7 and len(cpu["phases"]) == 9
    for phase in cpu["phases"]:
        assert phase["exit_code"] == 0 and phase["natural_exit"] and phase["reaped"] and phase["process_group_absent"]
        assert not phase["timed_out"] and not phase["forced_cleanup"] and phase["exception"] is None
    arms = {}
    for arm in ("fixed","early"):
        body, output_pin = read(CPU/"evidence"/("inspect-"+arm+".stdout"), OUTPUT_SHA[arm])
        assert cpu["raw"]["inspect-"+arm+".stdout"] == output_pin
        result = json.loads(body)
        assert result["canonical_decode_verified"] and not result["execution_authority"] and not result["production_admission"]
        helper = result["helper"]
        assert helper["identity"] == HELPER and helper["function_index"] == 0
        old = json.loads(read(PAIR/(arm+"-run/evidence/result.json"))[0])
        before_pin = json.loads(read(PAIR/(arm+"-run/evidence/sources-before.json"))[0])[str(SOURCE)]
        after_pin = json.loads(read(PAIR/(arm+"-run/evidence/sources-after.json"))[0])[str(SOURCE)]
        assert before_pin == after_pin == source_pin
        assert old["diagnostic_files"]["semantic-mir-v1.bin"]["sha256"] == result["semantic_file_sha256"]
        origins = {}
        for key in ("call_site","expansion"):
            origin = helper[key]
            assert origin["file_identity"] == FILE_ID and origin["display_path"] == str(SOURCE)
            assert origin["file_bytes"] == len(raw) == 35976 and not origin["source_file_contents_verified"]
            start, end = origin["byte_range"]
            assert [start,end] == [29396,29457]
            assert coordinate(raw,start) == origin["start"] == [828,5]
            assert coordinate(raw,end) == origin["end"] == [830,6]
            span = raw[start:end]
            assert span == b"pub fn reject(&mut self) {\n        *self.valid = false;\n    }"
            origins[key] = dict(origin, verified_source=source_pin, span_utf8=span.decode(),
                                source_file_contents_verified=True)
        arms[arm] = dict(inspection=output_pin, helper_identity=HELPER,
                         item_definition_identity=helper["item_definition_identity"],
                         monomorphization_identity=helper["monomorphization_identity"],
                         arguments=helper["arguments"], origins=origins)
    assert arms["fixed"]["origins"] == arms["early"]["origins"]
    assert read(SOURCE)[1] == source_pin and read(CPU/"evidence/complete.json")[1] == receipt_pin
    result = dict(schema="ferric-mlp-canonical-helper-source-join-v1", passed=True,
                  reader_receipt=receipt_pin, source=source_pin, arms=arms,
                  source_review_scope="impl MlpNormTileV2<'_, '_>",
                  source_contents_join_verified=True, compiler_correction_implemented=False,
                  gpu_execution=False, numerical_acceptance=False, performance_claim=False,
                  production_authority=False)
    with (ROOT/"source-join.json").open("x") as f:
        json.dump(result,f,indent=2,sort_keys=True); f.write("\n")
    print(json.dumps(dict(passed=True,output=read(ROOT/"source-join.json")[1],helper=HELPER,
                          span=[29396,29457],source=source_pin)),flush=True)

if __name__ == "__main__":
    main()
