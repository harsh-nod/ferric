"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-semantic-inspect-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-semantic-call-inspect-cpu-v228-v1'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == '5999eb6b23579e9be205b7627cc97f98eb58b471c552ff355239285c84a13877'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / 'run_cpu.py', ROOT / 'supervisor.py', ROOT / 'prepare_inputs.py']
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5812
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
E = ROOT.parent
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v8'
CAPTURE_FILES = {
    'captures/fixed/result.json': (PAIR / 'fixed-run/evidence/result.json', '91192072e44394fc8e808936572bdc5b3b37092aae37632365436f99caade77d'),
    'captures/fixed/compile.stderr': (PAIR / 'fixed-run/evidence/compile.stderr', 'ff1e3d1ad6117129e3acad5c2f7e6b32c52ea7af01df2da719d40f8559a2d2d7'),
    'captures/fixed/semantic-mir-v1.bin': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '72dfdc23aabf0eaac4f2809371131a853874f51609bf1e380476ce95eb0a1667'),
    'captures/fixed/semantic-source-map-v1.json': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '1c33e74ee9d15837276a82b687d40aa065957cc645df49b746f0c4cc379ef5a5'),
    'captures/early/result.json': (PAIR / 'early-run/evidence/result.json', '5206dc0347e1093ea04a983a73bb763bbf70def98ed9fd8e31fb75dbee693ceb'),
    'captures/early/compile.stderr': (PAIR / 'early-run/evidence/compile.stderr', '3942d375c48f1f8c05a1f321283b5058c01144c54b91a5b0ae776f48a00c7580'),
    'captures/early/semantic-mir-v1.bin': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'e29daedb54bb4428533a48a9342e1a1964ab3756b95fd875537fcb5803597f69'),
    'captures/early/semantic-source-map-v1.json': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '57d9ee61bc355f3debfb3c4828b87bfef487c04325b2af95db11e989f38fbc6e'),
}
HELPER = '00b15eaa5a80fc7f25e19c1c333fcde91f768f51097ae1c2c4f27ced27c66af0'
CALL_PAIR = E / 'guarded-mlp-early-stop-compile-v228-v12'
CALL_CAPTURE_FILES = {
    'call-captures/fixed/result.json': (CALL_PAIR / 'fixed-run/evidence/result.json', '8eeda87c5e60b46c2473ce59caacabe50ce5834b2020696f93a305d50094d9df'),
    'call-captures/fixed/compile.stderr': (CALL_PAIR / 'fixed-run/evidence/compile.stderr', 'f1320124bd68f601e42265128d6b0712805f6a72a82b9578d95137db61bc7f36'),
    'call-captures/fixed/semantic-mir-v1.bin': (CALL_PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'dfb4b64f370def38bd02042298476ec71ee56a53976000ddcb8e8ab5b6047723'),
    'call-captures/fixed/semantic-source-map-v1.json': (CALL_PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '9a65300626378c82b5140139ea42625ad13fe9415926abc98a7432600000b663'),
    'call-captures/early/result.json': (CALL_PAIR / 'early-run/evidence/result.json', '747d0f1e63ccf9cae6769260da1112878e8255407f5f1f8ddb5d36fad86ecb21'),
    'call-captures/early/compile.stderr': (CALL_PAIR / 'early-run/evidence/compile.stderr', '1f58fd02cf60d0514ed63873d83532c5aff44855789e7f9be0af829cfccdded4'),
    'call-captures/early/semantic-mir-v1.bin': (CALL_PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '9dc891d206ed5317606b266706f20d2a161d16855b60227501eb88b962be7195'),
    'call-captures/early/semantic-source-map-v1.json': (CALL_PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', 'f670805114318453baf51ef83d425009f0a1ab9c64d8f47268d3a5a059f97807'),
}
CAPTURE_FILES.update(CALL_CAPTURE_FILES)

for name, (path, digest) in CAPTURE_FILES.items():
    assert path.resolve(strict=True) == path and not path.is_symlink()
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    files[name] = dict(bytes=len(raw), sha256=digest)
assert len(files) == 5828
value = dict(schema='ferric-guarded-mlp-semantic-call-inspect-cpu-input-v1',
             base_complete_sha256=hashlib.sha256(body).hexdigest(),
             files=files, tool_pins=receipt['tool_pins'])
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
