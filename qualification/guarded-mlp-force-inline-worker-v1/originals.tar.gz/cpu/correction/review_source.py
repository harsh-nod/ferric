"""Review the final two borrowed-self accessor annotations and the new closure."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
E = ROOT.parent
BASE = E / 'guarded-mlp-force-inline-accessors-cpu-v228-v1/fe2o3/crates/fe2o3-device'
CURRENT = ROOT / 'fe2o3/crates/fe2o3-device'
DOMAIN = b'FE2O3/WORKGROUP-SYNC-PROVIDER-SOURCE-CLOSURE/V1\0'
OLD = 'f58fbbbbcd003546719cddc201768131353c211f3ca57fd313d6b943a040a7e5'
MODULE = 'src/finite_join/wave_mlp_tiles_v2.rs'
TESTS = 'src/finite_join/wave_mlp_tiles_v2_tests.rs'
ATTRIBUTE = b'    #[cfg_attr(target_arch = "amdgpu", rustc_force_inline)]\n'


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    before = path.lstat()
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    assert before.st_size <= 16 << 20
    raw = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return raw


def closure(root):
    paths = [root / 'Cargo.toml']
    if (root / 'build.rs').exists():
        paths.append(root / 'build.rs')
    for path in (root / 'src').rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            paths.append(path)
        else:
            assert path.is_dir()
    bodies = {p.relative_to(root).as_posix(): read(p) for p in paths}
    digest = hashlib.sha256(DOMAIN)
    for name, body in sorted(bodies.items()):
        for field in (name.encode(), body):
            digest.update(len(field).to_bytes(8, 'little'))
            digest.update(field)
    return digest.hexdigest(), bodies


def main():
    assert __debug__ and os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03'
    assert ROOT.name == 'guarded-mlp-force-inline-worker-cpu-v228-v1'
    assert not (ROOT / 'source-review.json').exists()
    old_id, old = closure(BASE)
    new_id, new = closure(CURRENT)
    assert old_id == OLD and len(old) == len(new) == 53 and set(old) == set(new)
    changed = {name for name in old if old[name] != new[name]}
    assert changed == {MODULE, TESTS}
    expected = old[MODULE]
    annotated = ('WaveMlpTileStorageV2::state', 'WaveMlpTileWorkerV2::observations')
    for signature in (b'    fn state(&self) -> &[AtomicU32; WAVE_STATE_WORDS] {\n',
                      b'    pub fn observations(&self) -> FiniteJoinWorkerResult {\n'):
        assert expected.count(signature) == 1 and ATTRIBUTE + signature not in expected
        expected = expected.replace(signature, ATTRIBUTE + signature)
    assert expected == new[MODULE]
    marker = b'#[test]\nfn storage_state_accessor_retains_exact_atomic_root()'
    end = b'#[test]\nfn tile_accessor_bounds_and_rejection_preserve_existing_read_semantics()'
    assert new[TESTS].count(marker) == new[TESTS].count(end) == 1
    start, finish = new[TESTS].index(marker), new[TESTS].index(end)
    assert new[TESTS][:start] + new[TESTS][finish:] == old[TESTS]
    joins = {}
    for arm, digest in (
        ('fixed', '70400214a942d2bc534e01a4b5ef757dbb42a320f4613fe7ec7c6bd819117427'),
        ('early', 'ef572709628d9ef7fff91fe66eead7230d0cdd6b99c19256294211dbf5633d44'),
    ):
        path = E / 'guarded-mlp-helper-source-join-v228-v3' / (arm + '-run/evidence/result.json')
        raw = read(path)
        assert pin(raw)['sha256'] == digest
        joined = json.loads(raw)
        assert joined['passed'] and joined['source_contents_join_verified']
        assert joined['helper']['identity'] == '7eddc4a0d2b9ce6d1a9ca7dd2780781a00d45048fbc70b19792409f824892b21'
        source = joined['origins']['call_site']['verified_source']
        assert pin(old[MODULE]) == {key: source[key] for key in ('bytes', 'sha256')}
        joins[arm] = dict(path=str(path), **pin(raw))
    result = dict(schema='ferric-mlp-force-inline-worker-source-review-v1',
                  base_source_closure=old_id, candidate_source_closure=new_id, source_joins=joins,
                  original_files={name: pin(body) for name, body in old.items()},
                  candidate_files={name: pin(body) for name, body in new.items()},
                  changed_files=sorted(changed), annotated_methods=annotated,
                  annotation_only_production_delta=True, all_bodies_and_signatures_unchanged=True,
                  previous_host_tests_unchanged=True, new_host_test_definitions=1,
                  cpu_tests_executed=False, gpu_compilation=False, gpu_execution=False,
                  compiler_acceptance=False, production_authority=False)
    assert closure(BASE)[0] == old_id and closure(CURRENT)[0] == new_id
    with (ROOT / 'source-review.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(old=old_id, new=new_id, methods=annotated,
                          receipt=pin(read(ROOT / 'source-review.json')))), flush=True)


if __name__ == '__main__':
    main()
