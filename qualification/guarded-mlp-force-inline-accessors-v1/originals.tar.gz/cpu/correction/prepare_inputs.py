"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-force-inline-reject-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-force-inline-accessors-cpu-v228-v1'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == 'c9bc292d82f5018e04692e7ed7b866f7ac578d35863f210313bc6e5efd176294'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / name for name in ('run_cpu.py', 'supervisor.py', 'qualification_helpers.py',
                                 'prepare_inputs.py', 'review_source.py', 'source-review.json')]
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5814
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
rust_path = ROOT.parent / 'guarded-mlp-s-rpo-qualification-cpu-v228-v1/inputs/rust-library.json'
rust_body = rust_path.read_bytes()
assert hashlib.sha256(rust_body).hexdigest() == '2bb66d20f3f8343267a015571da096c2bc0dd238cd8a2df3bffd430f332a66b9'
rust_pin = dict(path=str(rust_path), bytes=len(rust_body), sha256=hashlib.sha256(rust_body).hexdigest())
value = dict(schema='ferric-guarded-mlp-force-inline-accessors-cpu-input-v1',
             base_complete_sha256=hashlib.sha256(body).hexdigest(),
             files=files, tool_pins=receipt['tool_pins'], rust_src=rust_pin)
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
