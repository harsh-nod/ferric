"""Review exact tile-view annotations, preserved old tests, and the new closure."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
E = ROOT.parent
BASE = E / 'guarded-mlp-force-inline-reject-cpu-v228-v1/fe2o3/crates/fe2o3-device'
CURRENT = ROOT / 'fe2o3/crates/fe2o3-device'
DOMAIN = b'FE2O3/WORKGROUP-SYNC-PROVIDER-SOURCE-CLOSURE/V1\0'
OLD = 'd6ac31898b9e4d594d3aa36d6c5ced378059a4ffff54881463f57c10eba0563c'
MODULE = 'src/finite_join/wave_mlp_tiles_v2.rs'
TESTS = 'src/finite_join/wave_mlp_tiles_v2_tests.rs'
ATTRIBUTE = b'    #[cfg_attr(target_arch = "amdgpu", rustc_force_inline)]\n'
TYPES = ('MlpNormTileV2', 'MlpGateTileV2', 'MlpUpTileV2', 'MlpSwiGluTileV2', 'MlpDownTileV2')


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path):
    before = path.lstat()
    assert path.resolve(strict=True) == path and path.is_file() and not path.is_symlink()
    assert before.st_size <= 16 << 20
    raw = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    return raw


def closure(root):
    paths = [root / 'Cargo.toml']
    if (root / 'build.rs').exists():
        paths.append(root / 'build.rs')
    for path in (root / 'src').rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            paths.append(path)
        else:
            assert path.is_dir()
    bodies = {p.relative_to(root).as_posix(): read(p) for p in paths}
    digest = hashlib.sha256(DOMAIN)
    for name, body in sorted(bodies.items()):
        for field in (name.encode(), body):
            digest.update(len(field).to_bytes(8, 'little'))
            digest.update(field)
    return digest.hexdigest(), bodies


def main():
    assert __debug__ and os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03'
    assert ROOT.name == 'guarded-mlp-force-inline-accessors-cpu-v228-v1'
    assert not (ROOT / 'source-review.json').exists()
    old_id, old = closure(BASE)
    new_id, new = closure(CURRENT)
    assert old_id == OLD and len(old) == len(new) == 53 and set(old) == set(new)
    changed = {name for name in old if old[name] != new[name]}
    assert changed == {MODULE, TESTS}
    expected, annotated = old[MODULE], {}
    for name in TYPES:
        marker = ('impl ' + name + "<'_, '_> {\n").encode()
        assert expected.count(marker) == 1
        start = expected.index(marker) + len(marker)
        end = expected.index(b'\n}\n', start)
        lines = expected[start:end].splitlines(keepends=True)
        updated, methods = [], []
        for index, line in enumerate(lines):
            if line.startswith(b'    pub fn ') and (index == 0 or lines[index - 1] != ATTRIBUTE):
                updated.append(ATTRIBUTE)
                methods.append(line.split(b'(')[0].removeprefix(b'    pub fn ').decode())
            updated.append(line)
        annotated[name] = methods
        expected = expected[:start] + b''.join(updated) + expected[end:]
    assert sum(map(len, annotated.values())) == 19 and expected == new[MODULE]
    marker = b'#[test]\nfn tile_accessor_bounds_and_rejection_preserve_existing_read_semantics()'
    end = b'#[test]\nfn norm_reject_preserves_payload_and_uses_ordinary_error_retirement()'
    assert new[TESTS].count(marker) == new[TESTS].count(end) == 1
    start, finish = new[TESTS].index(marker), new[TESTS].index(end)
    assert new[TESTS][:start] + new[TESTS][finish:] == old[TESTS]
    joins = {}
    for arm, digest in (
        ('fixed', '75e625c6b2833735ad72724e097f0e7689bac3c89d325eb016b7b90650c9d568'),
        ('early', 'c0cfdfa83eec31c9bde7431f8acb56fe974a15b048f20e978c5513a261300beb'),
    ):
        path = E / 'guarded-mlp-helper-source-join-v228-v2' / (arm + '-run/evidence/result.json')
        raw = read(path)
        assert pin(raw)['sha256'] == digest
        joined = json.loads(raw)
        assert joined['passed'] and joined['source_contents_join_verified']
        assert joined['helper']['identity'] == '20a4d4a655b95130262fa05b5f384876f36f6d09945ec40dea003e461afe0a2c'
        source = joined['origins']['call_site']['verified_source']
        assert pin(old[MODULE]) == {key: source[key] for key in ('bytes', 'sha256')}
        joins[arm] = dict(path=str(path), **pin(raw))
    result = dict(schema='ferric-mlp-force-inline-accessors-source-review-v1',
                  base_source_closure=old_id, candidate_source_closure=new_id, source_joins=joins,
                  original_files={name: pin(body) for name, body in old.items()},
                  candidate_files={name: pin(body) for name, body in new.items()},
                  changed_files=sorted(changed), annotated_methods=annotated,
                  annotation_only_production_delta=True, all_bodies_and_signatures_unchanged=True,
                  previous_host_tests_unchanged=True, new_host_test_definitions=1,
                  cpu_tests_executed=False, gpu_compilation=False, gpu_execution=False,
                  compiler_acceptance=False, production_authority=False)
    assert closure(BASE)[0] == old_id and closure(CURRENT)[0] == new_id
    with (ROOT / 'source-review.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(dict(old=old_id, new=new_id, methods=annotated,
                          receipt=pin(read(ROOT / 'source-review.json')))), flush=True)


if __name__ == '__main__':
    main()
