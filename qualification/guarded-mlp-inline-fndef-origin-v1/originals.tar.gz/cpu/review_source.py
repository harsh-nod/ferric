"""Check the closed source delta before compiling; grants no execution authority."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-force-inline-worker-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-inline-fndef-origin-cpu-v228-v1'
assert not (ROOT / 'source-review.json').exists()
def pin(body):
    return dict(bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
def files(root):
    return {str(p.relative_to(root)): p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file()}
old = files(BASE / 'fe2o3')
new = files(ROOT / 'fe2o3')
assert len(old) == len(new) == 5808 and old.keys() == new.keys()
collector = 'crates/rustc-codegen-fe2o3/src/collector.rs'
tests = 'crates/rustc-codegen-fe2o3/src/collector/static_fndef_source_origin_v1_tests.rs'
assert {name for name in old if old[name] != new[name]} == {collector, tests}
o, n = old[collector].decode(), new[collector].decode()
start = "fn static_fndef_source_origin_v1<'tcx>("
end = "struct DeviceCollector<'tcx> {"
old_region = o[o.index(start):o.index(end)]
new_region = n[n.index(start):n.index(end)]
guard_start = '    let InstanceKind::FnPtrShim(method, self_ty) = inlined.def else {'
guard_end = '    // Only reuse an already collected body.'
old_guards = old_region[old_region.index(guard_start):old_region.index(guard_end)]
base_start = new_region.index("fn static_fndef_target_v1<'tcx>(")
new_guards = new_region[new_region.index(guard_start, base_start):
                        new_region.index('    Some(target)\n}', base_start)]
assert new_guards == old_guards
fallback = """                        .or_else(|| {
                            inlined_static_fndef_source_origin_v1(
                                self.tcx,
                                function.instance,
                                body,
                                scope_index,
                                inlined,
                                &mut inline_fndef_work_left,
                            )
                        })
"""
restored = n.replace(new_region, old_region, 1)
assert restored.count(fallback) == 1
restored = restored.replace(fallback, '', 1)
budget = '        let mut inline_fndef_work_left = fe2o3_rustc_front::MAX_TOTAL_BLOCKS_V1;\n'
assert restored.count(budget) == 1
restored = restored.replace(budget, '', 1)
restored = restored.replace('    SourceScope, TerminatorKind, UnwindAction,',
                            '    TerminatorKind, UnwindAction,', 1)
assert restored == o
ot, nt = old[tests].decode(), new[tests].decode()
restored_tests = nt
fixture_start = restored_tests.index('#[inline(always)]\nfn fully_inline_target')
fixture_end = restored_tests.index('"#;', fixture_start)
restored_tests = restored_tests[:fixture_start] + restored_tests[fixture_end:]
helper_start = restored_tests.index('#[derive(Clone)]\nstruct InlinedResults {')
helper_end = restored_tests.index('struct Fixture(PathBuf);', helper_start)
restored_tests = restored_tests[:helper_start] + restored_tests[helper_end:]
new_test_start = restored_tests.index('#[test]\nfn fully_inlined_fndef_origin_audits_real_descendant_without_executable_node()')
new_test_end = restored_tests.index('#[test]\nfn static_fndef_origin_unsafe_callback_body_keeps_rooted_rejection()', new_test_start)
restored_tests = restored_tests[:new_test_start] + restored_tests[new_test_end:]
restored_tests = restored_tests.replace('    inlined: InlinedResults,\n', '', 1)
restored_tests = restored_tests.replace('            inlined: inlined_results(tcx),\n', '', 1)
assert restored_tests == ot
device = 'crates/fe2o3-device/'
provider = {name[len(device):]: body for name, body in new.items()
            if name.startswith(device + 'src/') or name in (device + 'Cargo.toml', device + 'build.rs')}
assert len(provider) == 53
assert all(new[device + name] == old[device + name] for name in provider)
closure = hashlib.sha256(b'FE2O3/WORKGROUP-SYNC-PROVIDER-SOURCE-CLOSURE/V1\0')
for name, body in sorted(provider.items()):
    for value in (name.encode(), body):
        closure.update(len(value).to_bytes(8, 'little'))
        closure.update(value)
digest = closure.hexdigest()
assert digest == '91b3c53fa4235b478427f4569d1d0b77ccbf996ac509dba8e58fc36aa828f950'
result = dict(
    schema='ferric-inlined-static-fndef-source-review-v1',
    candidate_files={name: pin(body) for name, body in sorted(provider.items())},
    changed_files={name: dict(before=pin(old[name]), after=pin(new[name])) for name in (collector, tests)},
    unchanged_provider_source_closure=digest,
    exact_existing_static_fndef_guards_preserved=True,
    existing_test_bodies_and_fixture_prefix_preserved=True,
    other_collector_bodies_unchanged=True,
    source_origin_authentication_extended=True,
    executable_closure_changed=False,
    helper_abi_changed=False,
    cpu_tests_executed=False, gpu_compilation=False, gpu_execution=False,
    production_authority=False,
)
body = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'source-review.json').open('xb') as stream:
    stream.write(body)
print(json.dumps(pin(body), sort_keys=True))
