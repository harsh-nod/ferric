"""Inspect one retained pair with the already-qualified reader; no worker replay or GPU."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import sys
import time
import types

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
ROOT = E / 'guarded-mlp-finite-predicate-census-v228-v1'
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v18'
READER_CPU = E / 'guarded-mlp-semantic-call-census-cpu-v228-v2'
QUALIFIED = E / 'guarded-mlp-finite-predicate-inline-cpu-v228-v3'
SUPERVISOR = QUALIFIED / 'supervisor.py'
SUPERVISOR_SHA = '8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 3
            and all(re.fullmatch('[0-9a-f]{64}', value) for value in sys.argv[1:]),
            'python3 -B run.py FIXED_RECEIPT_SHA EARLY_RECEIPT_SHA')
    require(Path(__file__).resolve() == ROOT / 'run.py'
            and os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == 'smci350-rck-g03-b19-03', 'owned script/host')
    require(not (ROOT / 'evidence').exists(), 'fresh outputs')
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10,
            'CPU8/9 nice10')
    cgroup = Path('/proc/self/cgroup').read_text().strip().split(':', 2)[2]
    scope = Path('/sys/fs/cgroup') / cgroup.lstrip('/')
    require(scope.name == 'ferric-mlp-finite-predicate-census-v228-v1.service'
            and (scope / 'memory.max').read_text().strip() == str(12 << 30)
            and (scope / 'memory.swap.max').read_text().strip() == '0', 'bounded owned service')
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    require(boot == '2dbbbc5a-d8b7-46ac-bd1f-236e5847e24a', 'reconciled boot')
    for kind, limit in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30),
                        (resource.RLIMIT_FSIZE, 1 << 30)):
        resource.setrlimit(kind, (limit, limit))
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'subreaper')
    raw = SUPERVISOR.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == SUPERVISOR_SHA, 'supervisor identity')
    h = types.ModuleType('qualified_census_supervisor')
    h.__file__ = str(SUPERVISOR)
    exec(compile(raw, str(SUPERVISOR), 'exec'), h.__dict__)
    h.ROOT, h.OUT, h.TMP, h.TARGET = ROOT, ROOT / 'evidence', ROOT / 'tmp', ROOT / 'unused-target'
    h.OUT.mkdir(mode=0o700)
    h.TMP.mkdir(mode=0o700)
    paths = [ROOT / 'run.py', SUPERVISOR, QUALIFIED / 'evidence/complete.json',
             READER_CPU / 'evidence/complete.json']
    phases, reports, errors, before, after = [], {}, [], None, None
    started = time.monotonic()
    deadline = started + 300
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)
    failure = None
    try:
        reader_receipt = READER_CPU / 'evidence/complete.json'
        require(h.pin(reader_receipt)['sha256'] ==
                '60898b32e9d93cdae3ec5359177055213898dc27c0e14e5bf68b5d727376a5a7',
                'actual qualified 18-test reader receipt')
        reader = json.loads(reader_receipt.read_bytes())
        require(reader['passed'] and reader['source_unchanged'] and not reader['postcheck_errors']
                and reader['tests']['reader']['passed'] == 18
                and reader['tests']['reader']['failed'] == reader['tests']['reader']['ignored'] == 0,
                'reader qualification')
        executable = Path(reader['artifacts']['reader']['pin']['path'])
        require(h.pin(executable) == reader['artifacts']['reader']['pin']
                and h.pin(executable)['sha256'] ==
                '601bfbed7f0c7e9707b2d453739127abfeebfaa98a984f1546a036247a4c1d67',
                'qualified reader ELF')
        require(h.pin(QUALIFIED / 'evidence/complete.json')['sha256'] ==
                '41d0425beff3ebef1c98910bc904402452c83cddbb8c72229cb9c05e42787a1a',
                'exact current compiler qualification')
        paths.append(executable)
        for arm, sha in zip(('fixed', 'early'), sys.argv[1:], strict=True):
            evidence = PAIR / (arm + '-run/evidence')
            result_path = evidence / 'result.json'
            require(h.pin(result_path)['sha256'] == sha, 'actual compile terminal receipt')
            result = json.loads(result_path.read_bytes())
            require(result['arm'] == arm and result['postcheck_errors'] == []
                    and len(result['phases']) == 1, 'closed original compile scope')
            phase = result['phases'][0]
            require(phase['natural_exit'] and phase['reaped'] and phase['process_group_absent']
                    and not phase['timed_out'] and not phase['forced_cleanup']
                    and phase['exception'] is None and phase['storage_failure'] is None,
                    'clean original compile terminal')
            require(not Path('/proc/' + str(result['execution_scope']['pid'])).exists(),
                    'original controller retired')
            for key in ('pid', 'pgid'):
                require(not Path('/proc/' + str(phase[key])).exists(), 'original child retired')
            paths += [result_path, evidence / 'compile.stderr']
            require(h.pin(evidence / 'compile.stderr') == phase['stderr'], 'original stream pin')
            for name in ('semantic-mir-v1.bin', 'semantic-source-map-v1.json'):
                path = PAIR / (arm + '-run/fe2o3-engineering-diagnostics-v1') / name
                require(h.pin(path) == result['diagnostic_files'][name], 'actual original capture')
                paths.append(path)
        def sources():
            return {str(path): h.pin(path) for path in paths}
        h.sources = sources
        before = sources()
        h.save('sources-before.json', before)
        env = dict(HOME='/home/harmenon', PATH='/usr/bin:/bin',
                   ROCR_VISIBLE_DEVICES='', HIP_VISIBLE_DEVICES='', CUDA_VISIBLE_DEVICES='')
        for arm in ('fixed', 'early'):
            directory = PAIR / (arm + '-run/fe2o3-engineering-diagnostics-v1')
            mir, mapping = directory / 'semantic-mir-v1.bin', directory / 'semantic-source-map-v1.json'
            label = 'census-' + arm
            h.run(label, [str(executable), str(mir), str(mapping),
                          before[str(mir)]['sha256'], before[str(mapping)]['sha256'], '--census'],
                  env, phases, deadline, before, 60, ROOT)
            value = json.loads((h.OUT / (label + '.stdout')).read_bytes())
            require(value['schema'] == 'fe2o3-semantic-call-census-v1'
                    and value['canonical_decode_verified']
                    and not value['execution_authority'] and not value['production_admission']
                    and not value['kir_binding_types_observed']
                    and value['semantic_file_sha256'] == before[str(mir)]['sha256']
                    and value['source_map_file_sha256'] == before[str(mapping)]['sha256'],
                    'exact diagnostic-only capture census')
            reports[arm] = value
    except BaseException as error:
        failure = repr(error)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    try:
        after = {str(path): h.pin(path) for path in paths}
        h.save('sources-after.json', after)
        require(before is not None and after == before, 'inputs changed')
    except BaseException as error:
        errors.append(repr(error))
    failure = failure or ('postcheck failure' if errors else None)
    result = dict(schema='ferric-finite-predicate-retained-census-v1', passed=failure is None,
                  failure=failure, postcheck_errors=errors, phases=phases, reports=reports,
                  inputs_before=before, inputs_after=after,
                  boot_id=boot, pid=os.getpid(), cgroup=cgroup, affinity=[8, 9],
                  compile_receipt_hashes=sys.argv[1:], elapsed_seconds=time.monotonic() - started,
                  gpu_execution=False, compiler_worker_replayed=False, production_authority=False)
    h.save('complete.json' if failure is None else 'failed.json', result)
    print(json.dumps(dict(passed=failure is None, failure=failure,
                          counts={key: {name: value[name] for name in
                                  ('function_count', 'block_count', 'call_count', 'defined_call_count')}
                                  for key, value in reports.items()}), sort_keys=True))
    return 0 if failure is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
