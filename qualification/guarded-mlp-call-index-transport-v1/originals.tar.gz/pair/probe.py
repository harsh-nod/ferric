"""Paired compile-feasibility probe; grants no GPU or numerical authority."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import sys
import time
import tomllib
import types

E = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220")
ROOT = E / "guarded-mlp-early-stop-compile-v228-v14"
DRIVER = E / "guarded-mlp-semantic-capture-driver-cpu-v228-v1"
DRIVER_RECEIPT_SHA = "d8d5be4c85fbcac8b963657d1b5054c8fc8e1fdd987b4a9ba1954bc1cff1895f"
BACKEND = E / "guarded-mlp-call-index-transport-cpu-v228-v4"
BACKEND_RECEIPT_SHA = "fd40879fc85e939f527407ff77f6b7d3fe71ea6c784253f5505e0c4d4a6fd484"
ORIGINAL = E / "row-silu-materialized-checked-probe-v228-v1"
PROVIDER = BACKEND / "fe2o3"
LOCK = E / "guarded-mlp-segment-cpu-v228-v5/candidate/Cargo.lock"
TOOLS = E / "guarded-mlp-memory-bounds-dag-compiler-tools-v228-v1"
COMMAND = E / "guarded-mlp-memory-bounds-dag-lowering-v228-v1/compile.command.json"
SUPERVISOR = E / "guarded-mlp-currentness-duration-diagnostic-cpu-v228-v2/supervisor.py"
PINNED = {
    DRIVER / "evidence/complete.json": DRIVER_RECEIPT_SHA,
    BACKEND / "evidence/complete.json": BACKEND_RECEIPT_SHA,
    SUPERVISOR: "8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc",
    COMMAND: "9488ece7a30056534f29dfae7ef5f2c8c7b5b4e53f0ddb5805ec09330a44b092",
    TOOLS / "manifest.json": "3e9e05f830711ff4c93f2694683a66618e218fb2f792acc16d93c42a274c7949",
    LOCK: "663d3f2a02334440ea3f210a56d3be0e2c4c55f0bea647e8cc01304f2145915e",
}


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def load_supervisor():
    bodies = {}
    for path, digest in PINNED.items():
        require(path.resolve(strict=True) == path and path.is_file(), "canonical input")
        raw = path.read_bytes()
        require(hashlib.sha256(raw).hexdigest() == digest, "input identity: " + str(path))
        bodies[path] = raw
    module = types.ModuleType("early_stop_bounded_leaf")
    module.__file__ = str(SUPERVISOR)
    exec(compile(bodies[SUPERVISOR], str(SUPERVISOR), "exec"), module.__dict__)
    return module


def fixture_transition():
    old_root = "/home/harmenon/ferric-asrock-42/fe2o3"
    original = ORIGINAL / "fixture"
    require(hashlib.sha256((original / "src/lib.rs").read_bytes()).hexdigest()
            == "794bac2a76ced9ddcf3aa3abdaea6c41850e861a1d253837c321efc9c3ceef34", "original caller identity")
    require(hashlib.sha256((PROVIDER / "crates/fe2o3-device/src/finite_join/wave_mlp_tiles_v2.rs").read_bytes()).hexdigest()
            == "df217a21e317623af943282a7ae4b43d840c69db983cfbbcd9418a16953f7c8b", "qualified force-inline worker provider")
    names = sorted(str(p.relative_to(original)) for p in original.rglob("*") if p.is_file())
    require(len(names) == 7, "seven original fixture files")
    for arm in ("fixed", "early"):
        actual = sorted(str(p.relative_to(ROOT / arm)) for p in (ROOT / arm).rglob("*") if p.is_file())
        require(actual == names, "closed fixture roster")
        for name in names:
            raw = (original / name).read_bytes()
            if name == "Cargo.lock":
                raw = LOCK.read_bytes()
                expected = tomllib.loads(raw.decode())
                packages = [p for p in expected["package"] if p["name"] == "ferric-qwen3-tp-guarded-mlp-segment-kernels-device-v1"]
                require(len(packages) == 1 and packages[0]["dependencies"] == ["fe2o3-device", "fe2o3-host"], "same root dependencies")
                packages[0]["name"] = "fe2o3-production-extraction-fixture"
                require(tomllib.loads((ROOT / arm / name).read_text()) == expected, "retained lock semantics")
                token = b"ferric-qwen3-tp-guarded-mlp-segment-kernels-device-v1"
                require(raw.count(token) == 1, "one root package rename")
                raw = raw.replace(token, b"fe2o3-production-extraction-fixture")
            if name == "Cargo.toml":
                require(raw.count(old_root.encode()) == 2, "two dependency relocations")
                raw = raw.replace(old_root.encode(), str(PROVIDER).encode())
            if name == "src/lib.rs":
                closure = b'        #[cfg_attr(target_arch = "amdgpu", inline(always))]\n        |task| execute_task(task),'
                require(raw.count(closure) == 1, "one noncapturing forwarding closure")
                raw = raw.replace(closure, b"        execute_task,")
                forced = b'#[cfg_attr(target_arch = "amdgpu", rustc_force_inline)]\nfn execute_task'
                require(raw.count(forced) == 1, "one named callback attribute")
                raw = raw.replace(forced, b"#[inline(always)]\nfn execute_task")
            if arm == "early" and name == "src/lib.rs":
                token = b"WaveMlpTileWorkerV2::run_fixed_rounds("
                require(raw.count(token) == 1, "one scheduler call")
                raw = raw.replace(token, b"WaveMlpTileWorkerV2::run(")
            require((ROOT / arm / name).read_bytes() == raw, "unexpected fixture edit: " + name)


def main(arm):
    require(__debug__ and sys.dont_write_bytecode and arm in ("fixed", "early"), "closed invocation")
    require(Path(__file__).resolve() == ROOT / "probe.py", "owned script path")
    require(os.getuid() == os.geteuid() == 9661 and os.uname().nodename == "smci350-rck-g03-b19-03", "MI350 owner")
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    nice = os.getpriority(os.PRIO_PROCESS, 0)
    require(nice in (0, 10), "nice envelope")
    if nice == 0:
        os.nice(10)
    for kind, cap in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30), (resource.RLIMIT_FSIZE, 1 << 30)):
        limits = resource.getrlimit(kind)
        limit = min([cap] + [v for v in limits if v != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (limit, limit))
    require(shutil.disk_usage(ROOT).free >= 40 << 30, "initial 40 GiB free floor")
    fixture_transition()
    h = load_supervisor()
    out = ROOT / (arm + "-run")
    require(not os.path.lexists(out), "fresh output required")
    out.mkdir(mode=0o700)
    h.ROOT, h.OUT, h.TARGET, h.TMP = ROOT, out / "evidence", out / "fe2o3-engineering-v1", out / "tmp"
    h.OUT.mkdir(); h.TMP.mkdir()
    h.CPU_LIMIT = 600
    h.CLEANUP_RESERVE = 50
    h.LEAF_WALL = 600
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, "owned subreaper")
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)

    def snapshot():
        paths = [ROOT / "probe.py", COMMAND, TOOLS / "manifest.json", SUPERVISOR, LOCK,
                 DRIVER / "evidence/complete.json", DRIVER / "input-manifest.json",
                 DRIVER / "run_cpu.py", DRIVER / "supervisor.py",
                 BACKEND / "evidence/complete.json", BACKEND / "input-manifest.json",
                 BACKEND / "run_cpu.py", BACKEND / "supervisor.py",
                 BACKEND / "prepare_inputs.py", BACKEND / "qualification_helpers.py"]
        for directory in (PROVIDER, DRIVER / "fe2o3", BACKEND / "fe2o3",
                          ROOT / "fixed", ROOT / "early", ORIGINAL / "fixture"):
            paths.extend(h.files_below(directory))
        require(len(paths) < 18000, "source roster includes both rebuilt compiler trees")
        return {str(p): h.pin(p) for p in sorted(set(paths))}

    h.sources = snapshot
    before = snapshot()
    h.save("sources-before.json", before)
    tool_pins = {}
    for name, expected in json.loads((TOOLS / "manifest.json").read_text()).items():
        actual = h.pin(TOOLS / name)
        require(all(actual[k] == expected[k] for k in ("bytes", "sha256")), "compiler tool identity")
        tool_pins[actual["path"]] = actual
    command = json.loads(COMMAND.read_text())
    argv = command["compiler_argv"][:]
    require(argv[0] == str(TOOLS / "bin/cargo-fe2o3") and argv[1:3] == ["engineering", "hsaco"], "checked route")
    driver = json.loads((DRIVER / "evidence/complete.json").read_bytes())
    require(driver["schema"] == "ferric-guarded-mlp-semantic-capture-driver-cpu-v1"
            and driver["passed"] is True and driver["failure"] is None
            and driver["postcheck_errors"] == [] and driver["source_unchanged"] is True
            and driver["tests"]["driver"]["passed"] == 25
            and driver["tests"]["driver"]["failed"] == 0
            and driver["profile"] == "optimized-inline-hint-16384-v1",
            "qualified frontend receipt required")
    require(driver["final_sources"] == {name: before[str(DRIVER / name)]
                                       for name in driver["final_sources"]},
            "frontend source provenance join")
    driver_pin = driver["artifacts"]["driver"]["pin"]
    require(driver_pin["path"] == str(DRIVER / "target/debug/cargo-fe2o3")
            and h.pin(Path(driver_pin["path"])) == driver_pin, "actual rebuilt frontend identity")
    tool_pins[driver_pin["path"]] = driver_pin
    argv[0] = driver_pin["path"]
    backend = json.loads((BACKEND / "evidence/complete.json").read_bytes())
    require(backend["schema"] == "ferric-guarded-mlp-call-index-transport-cpu-v1"
            and backend["passed"] is True and backend["failure"] is None
            and backend["postcheck_errors"] == [] and backend["source_unchanged"] is True
            and backend["full_compiler_tests_executed"] is True
            and backend["tests"]["compiler"]["passed"] == 1336
            and backend["tests"]["compiler"]["failed"] == 0
            and backend["tests"]["compiler"]["ignored"] == 24
            and backend["full_device_tests_executed"] is True
            and backend["tests"]["device"]["passed"] == 359
            and backend["tests"]["device"]["failed"] == 0
            and backend["tests"]["device"]["ignored"] == 0
            and backend["final_artifact_phase"] == "compiler-products"
            and backend["admission_changed"] is True
            and backend["source_origin_authentication_extended"] is False
            and backend["rejection_diagnostic_extended"] is False
            and backend["lowered_call_transport_extended"] is True
            and backend["full_lowerer_integration_tests_executed"] is True
            and backend["tests"]["lowerer"]["passed"] == 125
            and backend["tests"]["lowerer"]["failed"] == 0
            and backend["tests"]["lowerer"]["ignored"] == 0
            and backend["helper_abi_changed"] is False
            and backend["semantic_predicates_changed"] is True
            and backend["full_lowerer_unit_tests_executed"] is True
            and backend["tests"]["lowerer-unit"]["passed"] == 766
            and backend["tests"]["lowerer-unit"]["ignored"] == 0
            and backend["tests"]["lowerer-unit"]["failed"] == 0
            and backend["reviewed_provider_source_pin_changed"] is False,
            "qualified exact Index-to-U64 call transport backend and device receipt required")
    diagnostic_tests = tuple("shared_slice_helper_v1::" + name for name in (
        "defined_call_index_to_u64_transport_preserves_copy_move_and_correspondence",
        "defined_call_type_diagnostic_preserves_exact_u64_copy_and_move",
        "defined_call_type_diagnostic_display_is_bounded_and_preserves_scalar_kind",
    ))
    diagnostic_tests += ("shared_slice_helper_v1::llvm_abi::source_index_to_u64_helper_argument_reaches_exact_llvm_on_both_targets",)
    require(all(backend["tests"]["lowerer"]["named_outcomes"].get(name) == "ok"
                for name in diagnostic_tests), "all exact call transport and dual-target LLVM regressions must pass")
    unit_tests = tuple("production_semantic_kir_v1::resource_tests::" + name for name in (
        "index_to_u64_transport_cast_obeys_emission_budget_and_exact_passthrough",
        "rust_usize_and_kernel_index_are_edge_transport_equivalent",
    ))
    unit_tests += ("production_semantic_kir_v1::wave_task_entry_parameter_tests::access_roots::retained_fields::"
                   "retained_nested_enum_referent_scalar_move_invalidates_saved_references",)
    require(all(backend["tests"]["lowerer-unit"]["named_outcomes"].get(name) == "ok"
                for name in unit_tests), "exact emission budget and mismatch controls must pass")
    inline_tests = tuple("collector::static_fndef_source_origin_v1_tests::" + name for name in (
        "fully_inlined_fndef_origin_audits_real_descendant_without_executable_node",
        "fully_inlined_fndef_origin_preserves_unsafe_body_rejection",
        "fully_inlined_fndef_origin_normalizes_generic_owner_and_target",
        "fully_inlined_fndef_origin_rejects_wrong_scope_identity_and_ancestry",
        "fully_inlined_fndef_origin_has_exact_and_shared_work_bounds",
    ))
    for cohort in (backend["capture_tests"], backend["helper_controls"], inline_tests):
        require(cohort and all(backend["tests"]["compiler"]["named_outcomes"].get(name) == "ok"
                               for name in cohort), "retained capture and helper controls must pass")
    require(backend["final_sources"] == {name: before[str(BACKEND / name)]
                                        for name in backend["final_sources"]},
            "backend source provenance join")
    for role, option, filename in (("backend", "--extractor-backend", "librustc_codegen_fe2o3.so"),
                                    ("extractor", "--extractor", "fe2o3-rustc-extract")):
        product = backend["artifacts"][role]["pin"]
        require(product["path"] == str(BACKEND / "target/debug" / filename)
                and h.pin(Path(product["path"])) == product, "actual rebuilt compiler product")
        require(argv.count(option) == argv.count(option + "-sha256") == 1,
                "unique compiler product options")
        argv[argv.index(option) + 1] = product["path"]
        argv[argv.index(option + "-sha256") + 1] = product["sha256"]
        tool_pins[product["path"]] = product
    diagnostic = out / "fe2o3-engineering-diagnostics-v1"
    require(argv.count("--") == 1 and "--diagnostic-semantic-dir" not in argv,
            "explicit fresh diagnostic opt-in only")
    separator = argv.index("--")
    argv[separator:separator] = ["--diagnostic-semantic-dir", str(diagnostic)]
    require(argv.count("--mir-normalization") == 1
            and argv[argv.index("--mir-normalization") + 1] == "optimized-inline-v1",
            "original closed normalization selector")
    argv[argv.index("--mir-normalization") + 1] = "optimized-inline-hint-16384-v1"
    for option, value in (("--crate", "fe2o3_production_source_safety_fixture"),
                          ("--output-root", str(h.TARGET)), ("--manifest-path", str(ROOT / arm / "Cargo.toml"))):
        require(argv.count(option) == 1, "unique compiler option")
        argv[argv.index(option) + 1] = value
    require(argv[-4:] == ["--lib", "--no-default-features", "--features", "gfx950"], "old guarded feature tail")
    argv[-4:] = ["--lib"]
    for option in ("--cargo", "--rustc"):
        actual = h.pin(Path(argv[argv.index(option) + 1]))
        require(actual["sha256"] == argv[argv.index(option + "-sha256") + 1], "Rust tool identity")
        tool_pins[actual["path"]] = actual
    env = dict(command["env"], HOME=str(out), TMPDIR=str(h.TMP))
    for key in ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES"):
        env[key] = ""
    require(env["CARGO_BUILD_JOBS"] == "2", "outer Cargo job setting; inner environment is cleared")
    h.save("inputs.json", dict(arm=arm, argv=argv, env=env, tool_pins=tool_pins,
                              original_image_sha256="b0d1766fdb0fda17ab09496d1120ba3cee29100692b48fcc5b05cf0db0a8d589",
                              frontend_cpu_receipt=h.pin(DRIVER / "evidence/complete.json"),
                              backend_cpu_receipt=h.pin(BACKEND / "evidence/complete.json"),
                              diagnostic_directory=str(diagnostic),
                              mir_normalization="optimized-inline-hint-16384-v1",
                              explicit_inner_cargo_job_limit=False,
                              current_generation_not_historical=True, gpu_execution=False))
    phases, error, postcheck_errors, diagnostic_files = [], None, [], {}
    started = time.monotonic()
    deadline = started + 650
    signal.setitimer(signal.ITIMER_REAL, 600)
    try:
        h.run("compile", argv, env, phases, deadline, before, 600, ROOT / arm)
    except BaseException as failure:
        error = repr(failure)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        try:
            after = snapshot()
            h.save("sources-after.json", after)
            require(after == before, "source mutation")
            require({p: h.pin(Path(p)) for p in tool_pins} == tool_pins, "tool mutation")
            fixture_transition()
            if diagnostic.exists():
                files = list(h.files_below(diagnostic))
                bounds = {"semantic-mir-v1.bin": 16 << 20, "semantic-source-map-v1.json": 1 << 20}
                require(len(files) <= 2 and all(p.parent == diagnostic and p.name in bounds for p in files),
                        "closed diagnostic file roster")
                for path in files:
                    require(path.stat().st_size <= bounds[path.name], "diagnostic byte cap")
                    diagnostic_files[path.name] = h.pin(path)
        except BaseException as failure:
            postcheck_errors.append(repr(failure))
    accepted = error is None and not postcheck_errors and len(phases) == 1
    result = dict(schema="ferric-mlp-early-stop-compile-feasibility-v1", arm=arm,
                  compile_accepted=accepted, error=error, postcheck_errors=postcheck_errors,
                  phases=phases, elapsed_seconds=time.monotonic() - started,
                  diagnostic_files=diagnostic_files, semantic_identity_join_verified=False,
                  gpu_execution=False, numerical_acceptance=False, performance_claim=False,
                  production_authority=False, full_model_acceptance=False)
    h.save("result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if accepted else 1


if __name__ == "__main__":
    require(len(sys.argv) == 2, "fixed or early")
    sys.exit(main(sys.argv[1]))
