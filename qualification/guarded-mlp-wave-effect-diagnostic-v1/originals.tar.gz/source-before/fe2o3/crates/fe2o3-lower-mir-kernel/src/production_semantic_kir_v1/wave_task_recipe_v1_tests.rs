fn wave_recipe_owner_floor(owner: &ProductionPreRankedKirOwnerV1) -> usize {
    owner.executable_storage().retained_storage() + owner.assert_origin_storage().payload_storage()
}

#[test]
fn wave_recipe_keeps_actual_read_store_pointer_and_source_ordinals() {
    let owner = materialize_retained_request(retained_request_with_store_role(
        true,
        4095,
        4096,
        false,
        Some(Role::Normalized),
    ))
    .unwrap();
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
    let mut budget =
        fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(&mut work, 16_000_000);
    let floor = wave_recipe_owner_floor(&owner);
    budget.reserve_storage(floor).unwrap();
    let root = SemanticFunctionIdV1::from_index(0);
    let view = owner
        .replay_wave_task_recipe_for_root_v1(root, &mut budget)
        .unwrap()
        .unwrap();
    assert!(!view.grants_artifact_or_launch_authority());
    assert_eq!(view.selected_root(), root);
    assert_eq!(view.selected_function(), root);
    assert_eq!(view.function_ordinal(), 0);
    assert!(std::ptr::eq(view.executable(), owner.executable()));
    assert!(std::ptr::eq(
        view.function(),
        &owner.executable().module().functions[0]
    ));
    assert_eq!(view.roots().len(), 6);
    assert_eq!(view.accesses().len(), 2);
    assert_eq!(view.memory_census().len(), 2);
    assert_eq!(view.effect_operations().len(), 2);
    for (ordinal, row) in view.memory_census().iter().copied().enumerate() {
        assert_eq!(row.source_site(), Some((0, Some(ordinal as u32), 0)));
        assert_eq!(
            view.effect_source_site(row.location()),
            Some((0, Some(ordinal as u32)))
        );
        assert_eq!(row.memory_space(), dialect_kernel::MemorySpaceAttr::Global);
        assert_eq!(row.atomic_contract(), None);
        let ProductionWaveTaskMemoryClassV1::Global(global) = row.class() else {
            panic!("global source effects must retain their entry component");
        };
        assert_eq!(global, *view.access_at(0, Some(ordinal as u32), 0).unwrap());
        let operation = view.operation(row.location()).unwrap();
        let accesses = kir_memory_accesses_v1(operation);
        assert_eq!(accesses.len(), 1);
        assert_eq!(accesses[0].0, row.pointer());
        assert_eq!(accesses[0].1, row.access());
    }
    let input = view.memory_census()[0];
    let gep = view
        .function()
        .body
        .as_ref()
        .unwrap()
        .blocks
        .iter()
        .flat_map(|block| &block.operations)
        .find(|op| op.results.iter().any(|result| result.id == input.pointer()))
        .unwrap();
    let OperationKind::GetElementPointer { offset, .. } = gep.kind else {
        panic!("the actual nonzero input index must remain in KIR");
    };
    assert!(
        view.function()
            .body
            .as_ref()
            .unwrap()
            .blocks
            .iter()
            .flat_map(|block| &block.operations)
            .any(|op| op.results.iter().any(|result| result.id == offset)
                && matches!(op.kind, OperationKind::Constant(Constant::Index(4095))))
    );
    let retained = view.retained_storage();
    assert_eq!(budget.storage(), floor + retained);
    drop(view);
    budget.release_storage(retained).unwrap();
    assert_eq!(budget.storage(), floor);
}

#[test]
fn wave_recipe_keeps_ordinary_roots_separate_and_rejects_other_source_selection() {
    let wave = retained_owner(true);
    let ordinary = retained_owner(false);
    let root = SemanticFunctionIdV1::from_index(0);
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
    let mut budget =
        fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(&mut work, 16_000_000);
    budget
        .reserve_storage(wave_recipe_owner_floor(&wave).max(wave_recipe_owner_floor(&ordinary)))
        .unwrap();
    let floor = budget.storage();
    assert!(
        ordinary
            .replay_wave_task_recipe_for_root_v1(root, &mut budget)
            .unwrap()
            .is_none()
    );
    assert_eq!(budget.storage(), floor);
    let view = wave
        .replay_wave_task_recipe_for_root_v1(root, &mut budget)
        .unwrap()
        .unwrap();
    assert!(
        view.validate_source_selection(ordinary.semantic_ssa().source_semantic(), root, root)
            .is_err()
    );
    assert!(
        view.validate_source_selection(
            wave.semantic_ssa().source_semantic(),
            root,
            SemanticFunctionIdV1::from_index(1)
        )
        .is_err()
    );
    assert!(
        wave.replay_wave_task_recipe_for_root_v1(SemanticFunctionIdV1::from_index(1), &mut budget,)
            .is_err()
    );
}

#[test]
fn wave_recipe_shared_budget_exact_and_one_short_preserve_owner_floor() {
    let owner = retained_owner(true);
    let root = SemanticFunctionIdV1::from_index(0);
    let owner_floor = wave_recipe_owner_floor(&owner);
    let floor = owner_floor + 11;
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
    let mut budget =
        fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(&mut work, 16_000_000);
    budget.charge_work(7).unwrap();
    budget.reserve_storage(floor).unwrap();
    let view = owner
        .replay_wave_task_recipe_for_root_v1(root, &mut budget)
        .unwrap()
        .unwrap();
    let exact_work = budget.work();
    let exact_storage = budget.peak_storage();
    let retained = view.retained_storage();
    drop(view);
    budget.release_storage(retained).unwrap();
    assert_eq!(budget.storage(), floor);
    for (work_limit, storage_limit, succeeds) in [
        (exact_work, exact_storage, true),
        (exact_work - 1, exact_storage, false),
        (exact_work, exact_storage - 1, false),
    ] {
        let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(work_limit);
        let mut budget = fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(
            &mut work,
            storage_limit,
        );
        budget.charge_work(7).unwrap();
        budget.reserve_storage(floor).unwrap();
        let result = owner.replay_wave_task_recipe_for_root_v1(root, &mut budget);
        assert_eq!(result.is_ok(), succeeds);
        if let Ok(Some(view)) = result {
            let retained = view.retained_storage();
            drop(view);
            budget.release_storage(retained).unwrap();
        }
        assert_eq!(budget.storage(), floor);
        assert!(budget.work() >= 7 && budget.work() <= work_limit);
        assert_eq!(budget.remaining_work(), work_limit - budget.work());
    }
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(exact_work);
    let mut budget = fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(
        &mut work,
        exact_storage,
    );
    budget.reserve_storage(owner_floor - 1).unwrap();
    assert!(
        owner
            .replay_wave_task_recipe_for_root_v1(root, &mut budget)
            .is_err()
    );
    assert_eq!(budget.storage(), owner_floor - 1);
    assert_eq!(budget.work(), 0);
}

#[test]
fn wave_recipe_malformed_correlation_charges_work_without_losing_incoming_floors() {
    let mut owner = retained_owner(true);
    let original = owner.correspondence.parameter_component_bindings.to_vec();
    owner.correspondence.parameter_component_bindings = original[1..].to_vec().into_boxed_slice();
    let floor = wave_recipe_owner_floor(&owner) + 11;
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
    let mut budget =
        fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(&mut work, 16_000_000);
    budget.charge_work(7).unwrap();
    budget.reserve_storage(floor).unwrap();
    let root = SemanticFunctionIdV1::from_index(0);
    assert!(
        owner
            .replay_wave_task_recipe_for_root_v1(root, &mut budget)
            .is_err()
    );
    assert!(budget.work() > 7);
    assert!(budget.work() < 4_000_000);
    assert_eq!(budget.storage(), floor);
    assert_eq!(budget.remaining_work(), 4_000_000 - budget.work());
}

#[derive(Clone, Copy)]
enum WaveRecipeBindingCase {
    Exact,
    SameTypeOriginSwap,
    WrongSourceOrdinal,
    MissingMemoryRow,
    DuplicateMemoryRow,
}

#[test]
fn wave_recipe_preflight_rejects_empty_summaries_from_unknown_effects() {
    let owner = retained_owner(true);
    // These are inert negative operations, not an admitted assembly identity.
    // Empty declared effects must never make either operation appear complete.
    let cases = [
        OperationKind::Call {
            callee: FunctionId::new("unknown_effects"),
            arguments: vec![],
        },
        OperationKind::InlineAssembly(fe2o3_kernel_ir::InlineAssembly {
            target: fe2o3_kernel_ir::InlineAssemblyTarget::AmdGpuGfx942,
            source: fe2o3_kernel_ir::AssemblySourceIdentity::new(
                [0; 32], [0; 32], [0; 32], [0; 32],
            ),
            mnemonic: "s_nop 0".into(),
            operands: vec![],
            options: BTreeSet::from([fe2o3_kernel_ir::AssemblyOption::NoMemory]),
            declared_effects: BTreeSet::new(),
        }),
    ];
    for kind in cases {
        let operation = Operation::new(vec![], kind);
        assert!(operation.memory_effects().is_empty());
        assert!(!operation.has_complete_effect_summary());
        let mut body = owner.executable().module().functions[0]
            .body
            .clone()
            .unwrap();
        body.blocks[0].operations.push(operation);
        let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
        let mut budget = fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(
            &mut work, 16_000_000,
        );
        budget.charge_work(7).unwrap();
        let floor = wave_recipe_owner_floor(&owner) + 11;
        budget.reserve_storage(floor).unwrap();
        assert!(matches!(
            wave_recipe_index_storage_v1(&owner, &body, &mut budget),
            Err(ProductionSemanticKirErrorV1::CorrespondenceMismatch)
        ));
        assert_eq!(budget.storage(), floor);
        assert!(budget.work() > 7);
    }
}

fn wave_recipe_small_conditional_input(
    owner: &ProductionPreRankedKirOwnerV1,
    case: WaveRecipeBindingCase,
) -> Result<
    (
        ProductionRankedSemanticChecksV1,
        Vec<ProductionRankedAccessSourceV1>,
    ),
    fe2o3_pliron::ProductionWaveTaskConditionalCompileErrorV1,
> {
    use fe2o3_pliron::{
        ProductionConstructionV1, ProductionRankedBlockV1, ProductionRankedKernelV1,
        ProductionRankedTerminatorV1, ProductionSessionLimitsV1,
        ProductionWaveTaskRankedEffectBindingV1,
        compile_ranked_kernel_for_conditional_wave_tasks_v1,
    };
    let mut work = fe2o3_kernel_ir::CanonicalKernelIrWorkBudgetV1::new(4_000_000);
    let mut budget =
        fe2o3_kernel_ir::CanonicalKernelIrVerificationResourceBudgetV1::new(&mut work, 16_000_000);
    budget
        .reserve_storage(wave_recipe_owner_floor(owner))
        .unwrap();
    let view = owner
        .replay_wave_task_recipe_for_root_v1(SemanticFunctionIdV1::from_index(0), &mut budget)
        .unwrap()
        .unwrap();
    let mut operations = vec![ProductionRankedOperationV1::ExecutionLayout {
        grid_identity: 1,
        global_extents: [64, 1, 1],
        workgroup_extents: [64, 1, 1],
        subgroup_size: 64,
        full_physical_workgroups: true,
    }];
    let mut sources = Vec::new();
    let mut bindings = Vec::new();
    for (index, row) in view.memory_census().iter().enumerate() {
        let ProductionWaveTaskMemoryClassV1::Global(global) = row.class() else {
            panic!("this small integration fixture has only original global effects");
        };
        let (block, statement, mut ordinal) = row.source_site().unwrap();
        let mut origin = global.root().allocation_origin();
        if index == 0 {
            match case {
                WaveRecipeBindingCase::SameTypeOriginSwap => {
                    origin = view
                        .roots()
                        .iter()
                        .find(|root| root.role() == Role::NormWeight)
                        .unwrap()
                        .allocation_origin();
                }
                WaveRecipeBindingCase::WrongSourceOrdinal => ordinal += 1,
                _ => {}
            }
        }
        let ranked_operation = u32::try_from(operations.len()).unwrap();
        operations.push(ProductionRankedOperationV1::AllocationEffect {
            kind: row.access(),
            memory_space: row.memory_space(),
            allocation_origin: origin,
            noalias_class: 0,
        });
        sources.push(ProductionRankedAccessSourceV1::new(
            block,
            statement,
            ordinal,
            0,
            ranked_operation,
        ));
        bindings.push(ProductionWaveTaskRankedEffectBindingV1::new(
            Some((block, statement, ordinal)),
            row.location(),
            row.operation_access_ordinal(),
            Some((0, ranked_operation)),
        ));
    }
    match case {
        WaveRecipeBindingCase::MissingMemoryRow => {
            bindings.pop();
        }
        WaveRecipeBindingCase::DuplicateMemoryRow => bindings.push(bindings[0]),
        _ => {}
    }
    let kernel = ProductionRankedKernelV1::new(
        view.function().id.as_str(),
        0,
        vec![ProductionRankedBlockV1::new(
            operations,
            ProductionRankedTerminatorV1::Return,
        )],
    )
    .unwrap();
    let input = compile_ranked_kernel_for_conditional_wave_tasks_v1(
        ProductionConstructionV1::ranked_kernel("wave_recipe_custody", kernel).unwrap(),
        ProductionSessionLimitsV1::default(),
        view.executable(),
        view.function_ordinal(),
        &bindings,
        &[],
        &mut budget,
    );
    let retained = view.retained_storage();
    drop(view);
    budget.release_storage(retained).unwrap();
    input.map(|input| {
        (
            ProductionRankedSemanticChecksV1::ConditionalWaveTasks(input),
            sources,
        )
    })
}

fn wave_recipe_two_global_owner(index: u64) -> ProductionPreRankedKirOwnerV1 {
    materialize_retained_request(retained_request_with_store_role(
        true,
        index,
        index + 1,
        false,
        Some(Role::Normalized),
    ))
    .unwrap()
}

#[test]
fn wave_recipe_conditional_join_replays_exact_source_and_every_memory_effect() {
    let owner = wave_recipe_two_global_owner(4095);
    let (checks, sources) =
        wave_recipe_small_conditional_input(&owner, WaveRecipeBindingCase::Exact).unwrap();
    assert!(checks.ordinary().is_none());
    assert!(!checks.all_mandatory_reports_are_clean());
    validate_retained_conditional_ranked_owner_v1(
        owner.semantic_ssa(),
        owner.executable(),
        &owner.correspondence,
        SemanticFunctionIdV1::from_index(0),
        &checks,
        &sources,
        &[],
        owner.limits,
    )
    .unwrap();
    let result = validate_mir_pliron_translation_with_semantic_v1(
        Some(owner.semantic_ssa().source_semantic()),
        owner.executable().module(),
        &owner.correspondence,
        owner.executable().module().kernels[0].id.as_str(),
        &checks,
        &sources,
        &[],
        owner.limits.max_operations,
    )
    .unwrap();
    assert_eq!(result.memory_effects, 2);
    assert_eq!(result.conservative_ranked_effects, 2);
    let other = wave_recipe_two_global_owner(4094);
    assert!(
        validate_retained_conditional_ranked_owner_v1(
            other.semantic_ssa(),
            other.executable(),
            &other.correspondence,
            SemanticFunctionIdV1::from_index(0),
            &checks,
            &sources,
            &[],
            other.limits,
        )
        .is_err()
    );
}

#[test]
fn wave_recipe_conditional_join_rejects_wrong_roots_ordinals_and_incomplete_census() {
    let owner = wave_recipe_two_global_owner(4095);
    for case in [
        WaveRecipeBindingCase::SameTypeOriginSwap,
        WaveRecipeBindingCase::WrongSourceOrdinal,
    ] {
        let (checks, sources) = wave_recipe_small_conditional_input(&owner, case).unwrap();
        assert!(
            validate_retained_conditional_ranked_owner_v1(
                owner.semantic_ssa(),
                owner.executable(),
                &owner.correspondence,
                SemanticFunctionIdV1::from_index(0),
                &checks,
                &sources,
                &[],
                owner.limits,
            )
            .is_err()
        );
    }
    for case in [
        WaveRecipeBindingCase::MissingMemoryRow,
        WaveRecipeBindingCase::DuplicateMemoryRow,
    ] {
        assert!(wave_recipe_small_conditional_input(&owner, case).is_err());
    }
}
