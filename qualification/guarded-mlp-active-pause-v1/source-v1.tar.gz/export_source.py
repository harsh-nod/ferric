"""Export the fixed active-pause Rust overlay, preimages and exact source predecessor."""
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import sys
import tarfile

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
ROOT = E / 'guarded-mlp-active-pause-source-v228-v1'
PROPOSAL = dict(bytes=444678, sha256='55f6af2baa21ed8be123ff815265966ba2b098cb856413eabd052fdee3e81161')
PREDECESSOR = dict(bytes=440584, sha256='937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f')
DELTA = (
    'fe2o3/crates/fe2o3-kfd/src/engineering_gfx950_peer_combined_mlp_paired_pause_tests.rs',
    'fe2o3/crates/fe2o3-kfd/src/engineering_gfx950_peer_combined_mlp_paired_v1.rs',
    'fe2o3/crates/fe2o3-kfd/src/engineering_gfx950_peer_combined_mlp_paired_v1_tests.rs',
)
FIXED = {
    'run_cpu.py': dict(bytes=32572, sha256='8f6bb1d2e7e4339e87bf957ff77ae356d00251754a0395653dbd1b44e200b8a6'),
    'seal_sources.py': dict(bytes=10243, sha256='dece218f4ea4b87ca0c34797fe49a2d9068e2201c225a419649238437064e3b3'),
    'seal-v1/format-command.json': dict(bytes=6949, sha256='92c4af331aa78f6f4d5384d8f2e6ae271fddff0c40573e7d99934ef5b9597908'),
    'seal-v1/format-result.json': dict(bytes=451, sha256='b0d25cf236958e37a24f7bba259a5d4e5be7e44a7d8ac972f40da5501e1fd0ae'),
}
READS = {}


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def compact(value):
    return {k: value[k] for k in ('bytes', 'sha256')}


def read(path, expected=None):
    path = Path(path)
    before = path.lstat()
    require(path.is_absolute() and path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_size <= 32 << 20, 'bounded canonical original')
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    with path.open('rb') as stream:
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'same opened original')
        raw = stream.read((32 << 20) + 1)
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'opened original unchanged')
    require(len(raw) == before.st_size and stamp(before) == stamp(path.lstat()), 'original unchanged')
    actual = pin(raw)
    require(expected is None or actual == compact(expected), 'original source pin')
    require(str(path) not in READS or READS[str(path)] == actual, 'source readset drift')
    READS[str(path)] = actual
    return raw


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 1, 'python3 -B export_source.py only')
    require(os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03',
            'exact unprivileged host')
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10
            and all(os.environ.get(k) == '' for k in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES')),
            'CPU8,9 nice10 hidden GPUs')
    require(shutil.disk_usage(ROOT).free >= 40 << 30, 'initial40GiB floor')
    resource.setrlimit(resource.RLIMIT_AS, (512 << 20, 512 << 20))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    signal.alarm(90)
    bodies = {}
    def keep(name, path, expected=None):
        require(name not in bodies and not name.startswith('/') and '..' not in Path(name).parts,
                'unique archive-relative body')
        bodies[name] = read(path, expected)
        return bodies[name]
    proposal = json.loads(keep('proposal.json', ROOT / 'proposal.json', PROPOSAL))
    base = json.loads(keep('base-manifest.json', ROOT / 'base-manifest.json', proposal['base_manifest']))
    require(proposal['predecessor'] == PREDECESSOR, 'exact qualified source predecessor')
    previous = json.loads(keep('predecessor-proposal.json', ROOT / 'predecessor-proposal.json', PREDECESSOR))
    keep('source-review-input-v1.json', ROOT / 'source-review-input-v1.json', proposal['review_input'])
    preformat = json.loads(keep('seal-v1/source-preformat.json', ROOT / 'seal-v1/source-preformat.json',
                              proposal['source_preformat']))
    require(proposal['schema'] == 'ferric-readiness40-active-pause-source-v1'
            and proposal['runtime_source_changed'] is True and proposal['polling_pause_changed'] is True
            and all(proposal[k] is False for k in ('compiled', 'tests_executed', 'gpu_execution',
                'native_admission', 'kernel_math_changed', 'currentness_policy_changed',
                'numerical_acceptance', 'performance_claim')), 'source-only seal claims')
    require(len(proposal['files']) == 2139 and len(base['sources']) == 2128
            and len(proposal['overlay']) == 31 and len(previous['files']) == 2138,
            'closed cumulative project and overlay census')
    require(sum(n.startswith('fe2o3/') for n in proposal['files']) == 834
            and sum(n.startswith('ferric/adapters/tp-peer-finite-engineering-worker-v1/')
                    for n in proposal['files']) == 242, 'runtime and worker source census')
    require(set(preformat) == set(proposal['files']), 'complete preformat source map')
    for name, expected in proposal['files'].items():
        require(name.startswith(('fe2o3/', 'ferric/')) and '..' not in Path(name).parts
                and Path(name).as_posix() == name, 'closed source path')
        read(ROOT / name, expected)
    changed = sorted(n for n, p in proposal['files'].items() if n in base['sources']
                     and p != compact(base['sources'][n]))
    changed += sorted(set(proposal['files']) - set(base['sources']))
    require(sorted(changed) == proposal['overlay'], 'only declared cumulative source changes')
    require(set(previous['files']) <= set(proposal['files'])
            and sorted(n for n in proposal['files']
                       if proposal['files'][n] != previous['files'].get(n)) == list(DELTA),
            'only three reviewed active-pause source changes from qualified predecessor')
    patches = {'fe2o3': [], 'ferric': []}
    for name in proposal['overlay']:
        require(name.endswith('.rs'), 'Rust-only source publication')
        after = keep(name, ROOT / name, proposal['files'][name])
        before = b''
        if name in base['sources']:
            row = base['sources'][name]
            before = keep('preimages/' + name, Path(row['source']), row)
        repository, relative = name.split('/', 1)
        patches[repository].extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
            fromfile='a/' + relative if before else '/dev/null', tofile='b/' + relative))
    for name, expected in FIXED.items():
        keep(name, ROOT / name, expected)
    result = json.loads(bodies['seal-v1/format-result.json'])
    require(result['exit_code'] == 0 and result['failure'] is None and result['reaped'] is True
            and result['owned_group_absent'] is True and result['spawn_observed'] is True
            and result['timed_out'] is False and result['cleanup_signalled'] is False
            and result['cleanup_errors'] == [] and result['interrupted_signals'] == [], 'original healthy formatting')
    for key in ('stdout', 'stderr'):
        keep('seal-v1/format.' + key, ROOT / ('seal-v1/format.' + key), result[key])
    command = json.loads(bodies['seal-v1/format-command.json'])
    read(Path(command['tool']['path']), command['tool'])
    require(command['affinity'] == [8, 9] and command['nice'] == 10, 'original formatter bounds')
    for name in ('export_cpu.py', 'export_source.py'):
        keep(name, ROOT / name)
    for repository, lines in patches.items():
        bodies[repository + '.patch'] = ''.join(lines).encode()
    require(len(bodies) <= 128 and sum(map(len, bodies.values())) <= 32 << 20
            and all(not raw.startswith(b'\x7fELF') for raw in bodies.values()), 'bounded source-only archive')
    generated = {name: pin(bodies[name]) for name in ('fe2o3.patch', 'ferric.patch')}
    originals = {n: pin(raw) for n, raw in sorted(bodies.items()) if n not in generated}
    manifest = dict(schema='ferric-active-pause-source-export-v1', proposal=PROPOSAL,
        predecessor=PREDECESSOR, predecessor_delta=list(DELTA), originals=originals,
        generated_patches=generated, source_changes_authored_on='mi350', overlay_bodies=31,
        runtime_source_bodies=834, worker_source_bodies=242, project_source_bodies=2139,
        polling_pause_changed=True, inherited_failure_capsules_reexported=False,
        cpu_qualification_claim=False, gpu_execution=False,
        native_admission=False, numerical_acceptance=False, performance_claim=False)
    bodies['export-manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    out = E / 'guarded-mlp-active-pause-source-v228-v1.tar.gz'
    require(not os.path.lexists(out) and shutil.disk_usage(ROOT).free >= 38 << 30, 'fresh archive and live floor')
    with out.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as tar:
            for name, raw in sorted(bodies.items()):
                member = tarfile.TarInfo(name); member.size = len(raw); member.mode = 0o600; member.mtime = 0
                tar.addfile(member, io.BytesIO(raw))
    for path, expected in list(READS.items()):
        read(Path(path), expected)
    require(shutil.disk_usage(ROOT).free >= 38 << 30, 'final38GiB floor')
    signal.alarm(0)
    print(json.dumps(dict(archive=str(out), **pin(read(out)), members=len(bodies),
        expanded_bytes=sum(map(len, bodies.values()))), sort_keys=True))


if __name__ == '__main__':
    main()
