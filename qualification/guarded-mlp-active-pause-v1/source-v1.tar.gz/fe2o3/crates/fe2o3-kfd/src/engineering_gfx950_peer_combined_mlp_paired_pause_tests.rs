use super::*;
use std::cell::{Cell, RefCell};
use std::panic::{AssertUnwindSafe, catch_unwind};

#[derive(Debug, PartialEq, Eq)]
enum Event {
    Clock(i64),
    Spin,
    Sleep(Duration),
}

fn scripted(scoped: bool, samples: &[i64]) -> Vec<Event> {
    let base = Instant::now() + Duration::from_secs(1);
    let pending = RefCell::new(samples.iter().copied());
    let events = RefCell::new(Vec::new());
    pause_with(
        scoped,
        || {
            let sample = pending.borrow_mut().next().expect("unexpected clock read");
            events.borrow_mut().push(Event::Clock(sample));
            if sample < 0 {
                base - Duration::from_nanos((-sample) as u64)
            } else {
                base + Duration::from_nanos(sample as u64)
            }
        },
        || events.borrow_mut().push(Event::Spin),
        |duration| events.borrow_mut().push(Event::Sleep(duration)),
    );
    assert!(pending.borrow_mut().next().is_none(), "unused clock sample");
    events.into_inner()
}

fn spins(events: &[Event]) -> usize {
    events.iter().filter(|event| **event == Event::Spin).count()
}

#[test]
fn paired_pause_full_preserves_exact_sleep_without_clock_or_spin() {
    assert_eq!(PAUSE_BUDGET, Duration::from_micros(50));
    assert_eq!(PAUSE_SPIN_LIMIT, 4096);
    let sleeps = RefCell::new(Vec::new());
    pause_with(
        false,
        || panic!("ordinary Full must not sample the active clock"),
        || panic!("ordinary Full must not spin"),
        |duration| sleeps.borrow_mut().push(duration),
    );
    assert_eq!(sleeps.into_inner(), [Duration::from_micros(50)]);
}

#[test]
fn paired_pause_scoped_immediate_budget_and_overshoot_do_not_spin_or_sleep() {
    for elapsed in [50_000, 50_001, 90_000] {
        assert_eq!(
            scripted(true, &[0, elapsed]),
            [Event::Clock(0), Event::Clock(elapsed)]
        );
    }
}

#[test]
fn paired_pause_scoped_partial_progress_preserves_exact_check_spin_order() {
    assert_eq!(
        scripted(true, &[0, 20_000, 49_999, 50_000]),
        [
            Event::Clock(0),
            Event::Clock(20_000),
            Event::Spin,
            Event::Clock(49_999),
            Event::Spin,
            Event::Clock(50_000),
        ]
    );
}

#[test]
fn paired_pause_scoped_stalled_clock_is_bounded_then_sleeps_full_budget() {
    let events = scripted(true, &vec![0; 4098]);
    assert_eq!(spins(&events), 4096);
    assert_eq!(
        events
            .iter()
            .filter(|event| matches!(event, Event::Clock(_)))
            .count(),
        4098
    );
    assert_eq!(
        events.last(),
        Some(&Event::Sleep(Duration::from_micros(50)))
    );
}

#[test]
fn paired_pause_scoped_partial_spin_budget_sleeps_only_positive_remainder() {
    let mut samples = vec![20_000; 4098];
    samples[0] = 0;
    let events = scripted(true, &samples);
    assert_eq!(spins(&events), 4096);
    assert_eq!(
        events.last(),
        Some(&Event::Sleep(Duration::from_micros(30)))
    );
    assert_eq!(
        events
            .iter()
            .filter(|event| matches!(event, Event::Sleep(_)))
            .count(),
        1
    );
}

#[test]
fn paired_pause_scoped_final_clock_recheck_avoids_zero_or_extra_sleep() {
    for elapsed in [50_000, 70_000] {
        let mut samples = vec![0; 4098];
        samples[4097] = elapsed;
        let events = scripted(true, &samples);
        assert_eq!(spins(&events), 4096);
        assert_eq!(events.last(), Some(&Event::Clock(elapsed)));
        assert!(!events.iter().any(|event| matches!(event, Event::Sleep(_))));
    }
}

#[test]
fn paired_pause_scoped_backward_samples_use_conservative_bounded_fallback() {
    let mut samples = vec![-1; 4098];
    samples[0] = 0;
    let events = scripted(true, &samples);
    assert_eq!(spins(&events), 4096);
    assert_eq!(
        events.last(),
        Some(&Event::Sleep(Duration::from_micros(50)))
    );
    let progress = scripted(true, &[0, 30_000, 10_000, 50_000]);
    assert_eq!(spins(&progress), 2);
    assert_eq!(progress.last(), Some(&Event::Clock(50_000)));
}

#[test]
fn paired_pause_injected_unwind_propagates_without_later_pause_effects() {
    // Ownership is outside this helper: an unwind is not itself a poison receipt.
    for fail in ["clock", "spin", "sleep"] {
        let base = Instant::now();
        let clock_calls = Cell::new(0);
        let spin_calls = Cell::new(0);
        let sleep_calls = Cell::new(0);
        let result = catch_unwind(AssertUnwindSafe(|| {
            pause_with(
                true,
                || {
                    clock_calls.set(clock_calls.get() + 1);
                    assert_ne!(fail, "clock", "injected clock unwind");
                    base
                },
                || {
                    spin_calls.set(spin_calls.get() + 1);
                    assert_ne!(fail, "spin", "injected spin unwind");
                },
                |duration| {
                    assert_eq!(duration, Duration::from_micros(50));
                    sleep_calls.set(sleep_calls.get() + 1);
                    assert_ne!(fail, "sleep", "injected sleep unwind");
                },
            );
        }));
        assert!(result.is_err());
        assert_eq!(
            (clock_calls.get(), spin_calls.get(), sleep_calls.get()),
            match fail {
                "clock" => (1, 0, 0),
                "spin" => (2, 1, 0),
                "sleep" => (4098, 4096, 1),
                _ => unreachable!(),
            }
        );
    }
}

#[test]
fn paired_pause_native_wiring_is_scoped_only_and_uses_real_pause_primitives() {
    let source = include_str!("engineering_gfx950_peer_combined_mlp_paired_v1.rs");
    let body = source
        .split("fn pause(&mut self) {")
        .nth(1)
        .unwrap()
        .split("fn complete_terminal_pair_until(")
        .next()
        .unwrap()
        .chars()
        .filter(|c| !c.is_whitespace())
        .collect::<String>();
    assert!(body.contains("pause_with("));
    assert!(
        body.contains("matches!(&self.currentness,scoped_currentness::Currentness::Scoped(_))")
    );
    assert!(body.contains("Instant::now,std::hint::spin_loop,std::thread::sleep,"));
    assert!(!body.contains("self.now("));
}

// Delegate every original coordinator effect to its existing fake. Only pause
// routes through the new helper; its private clock never calls backend.now().
struct PausingFake {
    inner: Fake,
    scoped: bool,
    pause_elapsed: Duration,
    now_calls: usize,
    spins: usize,
    sleeps: Vec<Duration>,
}

impl PausingFake {
    fn new(scoped: bool) -> Self {
        Self {
            inner: Fake::new(),
            scoped,
            pause_elapsed: Duration::from_micros(50),
            now_calls: 0,
            spins: 0,
            sleeps: Vec::new(),
        }
    }
}

impl CoordinatorBackend for PausingFake {
    fn now(&mut self) -> Instant {
        self.now_calls += 1;
        self.inner.now()
    }
    fn preflight(&mut self) -> Result<()> {
        self.inner.preflight()
    }
    fn consume(&mut self, rank: usize) -> Result<()> {
        self.inner.consume(rank)
    }
    fn reserve(&mut self, rank: usize) -> Result<()> {
        self.inner.reserve(rank)
    }
    fn fence(&mut self) -> Result<()> {
        self.inner.fence()
    }
    fn publish(&mut self, rank: usize, deadline: Instant) -> Result<()> {
        self.inner.publish(rank, deadline)
    }
    fn poll(&mut self, deadline: Instant) -> Result<bool> {
        self.inner.poll(deadline)
    }
    fn retire(&mut self, rank: usize, deadline: Instant) -> Result<()> {
        self.inner.retire(rank, deadline)
    }
    fn terminal(&mut self) -> Result<()> {
        self.inner.terminal()
    }
    fn complete(&mut self, rank: usize) -> Result<CombinedMlpSnapshotV1> {
        self.inner.complete(rank)
    }
    fn finish(
        &mut self,
        states: &[CombinedMlpSnapshotV1; 2],
        deadline: Instant,
    ) -> Result<[(u64, u64); 2]> {
        self.inner.finish(states, deadline)
    }
    fn pause(&mut self) {
        self.inner.events.push("pause".into());
        let base = self.inner.clock;
        let clock = Cell::new(base);
        let first = Cell::new(true);
        let spins = Cell::new(0);
        let sleeps = RefCell::new(Vec::new());
        let advance = self.pause_elapsed;
        pause_with(
            self.scoped,
            || {
                let observed = if first.replace(false) {
                    base
                } else {
                    base + advance
                };
                clock.set(observed);
                observed
            },
            || spins.set(spins.get() + 1),
            |remaining| {
                sleeps.borrow_mut().push(remaining);
                clock.set(clock.get() + remaining);
            },
        );
        self.inner.clock = clock.get();
        self.spins += spins.get();
        self.sleeps.extend(sleeps.into_inner());
    }
    fn poison(&mut self) {
        self.inner.poison()
    }
}

#[test]
fn paired_pause_coordinator_preserves_event_order_backend_clocks_and_retirement() {
    let mut original = Fake::new();
    coordinate(&mut original, 10).unwrap();
    let mut ordinary = PausingFake::new(false);
    let full = coordinate(&mut ordinary, 10).unwrap();
    let mut scoped = PausingFake::new(true);
    let warm = coordinate(&mut scoped, 10).unwrap();
    assert_eq!(ordinary.inner.events, original.events);
    assert_eq!(scoped.inner.events, original.events);
    assert_eq!(ordinary.now_calls, scoped.now_calls);
    assert_eq!(ordinary.inner.operations, scoped.inner.operations);
    assert_eq!(ordinary.inner.retired, [true; 2]);
    assert_eq!(scoped.inner.retired, [true; 2]);
    assert_eq!(ordinary.inner.poison_calls, 0);
    assert_eq!(scoped.inner.poison_calls, 0);
    assert_eq!(ordinary.sleeps, [Duration::from_micros(50)]);
    assert!(scoped.sleeps.is_empty());
    assert_eq!(ordinary.spins, 0);
    assert_eq!(scoped.spins, 0);
    assert_eq!(full.observed_queue_frontiers, warm.observed_queue_frontiers);
    assert_eq!(full.segment_host_ns, 50_000);
    assert_eq!(warm.segment_host_ns, 50_000);
}

#[test]
fn paired_pause_next_deadline_refuses_before_another_fence_poll_or_retirement() {
    for scoped in [false, true] {
        let mut fake = PausingFake::new(scoped);
        let deadline = fake.inner.clock + Duration::from_micros(50);
        assert!(coordinate_until(&mut fake, 10, Some(deadline)).is_err());
        assert_eq!(fake.inner.polls, 1);
        assert_eq!(fake.inner.retired, [false; 2]);
        assert_eq!(fake.inner.poison_calls, 1);
        assert_eq!(fake.inner.activation, [Activation::Poisoned; 2]);
        assert_eq!(
            &fake.inner.events[fake.inner.events.len() - 3..],
            ["poll", "pause", "poison"]
        );
    }
}

#[test]
fn paired_pause_preserves_original_before_and_after_effect_failure_traces() {
    let mut success = PausingFake::new(true);
    coordinate(&mut success, 10).unwrap();
    for ordinal in 1..=success.inner.operations {
        for after_effect in [false, true] {
            let mut ordinary = PausingFake::new(false);
            ordinary.inner.fail_at = ordinal;
            ordinary.inner.after_effect = after_effect;
            let mut scoped = PausingFake::new(true);
            scoped.inner.fail_at = ordinal;
            scoped.inner.after_effect = after_effect;
            assert!(coordinate(&mut ordinary, 10).is_err());
            assert!(coordinate(&mut scoped, 10).is_err());
            assert_eq!(ordinary.inner.events, scoped.inner.events);
            assert_eq!(ordinary.now_calls, scoped.now_calls);
            assert_eq!(ordinary.inner.published, scoped.inner.published);
            assert_eq!(ordinary.inner.retired, scoped.inner.retired);
            assert_eq!(ordinary.inner.poison_calls, 1);
            assert_eq!(scoped.inner.poison_calls, 1);
            assert_eq!(ordinary.inner.activation, [Activation::Poisoned; 2]);
            assert_eq!(scoped.inner.activation, [Activation::Poisoned; 2]);
        }
    }
}
