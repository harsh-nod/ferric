"""Format and seal a reviewed MI350 source map; never invoke Cargo or a GPU."""
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-active-pause-source-v228-v1")
BASE = dict(bytes=905626, sha256="672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a")
PREDECESSOR = dict(bytes=440584, sha256="937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f")
FEATURE = "engineering-currentness-duration-diagnostics"


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path, expected=None):
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_size <= 32 << 20, "bounded ordinary input")
    raw = path.read_bytes()
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stamp(before) == stamp(path.lstat()) and len(raw) == before.st_size, "input drift")
    require(expected is None or pin(raw) == expected, "input hash")
    return raw


def snapshot():
    result = {}
    for prefix in ("ferric", "fe2o3"):
        for directory, dirs, names in os.walk(ROOT / prefix, followlinks=False):
            require(not {".git", "target"} & set(dirs)
                    and all(not (Path(directory) / n).is_symlink() for n in dirs),
                    "source-only ordinary directories")
            for name in names:
                path = Path(directory) / name
                result[str(path.relative_to(ROOT))] = pin(read(path))
    require(2132 <= len(result) <= 2160
            and sum(row["bytes"] for row in result.values()) <= 64 << 20, "bounded source map")
    return result


def save(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as stream:
        stream.write(raw)
    require(read(path, pin(raw)) == raw, "original write rehash")
    return pin(raw)


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 3
            and re.fullmatch("v[1-9][0-9]*", sys.argv[1])
            and re.fullmatch("[0-9a-f]{64}", sys.argv[2]), "ATTEMPT REVIEW_SHA")
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == "smci350-rck-g03-b19-03", "exact unprivileged host")
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10
            and all(os.environ.get(k) == "" for k in
                    ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES")),
            "CPU8,9 nice10 hidden GPUs")
    require(shutil.disk_usage(ROOT).free >= 40 << 30, "initial storage floor")
    resource.setrlimit(resource.RLIMIT_AS, (512 << 20, 512 << 20))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 << 20, 32 << 20))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    out = ROOT / ("seal-" + sys.argv[1])
    require(not os.path.lexists(out) and not os.path.lexists(ROOT / "proposal.json"), "fresh seal attempt")
    review_raw = read(ROOT / ("source-review-input-" + sys.argv[1] + ".json"))
    require(pin(review_raw)["sha256"] == sys.argv[2], "reviewed input")
    review = json.loads(review_raw)
    require(set(review) == {"schema", "predecessor", "files", "overlay", "new_tests"}
            and review["schema"] == "ferric-active-pause-source-review-v1"
            and review["predecessor"] == PREDECESSOR, "closed review contract")
    predecessor_raw = read(ROOT / "predecessor-proposal.json", PREDECESSOR)
    predecessor = json.loads(predecessor_raw)
    base_raw = read(ROOT / "base-manifest.json", BASE)
    old = {n: {k: row[k] for k in ("bytes", "sha256")}
           for n, row in json.loads(base_raw)["sources"].items()}
    before = snapshot()
    overlay, tests = review["overlay"], review["new_tests"]
    require(before == review["files"] and set(predecessor["files"]) <= set(before)
            and set(old) <= set(before), "reviewed complete source map")
    require(overlay == sorted(n for n in before if before[n] != old.get(n))
            and 3 <= len(overlay) <= 48
            and all(n.endswith(".rs") and n.startswith((
                "fe2o3/crates/fe2o3-kfd/src/",
                "ferric/adapters/tp-peer-finite-engineering-worker-v1/",
                "ferric/adapters/m1-engineering-execution-v1/")) for n in overlay),
            "only reviewed Rust scope; locks unchanged")
    require(set(tests) == {"runtime", "worker", "parent"}, "three qualification roles")
    for role in tests:
        require(set(tests[role]) == {"default", "diagnostic"}, "feature-off/on rosters")
        for names in tests[role].values():
            require(names == sorted(set(names))
                    and all(re.fullmatch("[A-Za-z0-9_:]+", n) for n in names), "closed test names")
    base = ROOT.parent / "guarded-mlp-currentness-duration-diagnostic-cpu-v228-v2/evidence/complete.json"
    receipt = json.loads(read(base, dict(bytes=2569774, sha256="5a27b9983ecd0d523226cbf2db4070108cd6deaf75d2ee6fe528274d2f8a5ac2")))
    tool = receipt["tool_pins"]["rustfmt"]
    fmt = Path(tool["path"])
    tool_pin = {k: tool[k] for k in ("bytes", "sha256")}
    read(fmt, tool_pin)
    argv = [str(fmt), "--edition", "2024", "--config", "skip_children=true",
            *(str(ROOT / n) for n in overlay)]
    out.mkdir(mode=0o700)
    save(out / "source-preformat.json", before)
    save(out / "format-command.json", dict(argv=argv, timeout_seconds=120, affinity=[8, 9], nice=10, tool=tool))
    child, code, failure = None, None, None
    timed_out, cleanup_signalled, group_absent = False, False, True
    interrupted, cleanup_errors = [], []
    signals = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM)
    handlers = {number: signal.getsignal(number) for number in signals}
    def interrupted_by(number, _frame):
        # Record instead of raising across Popen's child-handle assignment.
        interrupted.append(number)
    def group_present():
        try:
            os.killpg(child.pid, 0)
            return True
        except ProcessLookupError:
            return False
    try:
        for number in signals:
            signal.signal(number, interrupted_by)
        with (out / "format.stdout").open("xb") as stdout, (out / "format.stderr").open("xb") as stderr:
            require(not interrupted, "interrupted before formatter spawn")
            child = subprocess.Popen(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            until = time.monotonic() + 120
            while True:
                require(not interrupted, "formatter interrupted")
                remaining = until - time.monotonic()
                if remaining <= 0:
                    timed_out = True
                    raise TimeoutError("formatter wall limit")
                try:
                    code = child.wait(timeout=min(0.25, remaining))
                    break
                except subprocess.TimeoutExpired:
                    pass
    except BaseException as error:
        failure = repr(error)
    finally:
        for number in signals:
            signal.signal(number, signal.SIG_IGN)
        if child is not None:
            try:
                if child.poll() is None or group_present():
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                        cleanup_signalled = True
                    except ProcessLookupError:
                        pass
                code = child.wait(timeout=5)
                cleanup_until = time.monotonic() + 5
                while group_present() and time.monotonic() < cleanup_until:
                    time.sleep(0.05)
                group_absent = not group_present()
            except BaseException as error:
                cleanup_errors.append(repr(error))
                group_absent = False
        for number, handler in handlers.items():
            signal.signal(number, handler)
    save(out / "format-result.json", dict(exit_code=code, timed_out=timed_out,
         failure=failure, interrupted_signals=interrupted, cleanup_errors=cleanup_errors,
         cleanup_signalled=cleanup_signalled, spawn_observed=child is not None,
         reaped=child is not None and child.returncode is not None,
         owned_group_absent=group_absent, stdout=pin(read(out / "format.stdout")),
         stderr=pin(read(out / "format.stderr"))))
    require(code == 0 and failure is None and not timed_out and not interrupted
            and not cleanup_signalled and not cleanup_errors and group_absent,
            "naturally retired formatter")
    after = snapshot()
    require(set(after) == set(before) and all(after[n] == before[n] for n in before if n not in overlay),
            "formatter scope")
    read(fmt, tool_pin)
    read(ROOT / ("source-review-input-" + sys.argv[1] + ".json"), pin(review_raw))
    read(ROOT / "predecessor-proposal.json", PREDECESSOR)
    require(shutil.disk_usage(ROOT).free >= 38 << 30, "final storage floor")
    proposal = dict(schema="ferric-readiness40-active-pause-source-v1", feature=FEATURE,
        files=after, overlay=overlay, new_tests=tests, base_manifest=BASE, predecessor=PREDECESSOR,
        review_input=pin(review_raw), source_preformat=pin(read(out / "source-preformat.json")),
        seal_attempt=sys.argv[1], formatted_paths=[n for n in overlay if before[n] != after[n]],
        runtime_source_changed=True, polling_pause_changed=True,
        currentness_policy_changed=False, kernel_math_changed=False,
        compiled=False, tests_executed=False, gpu_execution=False, native_admission=False,
        numerical_acceptance=False, performance_claim=False)
    result = save(ROOT / "proposal.json", proposal)
    print(json.dumps(dict(proposal=result, sources=len(after), overlay=len(overlay)), sort_keys=True))


if __name__ == "__main__":
    main()
