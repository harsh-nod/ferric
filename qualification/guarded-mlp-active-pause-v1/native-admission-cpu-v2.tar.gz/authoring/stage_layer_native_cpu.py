"""Stage active-pause workflow tests while retaining every predecessor case."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import sys

E = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220")
D = E / "guarded-mlp-active-pause-native-workflow-source-v228-v1"
OLD = E / "guarded-mlp-readiness40-tail-forward-duration-native-admission-cpu-v228-v1"
OLD_INPUT_SHA = "5d038bd4e54350dc131ce9883ce76315dd7369e0de2fa0f0d8c6a7ef89389a9c"
SUPERVISOR_SHA = "8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"
NEW = {"validate_layer.py", "test_layer.py", "test_forward.py", "layer_native_cpu_template.py",
       "layer_cpu_admission.py", "prepare_layer_model_inputs.py", "run_layer_model_gpu.py",
       "layer_retention_tool.py", "test_layer_cpu_admission.py", "test_layer_preparation.py",
       "test_layer_retention.py", "test_layer_cpu_usage.py"}
OLD_COUNTS = {"legacy-tests": 171, "forward-cpu-tests": 29,
              "forward-retention-tests": 12, "forward-preparation-tests": 15}
NEW_MODULES = {"layer-cpu-tests": "test_layer_cpu_admission",
               "layer-retention-tests": "test_layer_retention",
               "layer-preparation-tests": "test_layer_preparation",
               "usage-tests": "test_layer_cpu_usage"}
CHECKER = E / "guarded-mlp-readiness40-tail-layer-duration-checker-cpu-v228-v1"
CHECKER_INPUT_SHA = "11f6d54ddb6c8ed5bb8c07b61f4bdc6b1b64874788404cb15e3e825f5f419ecb"
CHECKER_TERMINAL = dict(path=str(CHECKER / "evidence/complete.json"), bytes=68280,
    sha256="bff2af1ddf5bfe3247e69f48595c51bf062c9dbc09af1bddd94a9384ba6026aa")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path, cap=16 << 20):
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_nlink == 1 and before.st_size <= cap, "bounded ordinary source")
    with path.open("rb") as stream:
        raw = stream.read(cap + 1)
        opened = os.fstat(stream.fileno())
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
                       s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stamp(before) == stamp(opened) == stamp(path.lstat())
            and len(raw) == before.st_size, "source changed during read")
    return raw


def names(raw, module):
    found = []
    for node in ast.parse(raw, filename=module).body:
        if isinstance(node, ast.ClassDef):
            found.extend(module + "." + node.name + "." + item.name for item in node.body
                         if isinstance(item, ast.FunctionDef) and item.name.startswith("test_"))
    require(len(found) == len(set(found)), "duplicate test definitions")
    return sorted(found)


def literals(raw, selected):
    result = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in selected:
                require(name not in result, "duplicate bound assignment")
                result[name] = ast.literal_eval(node.value)
    require(set(result) == set(selected), "complete literal binding set")
    return result


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 4
            and re.fullmatch("[0-9a-f]{64}", sys.argv[2])
            and re.fullmatch("[1-9][0-9]?", sys.argv[3]),
            "python3 -B stage_layer_native_cpu.py SEAL_PATH SEAL_SHA ATTEMPT")
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == "smci350-rck-g03-b19-03", "exact unprivileged host")
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10,
            "CPU8/9 nice10")
    require(all(os.environ.get(k) == "" for k in
                ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES")), "hidden GPUs")
    root = E / ("guarded-mlp-readiness40-tail-layer-active-pause-native-admission-cpu-v228-v" + sys.argv[3])
    require(not os.path.lexists(root) and shutil.disk_usage(E).free >= 40 << 30,
            "fresh output and initial storage floor")
    os.umask(0o077)
    for kind, cap in ((resource.RLIMIT_AS, 512 << 20), (resource.RLIMIT_CPU, 120),
                      (resource.RLIMIT_FSIZE, 16 << 20), (resource.RLIMIT_CORE, 0)):
        resource.setrlimit(kind, (cap, cap))
    signal.alarm(180)
    seal_path = Path(sys.argv[1])
    require(seal_path.is_absolute() and seal_path.parent == D, "authoring seal path")
    seal_raw = read(seal_path)
    require(pin(seal_raw)["sha256"] == sys.argv[2], "explicit reviewed seal")
    seal = json.loads(seal_raw)
    require(set(seal) == {"schema", "sources", "leaves"}
            and seal["schema"] == "ferric-active-pause-native-admission-source-seal-v1"
            and set(seal["sources"]) == NEW, "closed V2 seal")
    old_raw = read(OLD / "input-manifest.json")
    require(pin(old_raw)["sha256"] == OLD_INPUT_SHA, "qualified227 input ancestry")
    old = json.loads(old_raw)
    require(old["schema"] == "ferric-forward-native-admission-input-v1"
            and len(old["sources"]) == 364 and set(old["leaves"]) == set(OLD_COUNTS),
            "predecessor source and leaf census")
    bodies, readset = {}, {}
    for name, expected in old["sources"].items():
        relative = Path(name)
        require(not relative.is_absolute() and relative.as_posix() == name
                and all(part not in ("", ".", "..") for part in relative.parts),
                "safe predecessor source name")
        raw = read(OLD / name)
        require(pin(raw) == expected, "qualified source: " + name)
        readset[str(OLD / name)] = pin(raw)
        bodies["predecessor_run_cpu.py" if name == "run_cpu.py" else name] = raw
    for name in sorted(NEW):
        raw = read(D / name)
        require(pin(raw) == seal["sources"][name], "reviewed V2 source: " + name)
        destination = "run_cpu.py" if name == "layer_native_cpu_template.py" else name
        require(destination not in bodies, "new source does not replace predecessor")
        bodies[destination] = raw
        readset[str(D / name)] = pin(raw)
    bodies["active-pause-source-seal.json"] = seal_raw
    require(len(bodies) == 377 and sum(map(len, bodies.values())) <= 32 << 20
            and pin(bodies["supervisor.py"])["sha256"] == SUPERVISOR_SHA,
            "closed source packet and original supervisor")
    for name, raw in bodies.items():
        if name.endswith(".py"):
            ast.parse(raw, filename=name)
    leaves = dict(old["leaves"])
    for label, module in NEW_MODULES.items():
        observed = names(bodies[module + ".py"], module)
        require(0 < len(observed) <= 128, "bounded new test roster")
        leaves[label] = dict(directory=".", modules=[module], names=observed, count=len(observed))
    require(all(len(leaves[label]["names"]) == leaves[label]["count"] == count
                for label, count in OLD_COUNTS.items()) and leaves == seal["leaves"],
            "reviewed old and new exact test identities")
    for leaf in leaves.values():
        require(leaf["directory"] in (".", "legacy"), "fixed leaf namespace")
        prefix = "legacy/" if leaf["directory"] == "legacy" else ""
        actual = sorted(n for module in leaf["modules"]
                        for n in names(bodies[prefix + module + ".py"], module))
        require(actual == leaf["names"] and len(actual) == len(set(actual)), "unchanged test roster")
    combined = [n for leaf in leaves.values() for n in leaf["names"]]
    require(len(combined) == len(set(combined)), "disjoint leaf identities")
    # Native helper tests use the actually passed checker, never placeholder pins.
    checker_input = read(CHECKER / "input-manifest.json")
    require(pin(checker_input)["sha256"] == CHECKER_INPUT_SHA, "qualified checker input")
    checker = json.loads(checker_input)
    terminal_raw = read(Path(CHECKER_TERMINAL["path"]))
    require(pin(terminal_raw) == {k: CHECKER_TERMINAL[k] for k in ("bytes", "sha256")},
            "observed checker terminal")
    terminal = json.loads(terminal_raw)
    require(terminal["passed"] is True and terminal["failure"] is None
            and terminal["postcheck_errors"] == [] and terminal["tests"]["passed"] == 178,
            "passed checker before workflow qualification")
    runner = literals(bodies["run_layer_model_gpu.py"],
        ("CPU_ADMISSION_SHA", "LAYER_SHA", "FORWARD_SHA", "CHECKER_CPU", "CHECKER_TESTS",
         "CHECKER_CONTROLLER", "CHECKER_SOURCES", "PLAN_SHA"))
    preparer = literals(bodies["prepare_layer_model_inputs.py"], ("CPU_ADMISSION_SHA",))
    require(runner["CPU_ADMISSION_SHA"] == preparer["CPU_ADMISSION_SHA"]
            == pin(bodies["layer_cpu_admission.py"])["sha256"], "actual CPU helper binding")
    require(runner["LAYER_SHA"] == pin(bodies["validate_layer.py"])["sha256"]
            and runner["FORWARD_SHA"] == pin(bodies["validate_forward.py"])["sha256"],
            "qualified wire validator bindings")
    require(runner["CHECKER_CPU"] == CHECKER_TERMINAL and runner["CHECKER_TESTS"] == 178
            and runner["CHECKER_CONTROLLER"] == checker["sources"]["run_cpu.py"]
            and runner["CHECKER_SOURCES"] == {n: p for n, p in checker["sources"].items()
                                               if n not in ("run_cpu.py", "supervisor.py")}
            and runner["PLAN_SHA"] == {"tail_layer": None}, "actual checker and unbound native plan")
    for name, expected in checker["sources"].items():
        raw = read(CHECKER / name)
        require(pin(raw) == expected, "original qualified checker source")
        readset[str(CHECKER / name)] = pin(raw)
    readset[str(CHECKER / "input-manifest.json")] = pin(checker_input)
    readset[CHECKER_TERMINAL["path"]] = pin(terminal_raw)
    readset[str(OLD / "input-manifest.json")] = pin(old_raw)
    readset[str(seal_path)] = pin(seal_raw)
    self_path = Path(__file__).resolve()
    readset[str(self_path)] = pin(read(self_path))
    spec = dict(schema="ferric-active-pause-native-admission-input-v1", root=str(root),
                sources={name: pin(raw) for name, raw in sorted(bodies.items())}, leaves=leaves,
                predecessor_input=dict(path=str(OLD / "input-manifest.json"), **pin(old_raw)),
                source_seal=dict(path=str(seal_path), **pin(seal_raw)), authoring_readset=readset,
                source_files=len(bodies), total_tests=len(combined),
                leaf_order=[*OLD_COUNTS, *NEW_MODULES], original_fixture_files=152,
                fixture_copies=2, gpu_execution=False)
    input_raw = (json.dumps(spec, sort_keys=True, indent=2) + "\n").encode()
    require(len(input_raw) <= 1 << 20, "bounded staged manifest")
    for path, expected in readset.items():
        require(pin(read(Path(path))) == expected, "input drift before copying")
    root.mkdir(mode=0o700)
    for name, raw in bodies.items():
        (root / name).parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with (root / name).open("xb") as stream:
            stream.write(raw)
        require(read(root / name) == raw, "exact source copy")
    with (root / "input-manifest.json").open("xb") as stream:
        stream.write(input_raw)
    require(read(root / "input-manifest.json") == input_raw, "exact manifest copy")
    require(shutil.disk_usage(E).free >= 38 << 30, "final storage floor")
    signal.alarm(0)
    print(json.dumps(dict(root=str(root), input_manifest=pin(input_raw), sources=len(bodies),
                         legacy_tests=227, layer_tests=len(combined) - 227), sort_keys=True))


if __name__ == "__main__":
    main()
