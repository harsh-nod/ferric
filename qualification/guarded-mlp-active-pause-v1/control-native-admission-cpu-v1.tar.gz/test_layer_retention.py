"""Synthetic V2 layer retention workflows, not native observations.

The unchanged forward fixture first passes every original forward predicate.
These tests then derive a genuine V2 third record while retaining the exact
first two LF-inclusive records and all historical baseline bytes. Only fixture
data/source bindings change; validate, verify and retain are real entry points.
No model, native process or project executable runs here. Live-host export is
not exercised by these synthetic tests.
"""
import copy
from contextlib import contextmanager
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import layer_retention_tool as E
import test_forward_retention as H

old_fixture = H.old_fixture
DIRECTORY = Path(__file__).resolve().parent
FIXTURE_ROOT = Path('/synthetic/layer-phase-retention-only')
CASE = 'tail_layer'
FLAGS = dict(forward_phase_durations=True, currentness_durations_nested=True,
             disjoint_forward_phases=True, layer_phase_durations=True,
             paired_mlp_durations_nested=True, polling_pause_changed=False)
PHASES = ['input', 'metadata', 'embedding', 'bank', 'layers', 'tail', 'frame', 'fence', 'commit']
LAYER_STAGES = ['enter_pre_census', 'prefix', 'mlp_retired_seal',
                'hidden_post_census', 'full_exit', 'commit_prepare']
PAIRED_STAGES = ['preflight', 'consume', 'reserve', 'publish', 'poll', 'retire', 'terminal']
encoded = old_fixture.encoded
identity = old_fixture.identity
file_pin = old_fixture.file_pin


@contextmanager
def bindings(fixture):
    # Only declarative fixture identities; no acceptance predicate is replaced.
    with patch.multiple(E, REMOTE=FIXTURE_ROOT, ROOT_PINS=fixture['root_pins'],
                        ADMISSION=fixture['admission'], CHECKER=fixture['checker']):
        yield


@contextmanager
def fixture_helpers():
    with patch.multiple(old_fixture, E=E, CASE=CASE, FIXTURE_ROOT=FIXTURE_ROOT):
        yield


def update_native(fixture, stderr=None, edit_summary=None):
    with fixture_helpers():
        old_fixture.update_native(fixture, stderr, edit_summary)


def reconcile(fixture):
    with fixture_helpers():
        old_fixture.reconcile(fixture)


def synthetic_layer(first, second):
    base = H.synthetic_forward(first, second)
    callbacks = json.loads(second)
    rows = []
    for row, callback in zip(base['forwards'], callbacks['forwards']):
        metrics = None
        if row['position'] >= 2:
            subtotal = sum(value['elapsed_ns'] for value in callback['measured']['layers'].values())
            stages = [subtotal, 1, 7, 1, 1, 1]
            metrics = dict(layers=36, phase_ns=stages, layer_body_ns=sum(stages),
                paired_mlp_phase_ns=[1] * 7, paired_mlp_body_ns=7)
            row['phase_ns'][4] = metrics['layer_body_ns'] + 1
            row['forward_body_ns'] = sum(row['phase_ns'])
        rows.append(dict(position=row['position'], phase_ns=row['phase_ns'],
                         forward_body_ns=row['forward_body_ns'], layer_metrics=metrics))
    return dict(schema='FerricReadiness40ForwardLayerDurationsV2', instrumented=True,
        policy_sha256=base['policy_sha256'], currentness_record_sha256=base['currentness_record_sha256'],
        session=base['session'], worker_sha256=base['worker_sha256'],
        transcript_sha256=base['transcript_sha256'], phase_order=list(PHASES),
        layer_stage_order=list(LAYER_STAGES), paired_mlp_stage_order=list(PAIRED_STAGES),
        forwards=rows, host_elapsed_nanoseconds=True, disjoint_phases=True,
        currentness_durations_nested=True, layer_durations_nested=True,
        paired_mlp_durations_nested=True, gpu_timing=False, numerical_acceptance=False,
        performance_claim=False, execution_authority=False)



def synthetic_children_rusage():
    """Fixed synthetic cumulative counters, not a native measurement."""
    return dict(who='RUSAGE_CHILDREN',
        before=dict(ru_utime=12.5, ru_stime=3.25, ru_nvcsw=100, ru_nivcsw=20,
                    ru_minflt=300, ru_majflt=4),
        after=dict(ru_utime=13.75, ru_stime=3.75, ru_nvcsw=109, ru_nivcsw=22,
                   ru_minflt=317, ru_majflt=5),
        delta=dict(ru_utime=1.25, ru_stime=0.5, ru_nvcsw=9, ru_nivcsw=2,
                   ru_minflt=17, ru_majflt=1), error=None)


def make_fixture():
    prior = H.make_fixture()
    with H.bindings(prior):
        if H.E.verify(prior['bodies'], prior['outcomes'])['passed'] is not True:
            raise AssertionError('forward fixture must pass unchanged original predicates')
    old_root = str(H.FIXTURE_ROOT)
    replacements = [
        (old_root + '/run_model_gpu.py', str(FIXTURE_ROOT / 'run_layer_model_gpu.py')),
        (old_root + '/prepare_model_inputs.py', str(FIXTURE_ROOT / 'prepare_layer_model_inputs.py')),
        (old_root + '/forward_cpu_admission.py', str(FIXTURE_ROOT / 'layer_cpu_admission.py')),
        (old_root + '/tail_forward/', str(FIXTURE_ROOT / CASE) + '/'),
        (old_root + '/tail_forward-', str(FIXTURE_ROOT / (CASE + '-'))),
        (old_root, str(FIXTURE_ROOT)),
        (str(H.E.WORKER_ROOT), str(E.WORKER_ROOT)),
        (str(H.E.PARENT_ROOT), str(E.PARENT_ROOT)),
        ('ferric-guarded-mlp-readiness40-tail-forward-duration-',
         'ferric-guarded-mlp-readiness40-tail-layer-active-pause-control-'),
        ('bank_scoped_census_tail_forward', 'bank_scoped_census_tail_layer'),
        ('tail_forward', CASE),
    ]
    bodies = {}
    for name, raw in prior['bodies'].items():
        if name.startswith('baseline/'):
            bodies[name] = raw
            continue
        if name.endswith('.py'):
            continue
        target = name.replace('tail_forward', CASE)
        if name.endswith('.json') or name == 'tail_forward/parent/stdout':
            raw = encoded(old_fixture.rewrite(json.loads(raw), replacements))
        bodies[target] = raw
    for name in E.ROOT_PINS:
        if name.endswith('.py'):
            bodies[name] = (DIRECTORY / name).read_bytes()
    bodies['layer_retention_tool.py'] = Path(E.__file__).resolve().read_bytes()
    terminal = old_fixture.rewrite(prior['terminal'], replacements)
    terminal.update(FLAGS)
    next(row for row in terminal['phases'] if row['label'] == 'parent')['children_rusage'] = synthetic_children_rusage()
    terminal['controller'] = file_pin(FIXTURE_ROOT / 'run_layer_model_gpu.py',
                                       bodies['run_layer_model_gpu.py'])
    prepared = json.loads(bodies['prepared-inputs.json'])
    prepared.update(FLAGS)
    prepared['controller'] = file_pin(FIXTURE_ROOT / 'prepare_layer_model_inputs.py',
                                      bodies['prepare_layer_model_inputs.py'])
    plan_name = CASE + '-input.json'
    plan = json.loads(bodies[plan_name])
    plan['polling_pause_changed'] = False
    # Synthetic metadata pins are not actual qualification receipts or outcomes.
    for name, leaf in (('runtime_cpu', 'complete.json'), ('runtime_sources', 'sources-after.json')):
        row = file_pin(E.RUNTIME_ROOT / 'evidence' / leaf,
                       ('synthetic layer fixture metadata only: ' + name + '\n').encode())
        plan[name] = row
        terminal['admission'][name] = copy.deepcopy(row)
        terminal['readset'][row['path']] = copy.deepcopy(row)
    prepared['runtime_cpu'] = copy.deepcopy(plan['runtime_cpu'])
    plan['request'] = file_pin(FIXTURE_ROOT / (CASE + '-request.json'),
                               bodies[CASE + '-request.json'])
    bodies[plan_name] = encoded(plan)
    terminal['plan'] = file_pin(FIXTURE_ROOT / plan_name, bodies[plan_name])
    prepared['plans'] = {CASE: terminal['plan']}
    prepared['requests'] = {CASE: plan['request']}
    bodies['prepared-inputs.json'] = encoded(prepared)
    root_pins = {name: identity(bodies[name]) for name in E.ROOT_PINS}
    terminal['readset'] = {path: value for path, value in terminal['readset'].items()
                           if not path.startswith(str(FIXTURE_ROOT) + '/')}
    for name in root_pins:
        if ((name.endswith('.py') and name != 'prepare_layer_model_inputs.py')
                or name in (plan_name, CASE + '-request.json')):
            row = file_pin(FIXTURE_ROOT / name, bodies[name])
            terminal['readset'][row['path']] = row
    fixture = dict(bodies=bodies, terminal=terminal, root_pins=root_pins,
        admission={key: E.compact(value) for key, value in terminal['admission'].items()},
        checker=copy.deepcopy(terminal['checker_cpu']))
    lines = bodies[CASE + '/native/child-stderr.bin'].splitlines(keepends=True)
    if len(lines) != 3 or any(not line.endswith(b'\n') for line in lines):
        raise AssertionError('unchanged canonical three-record forward fixture')
    prefix = lines[0] + lines[1]
    third = encoded(synthetic_layer(lines[0], lines[1])) + b'\n'
    update_native(fixture, prefix + third)
    with bindings(fixture):
        *_, layer = E.validation_modules(bodies)
        summary_raw = bodies[CASE + '/native/complete.json']
        summary = json.loads(summary_raw)
        request = json.loads(bodies[CASE + '-request.json'])
        read_body = lambda row: E.native_body(bodies, row)
        checked = layer.validate(CASE, bodies[CASE + '/parent/stdout'], summary_raw,
            request, FIXTURE_ROOT / CASE / 'native', read_body,
            summary['bootstrap']['sequence']['prompt_tokens'])
        baseline_raw, baseline_checked = E.verify_baseline(bodies, None)
        parity = layer.compare_same_side(summary_raw, baseline_raw, checked, baseline_checked, read_body)
    terminal.update(observation=checked['ordinary'], matched_timing=checked, same_side_parity=parity)
    for name, value in (('observation.json', checked['ordinary']),
                        ('matched.json', checked), ('parity.json', parity)):
        bodies[CASE + '/' + name] = encoded(value)
    reconcile(fixture)
    fixture['original_prefix'] = prefix
    fixture['original_forward_third'] = lines[2]
    fixture['baseline_originals'] = {n: raw for n, raw in prior['bodies'].items() if n.startswith('baseline/')}
    return fixture


def write_archive(path, fixture, observation, extra=None):
    bodies = dict(fixture['bodies'])
    manifest = dict(schema='ferric-guarded-mlp-readiness40-tail-layer-active-pause-control-retention-v1',
        source_root=str(FIXTURE_ROOT), files={name: identity(raw) for name, raw in sorted(bodies.items())},
        observation=observation, outcomes=fixture['outcomes'])
    bodies['manifest.json'] = encoded(manifest)
    with tarfile.open(path, 'w:gz', format=tarfile.USTAR_FORMAT) as tar:
        for name, raw in sorted(bodies.items()):
            row = tarfile.TarInfo(name); row.size = len(raw); row.mode = 0o600
            tar.addfile(row, io.BytesIO(raw))
        if extra is not None:
            row = tarfile.TarInfo(extra); row.size = 0
            tar.addfile(row, io.BytesIO(b''))
    return identity(path.read_bytes())['sha256'], bodies


class LayerRetentionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = make_fixture()
        with bindings(cls.fixture):
            checked = E.verify(cls.fixture['bodies'], cls.fixture['outcomes'])
        if not checked['passed']:
            raise AssertionError('positive fixture must pass every new retention predicate')

    def fresh(self):
        return copy.deepcopy(self.fixture)

    def verify(self, fixture):
        with bindings(fixture):
            return E.verify(fixture['bodies'], fixture['outcomes'])

    def roundtrip(self, fixture):
        observation = self.verify(fixture)
        with tempfile.TemporaryDirectory(prefix='synthetic-layer-retention-') as directory:
            archive = Path(directory) / 'fixture.tar.gz'
            destination = Path(directory) / 'retained'
            sha, expected = write_archive(archive, fixture, observation)
            with bindings(fixture):
                got = E.retain(archive, sha, destination)
            self.assertEqual(got['members'], len(expected))
            self.assertEqual(got['cases'], observation['cases'])
            self.assertEqual(got['passed'], observation['passed'])
            self.assertEqual({p.relative_to(destination).as_posix(): p.read_bytes()
                              for p in destination.rglob('*') if p.is_file()}, expected)
        return observation

    def test_layer_complete_verify_retain_preserves_three_original_records(self):
        fixture = self.fresh()
        raw = fixture['bodies'][CASE + '/native/child-stderr.bin']
        got = self.roundtrip(fixture)
        self.assertTrue(raw.startswith(fixture['original_prefix']))
        self.assertEqual(len(raw.splitlines()), 3)
        self.assertEqual((got['selected_original_bodies'], got['raw_files']), (169, 73))
        checked = got['cases'][CASE]['matched_timing']
        self.assertEqual(checked['policy']['file']['sha256'], identity(raw)['sha256'])
        self.assertEqual(checked['policy']['file']['bytes'], len(raw))
        self.assertEqual(checked['timing']['disjoint_spans'], 124)
        self.assertEqual(len(checked['policy']['forward_record']['forwards']), 40)
        self.assertEqual({key: got[key] for key in FLAGS}, FLAGS)
        self.assertFalse(got['native_rerun'] or got['gpu_execution']
                         or got['numerical_acceptance'] or got['performance_claim'])

    def test_layer_failed_prefix_remains_failed_after_retain(self):
        fixture = self.fresh(); terminal = fixture['terminal']
        labels = {'parent-readelf', 'after-0', 'after-1', 'after-2'}
        terminal['phases'] = [row for row in terminal['phases'] if row['label'] in labels]
        terminal['phases'][0]['exit_code'] = 101
        terminal.update(passed=False, errors=['synthetic layer prelaunch failure'], native_attempts=0,
            observation=None, matched_timing=None, same_side_parity=None, owned_worker_lineage_verified=False,
            native_spawn_observed=False, gpu_execution_requested=False, gpu_execution=False,
            gpu_execution_confirmed=False, partial_gpu_execution_possible=False,
            model_source_authenticated_by_qualified_parent=False)
        keep = {'initial-topology.json'} | {name + '-topology.json' for name in labels if name.startswith('after-')}
        keep |= {label + '/' + name for label in labels
                 for name in ('command.json', 'started.json', 'stdout', 'stderr', 'result.json')}
        fixture['bodies'] = {name: raw for name, raw in fixture['bodies'].items()
                            if not name.startswith(CASE + '/') or name[len(CASE) + 1:] in keep}
        reconcile(fixture)
        got = self.roundtrip(fixture)
        self.assertFalse(got['passed'] or got['original_owned_lineage_revalidated'])
        self.assertEqual(got['raw_files'], 24)
        self.assertEqual(got['cases'][CASE]['original_terminal']['name'], 'failed.json')

    def test_layer_late_failure_keeps_all_raw_without_success_promotion(self):
        fixture = self.fresh()
        fixture['terminal'].update(passed=False, errors=['synthetic layer posthash refusal'])
        reconcile(fixture)
        got = self.roundtrip(fixture)
        self.assertFalse(got['passed'] or got['cases'][CASE]['retained_success_revalidated'])
        self.assertEqual(got['raw_files'], 73)

    def test_layer_absent_case_has_no_invented_terminal(self):
        fixture = self.fresh()
        fixture['bodies'] = {name: raw for name, raw in fixture['bodies'].items()
                            if not name.startswith(CASE + '/')}
        fixture['outcomes'] = {CASE: None}
        got = self.roundtrip(fixture)
        self.assertEqual((got['selected_original_bodies'], got['raw_files']), (95, 0))
        self.assertFalse(got['passed'] or got['cases'][CASE]['present'])
        self.assertIsNone(got['cases'][CASE]['original_terminal'])

    def test_layer_requires_third_record_and_canonical_order(self):
        for mutation in ('two', 'duplicate', 'reordered', 'extra'):
            fixture = self.fresh()
            lines = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines(keepends=True)
            changed = (lines[:2] if mutation == 'two' else
                       lines + [lines[2]] if mutation == 'duplicate' else
                       [lines[0], lines[2], lines[1]] if mutation == 'reordered' else lines + [b'\n'])
            update_native(fixture, b''.join(changed)); reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_third_identity_and_scope_mutations_reach_real_validator(self):
        for key in ('policy_sha256', 'currentness_record_sha256', 'worker_sha256',
                    'transcript_sha256', 'disjoint_phases', 'performance_claim'):
            fixture = self.fresh()
            first, second, third = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines()
            record = json.loads(third)
            if type(record[key]) is list:
                record[key][0] ^= 1
            else:
                record[key] = not record[key]
            update_native(fixture, first + b'\n' + second + b'\n' + encoded(record) + b'\n')
            reconcile(fixture)
            with self.subTest(key=key), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_rows_sum_and_nested_callback_containment_are_checked(self):
        for mutation in ('position', 'sum', 'bank', 'layers', 'tail'):
            fixture = self.fresh()
            first, second, third = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines()
            record = json.loads(third); row = record['forwards'][2]
            if mutation == 'position':
                row['position'] = 1
            elif mutation == 'sum':
                row['forward_body_ns'] += 1
            else:
                row['phase_ns'][{'bank': 3, 'layers': 4, 'tail': 5}[mutation]] = 0
                row['forward_body_ns'] = sum(row['phase_ns'])
            update_native(fixture, first + b'\n' + second + b'\n' + encoded(record) + b'\n')
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_whole_stderr_pin_cannot_be_replaced_by_prefix_pin(self):
        fixture = self.fresh()
        def truncate_pin(summary):
            summary['files']['child_stderr'] = file_pin(
                FIXTURE_ROOT / CASE / 'native/child-stderr.bin', fixture['original_prefix'], True)
        update_native(fixture, edit_summary=truncate_pin); reconcile(fixture)
        with self.assertRaises((RuntimeError, ValueError)):
            self.verify(fixture)

    def test_layer_healthy_close_owned_lineage_and_capture_custody_remain_real(self):
        for mutation in ('close', 'lineage', 'capture'):
            fixture = self.fresh()
            if mutation == 'close':
                update_native(fixture, edit_summary=lambda value: value.update(native_closed=False))
            elif mutation == 'lineage':
                parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
                parent['lineage'][1]['identity']['ppid'] += 1
            else:
                fixture['bodies'][CASE + '/native/capture-5.bin'] += b'\0'
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_closed_sources_require_both_new_helpers_and_old_duration(self):
        for name in ('validate_layer.py', 'layer_cpu_admission.py', 'validate_forward.py', 'validate_duration.py'):
            for mutation in ('missing', 'changed', 'readset'):
                fixture = self.fresh()
                if mutation == 'missing':
                    fixture['bodies'].pop(name)
                elif mutation == 'changed':
                    fixture['bodies'][name] += b'\n'
                else:
                    fixture['terminal']['readset'].pop(str(FIXTURE_ROOT / name))
                    reconcile(fixture)
                with self.subTest(name=name, mutation=mutation), self.assertRaises(RuntimeError):
                    self.verify(fixture)

    def test_layer_mode_flags_source_maps_and_outcome_custody_are_closed(self):
        for mutation in ('old_mode', 'flag', 'runtime_sources', 'worker_sources', 'parent_sources', 'terminal_sha', 'extra'):
            fixture = self.fresh()
            if mutation == 'old_mode':
                fixture['terminal']['case'] = 'tail_forward'
            elif mutation == 'flag':
                fixture['terminal']['layer_phase_durations'] = False
            elif mutation.endswith('_sources'):
                row = fixture['terminal']['admission'][mutation]
                fixture['terminal']['readset'][row['path']] = dict(row, sha256='0' * 64)
            elif mutation == 'extra':
                fixture['bodies'][CASE + '/unlisted.txt'] = b'synthetic only'
            reconcile(fixture)
            if mutation == 'terminal_sha':
                fixture['outcomes'][CASE]['sha256'] = '0' * 64
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                self.verify(fixture)

    def test_layer_retain_refuses_hash_duplicate_escape_and_observation_drift(self):
        fixture = self.fresh(); observation = self.verify(fixture)
        with tempfile.TemporaryDirectory(prefix='synthetic-layer-refusal-') as directory:
            root = Path(directory)
            for mutation in ('sha', 'duplicate', 'escape', 'observation'):
                archive = root / (mutation + '.tar.gz')
                changed = copy.deepcopy(observation)
                if mutation == 'observation':
                    changed['forward_phase_durations'] = False
                extra = 'prepared-inputs.json' if mutation == 'duplicate' else '../outside' if mutation == 'escape' else None
                sha, _ = write_archive(archive, fixture, changed, extra)
                if mutation == 'sha':
                    sha = '0' * 64
                destination = root / (mutation + '-retained')
                with self.subTest(mutation=mutation), bindings(fixture), self.assertRaises(RuntimeError):
                    E.retain(archive, sha, destination)
                self.assertFalse(destination.exists())


    def mutate_record(self, fixture, change):
        first, second, third = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines()
        record = json.loads(third)
        change(record)
        update_native(fixture, first + b'\n' + second + b'\n' + encoded(record) + b'\n')
        reconcile(fixture)

    def test_layer_v1_third_record_is_not_relabelled_or_admitted(self):
        fixture = self.fresh()
        update_native(fixture, fixture['original_prefix'] + fixture['original_forward_third'])
        reconcile(fixture)
        with self.assertRaises((RuntimeError, ValueError)):
            self.verify(fixture)

    def test_layer_nested_stage_orders_counts_and_nullability_are_closed(self):
        for mutation in ('layer_order', 'paired_order', 'layers', 'first_use', 'warm_null',
                         'layer_width', 'paired_width', 'bool', 'overflow', 'sum'):
            fixture = self.fresh()
            def change(record):
                metrics = record['forwards'][2]['layer_metrics']
                if mutation == 'layer_order':
                    record['layer_stage_order'].reverse()
                elif mutation == 'paired_order':
                    record['paired_mlp_stage_order'].reverse()
                elif mutation == 'layers':
                    metrics['layers'] = 35
                elif mutation == 'first_use':
                    record['forwards'][0]['layer_metrics'] = copy.deepcopy(metrics)
                elif mutation == 'warm_null':
                    record['forwards'][2]['layer_metrics'] = None
                elif mutation == 'layer_width':
                    metrics['phase_ns'].pop()
                elif mutation == 'paired_width':
                    metrics['paired_mlp_phase_ns'].append(0)
                elif mutation == 'bool':
                    metrics['phase_ns'][0] = True
                elif mutation == 'overflow':
                    metrics['phase_ns'][0] = 1 << 64
                else:
                    metrics['layer_body_ns'] += 1
            self.mutate_record(fixture, change)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_nested_body_containment_refuses_repinned_originals(self):
        for mutation in ('paired_sum', 'paired_escape', 'callback_escape', 'outer_escape'):
            fixture = self.fresh()
            def change(record):
                row = record['forwards'][2]; metrics = row['layer_metrics']
                if mutation == 'paired_sum':
                    metrics['paired_mlp_body_ns'] += 1
                elif mutation == 'paired_escape':
                    metrics['paired_mlp_phase_ns'][0] += 1
                    metrics['paired_mlp_body_ns'] += 1
                elif mutation == 'callback_escape':
                    metrics.update(phase_ns=[0] * 6, layer_body_ns=0,
                                   paired_mlp_phase_ns=[0] * 7, paired_mlp_body_ns=0)
                else:
                    row['phase_ns'][4] = metrics['layer_body_ns'] - 1
                    row['forward_body_ns'] = sum(row['phase_ns'])
            self.mutate_record(fixture, change)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_layer_runtime_admission_and_prepared_receipt_are_required(self):
        for mutation in ('missing', 'pin', 'path', 'prepared'):
            fixture = self.fresh()
            if mutation == 'missing':
                fixture['terminal']['admission'].pop('runtime_cpu')
            elif mutation == 'pin':
                fixture['terminal']['admission']['runtime_cpu']['sha256'] = '0' * 64
            elif mutation == 'path':
                fixture['terminal']['admission']['runtime_cpu']['path'] += '.other'
            else:
                prepared = json.loads(fixture['bodies']['prepared-inputs.json'])
                prepared['runtime_cpu']['sha256'] = '0' * 64
                fixture['bodies']['prepared-inputs.json'] = encoded(prepared)
                fixture['root_pins']['prepared-inputs.json'] = identity(fixture['bodies']['prepared-inputs.json'])
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                self.verify(fixture)


    def test_active_pause_usage_roundtrip_preserves_current_result_and_historical_bytes(self):
        fixture = self.fresh()
        parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
        self.assertEqual(parent['children_rusage'], synthetic_children_rusage())
        self.assertEqual(json.loads(fixture['bodies'][CASE + '/parent/result.json'])['children_rusage'],
                         parent['children_rusage'])
        self.assertEqual({n: raw for n, raw in fixture['bodies'].items() if n.startswith('baseline/')},
                         fixture['baseline_originals'])
        self.assertEqual(len(fixture['baseline_originals']), 73)
        self.assertTrue(self.roundtrip(fixture)['passed'])

    def test_active_pause_usage_is_required_and_closed_on_current_parent(self):
        for mutation in ('missing', 'null', 'list', 'scope', 'extra', 'missing_before'):
            fixture = self.fresh()
            parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
            if mutation == 'missing':
                del parent['children_rusage']
            elif mutation == 'null':
                parent['children_rusage'] = None
            elif mutation == 'list':
                parent['children_rusage'] = []
            elif mutation == 'scope':
                parent['children_rusage']['who'] = 'RUSAGE_SELF'
            elif mutation == 'extra':
                parent['children_rusage']['ru_maxrss'] = 1
            else:
                del parent['children_rusage']['before']
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                self.verify(fixture)

    def test_active_pause_usage_snapshot_types_and_nonnegative_values_are_independent(self):
        for side in ('before', 'after'):
            for field, wrong in (('ru_utime', 1), ('ru_stime', '1.0'), ('ru_utime', -1.0),
                                 ('ru_nvcsw', True), ('ru_nivcsw', 1.5), ('ru_minflt', -1), ('ru_majflt', None)):
                fixture = self.fresh()
                parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
                parent['children_rusage'][side][field] = wrong
                reconcile(fixture)
                with self.subTest(side=side, field=field, wrong=wrong), self.assertRaises(RuntimeError):
                    self.verify(fixture)

    def test_active_pause_usage_delta_is_recomputed_from_monotone_raw_snapshots(self):
        for field in synthetic_children_rusage()['delta']:
            for mutation in ('value', 'type', 'decrease'):
                fixture = self.fresh()
                parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
                usage = parent['children_rusage']
                if mutation == 'value':
                    usage['delta'][field] += 1
                elif mutation == 'type':
                    usage['delta'][field] = True
                else:
                    usage['after'][field] = usage['before'][field] - 1
                    usage['delta'][field] = -1.0 if field in ('ru_utime', 'ru_stime') else -1
                reconcile(fixture)
                with self.subTest(field=field, mutation=mutation), self.assertRaises(RuntimeError):
                    self.verify(fixture)

    def test_active_pause_success_cannot_hide_sampling_error_or_missing_delta(self):
        for mutation in ('error', 'missing_delta', 'partial', 'false_error'):
            fixture = self.fresh()
            parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
            usage = parent['children_rusage']
            if mutation == 'error':
                usage.update(error='synthetic failure', delta=None)
            elif mutation == 'missing_delta':
                usage['delta'] = None
            elif mutation == 'partial':
                usage.update(after=None, delta=None, error='synthetic missing after')
            else:
                usage['error'] = False
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                self.verify(fixture)

    def test_active_pause_after_sampling_failure_retains_failed_owned_phase_without_promotion(self):
        fixture = self.fresh()
        terminal = fixture['terminal']
        parent = next(row for row in terminal['phases'] if row['label'] == 'parent')
        parent['children_rusage'].update(after=None, delta=None,
            error='after child CPU usage: synthetic OSError')
        parent['reason'] = parent['children_rusage']['error']
        terminal.update(passed=False, errors=['synthetic after-sampling refusal'],
            observation=None, matched_timing=None, same_side_parity=None,
            owned_worker_lineage_verified=False, gpu_execution=False, gpu_execution_confirmed=False,
            partial_gpu_execution_possible=True, model_source_authenticated_by_qualified_parent=False)
        for name in ('observation.json', 'matched.json', 'parity.json'):
            fixture['bodies'].pop(CASE + '/' + name)
        reconcile(fixture)
        expected = copy.deepcopy(parent['children_rusage'])
        got = self.roundtrip(fixture)
        self.assertFalse(got['passed'] or got['cases'][CASE]['retained_success_revalidated'])
        self.assertEqual(got['cases'][CASE]['original_terminal']['name'], 'failed.json')
        self.assertEqual(got['raw_files'], 70)
        self.assertEqual(json.loads(fixture['bodies'][CASE + '/parent/result.json'])['children_rusage'], expected)
        self.assertEqual(parent['exit_code'], 0)
        self.assertTrue(parent['owned_processes_reaped'] and parent['owned_groups_absent'])

    def test_active_pause_usage_on_any_audit_phase_is_rejected(self):
        for label in E.LABELS:
            if label == 'parent':
                continue
            fixture = self.fresh()
            row = next(row for row in fixture['terminal']['phases'] if row['label'] == label)
            row['children_rusage'] = synthetic_children_rusage()
            reconcile(fixture)
            with self.subTest(label=label), self.assertRaisesRegex(RuntimeError, 'only covers the native parent'):
                self.verify(fixture)

    def test_active_pause_usage_original_result_cannot_diverge_from_terminal_phase(self):
        fixture = self.fresh()
        parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
        parent['children_rusage']['delta']['ru_utime'] += 1.0
        reconcile(fixture)
        name = CASE + '/parent/result.json'
        result = json.loads(fixture['bodies'][name])
        result['children_rusage'] = synthetic_children_rusage()
        fixture['bodies'][name] = encoded(result)
        fixture['terminal']['raw']['parent/result.json'] = file_pin(FIXTURE_ROOT / name, fixture['bodies'][name])
        terminal_body = encoded(fixture['terminal'])
        fixture['bodies'][CASE + '/complete.json'] = terminal_body
        fixture['outcomes'][CASE] = dict(name='complete.json', sha256=identity(terminal_body)['sha256'])
        with self.assertRaisesRegex(RuntimeError, 'phase original result'):
            self.verify(fixture)



    def test_control_retention_requires_false_flag_in_every_current_envelope(self):
        observation = self.verify(self.fixture)
        for owner in ('terminal', 'plan', 'prepared', 'absent_plan'):
            for mutation in ('opposite', 'numeric_alias', 'missing'):
                fixture = self.fresh()
                def change(value):
                    if mutation == 'missing':
                        value.pop('polling_pause_changed')
                    else:
                        value['polling_pause_changed'] = True if mutation == 'opposite' else 0
                if owner == 'terminal':
                    change(fixture['terminal'])
                else:
                    prepared = json.loads(fixture['bodies']['prepared-inputs.json'])
                    if owner == 'prepared':
                        change(prepared)
                    else:
                        name = CASE + '-input.json'
                        plan = json.loads(fixture['bodies'][name])
                        change(plan)
                        fixture['bodies'][name] = encoded(plan)
                        fixture['root_pins'][name] = identity(fixture['bodies'][name])
                        changed = file_pin(FIXTURE_ROOT / name, fixture['bodies'][name])
                        fixture['terminal']['plan'] = changed
                        fixture['terminal']['readset'][changed['path']] = changed
                        prepared['plans'][CASE] = changed
                    fixture['bodies']['prepared-inputs.json'] = encoded(prepared)
                    fixture['root_pins']['prepared-inputs.json'] = identity(fixture['bodies']['prepared-inputs.json'])
                reconcile(fixture)
                if owner == 'absent_plan':
                    fixture['bodies'] = {name: body for name, body in fixture['bodies'].items()
                                         if not name.startswith(CASE + '/')}
                    fixture['outcomes'] = {CASE: None}
                with self.subTest(owner=owner, mutation=mutation):
                    with self.assertRaises((RuntimeError, KeyError)):
                        self.verify(fixture)
                    if mutation == 'opposite':
                        with tempfile.TemporaryDirectory(prefix='synthetic-pause-flag-refusal-') as directory:
                            root = Path(directory)
                            archive, destination = root / 'fixture.tar.gz', root / 'retained'
                            sha, _ = write_archive(archive, fixture, observation)
                            with bindings(fixture), self.assertRaises((RuntimeError, KeyError)):
                                E.retain(archive, sha, destination)
                            self.assertFalse(destination.exists())


if __name__ == '__main__':
    unittest.main()
