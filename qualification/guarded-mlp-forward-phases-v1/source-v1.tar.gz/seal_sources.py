"""Seal the reviewed remote Rust overlay after bounded formatting, without Cargo."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess

ROOT = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-forward-phases-source-v228-v1")
OVERLAY = [
  "ferric/adapters/m1-engineering-execution-v1/src/lib.rs",
  "ferric/adapters/m1-engineering-execution-v1/src/tp_finite_client/long/readiness_bank_scoped_census_tail.rs",
  "ferric/adapters/m1-engineering-execution-v1/src/tp_finite_client/long/readiness_bank_scoped_census_tail_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/finite_guarded_mlp_readiness_forward_durations_v1.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/finite_guarded_mlp_readiness_forward_durations_v1_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/guarded_mlp_long_sequence_v2.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/guarded_mlp_long_sequence_v2_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/guarded_mlp_long_sequence_v2_timing.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/guarded_mlp_long_sequence_v2_timing_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/lib.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/native_guarded_mlp_readiness_cli_v1.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/native_guarded_mlp_readiness_cli_v1_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/native_guarded_mlp_readiness_duration_v1.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/native_guarded_mlp_readiness_duration_v1_tests.rs",
  "ferric/adapters/tp-peer-finite-engineering-worker-v1/src/native_guarded_mlp_readiness_v1.rs"
]
TESTS = {
  "worker": {
    "default": [],
    "diagnostic": [
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_allows_zero_elapsed_without_inventing_zero_callback_calls",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_authenticates_exact_lf_inclusive_callback_record",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_each_nested_scope_without_double_counting",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_exact_sum_overflow_position_and_row_bound",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_whole_case_sum_not_only_individual_bounds",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_does_not_launder_invalid_original_callback_counts",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_does_not_replace_original_policy_or_two_record_admission",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_fixture_rows_and_record_cannot_alias_original_callback_data",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_joins_all_record_and_external_close_identities",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_preserves_unchanged_combined_and_third_record_caps",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_refuses_claim_and_instrumentation_flag_drift",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_refuses_noncanonical_duplicate_unknown_and_record_framing",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_fixed_nine_phase_order",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_forty_unique_ordered_rows_on_both_sides",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_integer_arrays_and_rejects_numeric_aliases",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_roundtrips_three_lines_preserving_original_prefix",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_times_first_use_but_does_not_create_first_use_callbacks",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_clock_arithmetic_refusal_is_inside_attempt",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_disabled_routes_never_call_clock_or_sink",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_effect_and_every_deadline_refusal_never_publish",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_every_clock_error_and_unwind_poison",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_exact_ten_stamps_and_old_effect_deadline_trace",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_forty_rows_and_real_close_keep_own_transcript",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_sink_error_and_unwind_after_commit_are_terminal",
      "native_catalog::forward::guarded_mlp_decode_v1::readiness::tail_scoped::durations::tests::duration_phase_state_duplicate_position_and_absent_callbacks_refuse",
      "native_catalog::forward::guarded_mlp_decode_v1::readiness::tail_scoped::durations::tests::duration_phase_state_each_containment_refusal_is_terminal",
      "native_catalog::forward::guarded_mlp_decode_v1::readiness::tail_scoped::durations::tests::duration_phase_state_forty_rows_contain_original_callback_rows",
      "native_catalog::forward::guarded_mlp_decode_v1::readiness::tail_scoped::durations::tests::duration_phase_state_missing_prior_row_refuses_before_next_runtime_call",
      "native_catalog::forward::guarded_mlp_decode_v1::readiness::tail_scoped::durations::tests::duration_phase_state_total_overflow_and_whole_bound_refuse_before_sink_commit",
      "native_guarded_mlp_readiness_cli_v1::tests::forward_phase_cli_invalid_late_record_writes_no_policy_prefix",
      "native_guarded_mlp_readiness_cli_v1::tests::forward_phase_cli_three_records_preserve_original_first_two_bytes",
      "native_guarded_mlp_readiness_cli_v1::tests::forward_phase_cli_writer_deadline_and_each_write_flush_refusal_propagate"
    ]
  },
  "parent": {
    "default": [],
    "diagnostic": [
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_allows_zero_elapsed_without_inventing_zero_callback_calls",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_authenticates_exact_lf_inclusive_callback_record",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_each_nested_scope_without_double_counting",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_exact_sum_overflow_position_and_row_bound",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_checks_whole_case_sum_not_only_individual_bounds",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_does_not_launder_invalid_original_callback_counts",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_does_not_replace_original_policy_or_two_record_admission",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_fixture_rows_and_record_cannot_alias_original_callback_data",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_joins_all_record_and_external_close_identities",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_preserves_unchanged_combined_and_third_record_caps",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_refuses_claim_and_instrumentation_flag_drift",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_refuses_noncanonical_duplicate_unknown_and_record_framing",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_fixed_nine_phase_order",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_forty_unique_ordered_rows_on_both_sides",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_requires_integer_arrays_and_rejects_numeric_aliases",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_roundtrips_three_lines_preserving_original_prefix",
      "finite_guarded_mlp_readiness_forward_durations_v1::tests::forward_duration_times_first_use_but_does_not_create_first_use_callbacks",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_clock_arithmetic_refusal_is_inside_attempt",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_disabled_routes_never_call_clock_or_sink",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_effect_and_every_deadline_refusal_never_publish",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_every_clock_error_and_unwind_poison",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_exact_ten_stamps_and_old_effect_deadline_trace",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_forty_rows_and_real_close_keep_own_transcript",
      "guarded_mlp_long_sequence_v2::tests::forward_timing::forward_phase_sequence_sink_error_and_unwind_after_commit_are_terminal",
      "tp_finite_client::long::readiness::bank_scoped_census_tail::tests::forward_duration_parent_preserves_first_two_records_and_whole_stderr_identity",
      "tp_finite_client::long::readiness::bank_scoped_census_tail::tests::forward_duration_parent_refuses_rehashed_third_identity_rows_and_containment_drift",
      "tp_finite_client::long::readiness::bank_scoped_census_tail::tests::forward_duration_parent_requires_three_canonical_ordered_records"
    ]
  }
}

def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    before=path.lstat()
    assert path.resolve(strict=True)==path and stat.S_ISREG(before.st_mode) and before.st_size<=32<<20
    raw=path.read_bytes()
    stamp=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert stamp(before)==stamp(path.lstat()) and len(raw)==before.st_size
    return raw

def snapshot():
    result={}
    for prefix in ('ferric','fe2o3'):
        for root,dirs,names in os.walk(ROOT/prefix,followlinks=False):
            assert not {'.git','target'} & set(dirs)
            assert all(not (Path(root)/n).is_symlink() for n in dirs)
            for name in names:
                path=Path(root)/name
                result[str(path.relative_to(ROOT))]=pin(read(path))
    assert len(result)==2132 and sum(row['bytes'] for row in result.values())<=64<<20
    return result

def save(name,value):
    raw=(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
    with (ROOT/name).open('xb') as stream: stream.write(raw)
    assert read(ROOT/name)==raw
    return pin(raw)

assert os.getuid()==os.geteuid()==9661 and os.uname().nodename=='smci350-rck-g03-b19-03'
assert os.sched_getaffinity(0)=={8,9} and os.getpriority(os.PRIO_PROCESS,0)==10
assert all(os.environ.get(n)=='' for n in ('HIP_VISIBLE_DEVICES','ROCR_VISIBLE_DEVICES','CUDA_VISIBLE_DEVICES'))
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
resource.setrlimit(resource.RLIMIT_FSIZE,(32<<20,32<<20))
assert not any(os.path.lexists(ROOT/n) for n in ('proposal.json','source-preformat.json','format-command.json','format-result.json','format.stdout','format.stderr'))
base_raw=read(ROOT/'base-manifest.json')
assert pin(base_raw)==dict(bytes=905626,sha256='672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a')
old={n:{k:row[k] for k in ('bytes','sha256')} for n,row in json.loads(base_raw)['sources'].items()}
before=snapshot()
assert set(old)<=set(before)
assert sorted(n for n in before if before[n]!=old.get(n))==OVERLAY
save('source-preformat.json',before)
fmt=Path('/home/harmenon/.rustup/toolchains/nightly-2026-04-03-x86_64-unknown-linux-gnu/bin/rustfmt')
base=ROOT.parent/'guarded-mlp-currentness-duration-diagnostic-cpu-v228-v2/evidence/complete.json'
raw=read(base)
assert pin(raw)==dict(bytes=2569774,sha256='5a27b9983ecd0d523226cbf2db4070108cd6deaf75d2ee6fe528274d2f8a5ac2')
tool=json.loads(raw)['tool_pins']['rustfmt']
assert pin(read(fmt))=={k:tool[k] for k in ('bytes','sha256')}
argv=[str(fmt),'--edition','2024','--config','skip_children=true',*(str(ROOT/n) for n in OVERLAY)]
save('format-command.json',dict(argv=argv,timeout_seconds=120,affinity=[8,9],nice=10,tool=tool))
with (ROOT/'format.stdout').open('xb') as out,(ROOT/'format.stderr').open('xb') as err:
    child=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
    timed_out=False
    try:
        code=child.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(child.pid,signal.SIGKILL)
        code=child.wait(timeout=5)
save('format-result.json',dict(exit_code=code,timed_out=timed_out,reaped=True,
    stdout=pin(read(ROOT/'format.stdout')),stderr=pin(read(ROOT/'format.stderr'))))
assert code==0 and not timed_out
after=snapshot()
assert set(after)==set(before) and all(after[n]==before[n] for n in before if n not in OVERLAY)
assert pin(read(fmt))=={k:tool[k] for k in ('bytes','sha256')}
proposal=dict(schema='ferric-readiness40-forward-phases-source-v1',
    feature='engineering-currentness-duration-diagnostics',files=after,overlay=OVERLAY,
    new_tests=TESTS,base_manifest=pin(base_raw),source_preformat=pin(read(ROOT/'source-preformat.json')),
    formatted_paths=[n for n in OVERLAY if before[n]!=after[n]],runtime_source_changed=False,
    currentness_policy_changed=False,kernel_math_changed=False,compiled=False,tests_executed=False,
    gpu_execution=False,native_admission=False,numerical_acceptance=False,performance_claim=False)
print(json.dumps(dict(proposal=save('proposal.json',proposal),sources=len(after),overlay=len(OVERLAY),
    worker_new_tests=len(TESTS['worker']['diagnostic']),parent_new_tests=len(TESTS['parent']['diagnostic'])),sort_keys=True))

