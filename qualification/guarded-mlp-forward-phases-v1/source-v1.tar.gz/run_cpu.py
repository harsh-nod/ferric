"""Fresh, bounded CPU qualification of the opt-in forward-phase diagnostic.

Replay previously qualified Cargo recipes against an explicit new source closure.
The runtime is byte-identical; this run tests the changed worker and parent, not
a replacement runtime qualification or native execution admission.
"""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import sys
import time
import types

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
AUTHOR = E / 'guarded-mlp-forward-phases-source-v228-v1'
ROOT = Path(__file__).resolve().parent
FEATURE = 'engineering-currentness-duration-diagnostics'
WP = 'ferric/adapters/tp-peer-finite-engineering-worker-v1/'
PP = 'ferric/adapters/m1-engineering-execution-v1/'
BASE_PINS = {
    'worker-diagnostic': [2569774, '5a27b9983ecd0d523226cbf2db4070108cd6deaf75d2ee6fe528274d2f8a5ac2'],
    'worker-default': [2544682, 'c2371fe9155ddc2046c1e1cddae12447ec48a77b6c18df17d4ece2071f81ccbe'],
    'parent-diagnostic': [4165800, 'f253584fcc0fde7087614c2d9469f37ff950aeb48825fc64d1be1614d6596602'],
    'parent-default': [4134737, '90f69d27dd0e01e254a02139a16e758efd1345b5d4541ebb13886b20f73ef2ae'],
}
HELPERS = {
    'supervisor.py': '8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc',
    'worker_support.py': '4d12ba86c4014adaaea1c5c49c3790dffcca78af8326ae09cb085840347a518a',
}
WHOLE, RESERVE = 3600, 50


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def compact(row):
    return {k: row[k] for k in ('bytes', 'sha256')}


def pin_bytes(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path, expected=None, cap=128 << 20):
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_size <= cap, 'bounded ordinary input: ' + str(path))
    raw = path.read_bytes()
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stamp(before) == stamp(path.lstat()) and len(raw) == before.st_size, 'input changed')
    if expected is not None:
        require(pin_bytes(raw) == compact(expected), 'input hash: ' + str(path))
    return raw


def relative(name):
    return (type(name) is str and name not in ('', '.') and Path(name).as_posix() == name
            and not Path(name).is_absolute() and '..' not in Path(name).parts)


def put(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    require(read(path) == raw, 'staged bytes differ')


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def base_root(role, mode):
    middle = mode + ('-parent' if role == 'parent' else '')
    return E / ('guarded-mlp-currentness-duration-' + middle + '-cpu-v228-v2')


def setup():
    require(__debug__ and sys.dont_write_bytecode
            and os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == 'smci350-rck-g03-b19-03', 'exact MI350 host/UID')
    require(shutil.disk_usage(E).free >= 40 << 30, '40 GiB initial free floor')
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    nice = os.getpriority(os.PRIO_PROCESS, 0)
    require(nice in (0, 10), 'nice level')
    if nice == 0:
        os.nice(10)
    for key in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES'):
        os.environ[key] = ''
    for kind, cap in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30),
                      (resource.RLIMIT_FSIZE, 1 << 30)):
        old = resource.getrlimit(kind)
        limit = min([cap] + [v for v in old if v != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (limit, limit))


def stage(role, mode, attempt, digest):
    require(ROOT == AUTHOR and role in ('worker', 'parent') and mode in ('default', 'diagnostic')
            and re.fullmatch('v[1-9][0-9]*', attempt) and re.fullmatch('[0-9a-f]{64}', digest),
            'closed staging arguments')
    signal.alarm(180)
    raw = read(AUTHOR / 'proposal.json')
    require(pin_bytes(raw)['sha256'] == digest, 'root-bound reviewed proposal')
    proposal = json.loads(raw)
    require(proposal['schema'] == 'ferric-readiness40-forward-phases-source-v1'
            and proposal['feature'] == FEATURE, 'source proposal identity')
    base_raw = read(AUTHOR / 'base-manifest.json',
                    dict(bytes=905626, sha256='672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a'))
    base = json.loads(base_raw)
    old = {n: compact(row) for n, row in base['sources'].items()}
    files = proposal['files']
    require(all(relative(n) and n.startswith(('ferric/', 'fe2o3/')) for n in files)
            and len(files) <= 2160 and sum(row['bytes'] for row in files.values()) <= 64 << 20,
            'bounded closed source roster')
    require(set(old) <= set(files), 'no removed baseline sources')
    changed = sorted(n for n in files if files[n] != old.get(n))
    require(changed == proposal['overlay'] and 3 <= len(changed) <= 20
            and all(n.startswith((WP, PP)) and n.endswith('.rs') for n in changed),
            'only reviewed worker/parent Rust changes; runtime and locks unchanged')
    for role_name in ('worker', 'parent'):
        for selected_mode in ('default', 'diagnostic'):
            names = proposal['new_tests'][role_name][selected_mode]
            require(names == sorted(set(names)) and all(re.fullmatch('[A-Za-z0-9_:]+', n) for n in names),
                    'closed unique new-test roster')
    previous = base_root(role, mode)
    size, sha = BASE_PINS[role + '-' + mode]
    complete_raw = read(previous / 'evidence/complete.json', dict(bytes=size, sha256=sha))
    complete = json.loads(complete_raw)
    require(complete['passed'] is True and complete['failure'] is None
            and complete['postcheck_errors'] == [] and complete['source_unchanged'] is True
            and complete['gpu_execution'] is False, 'clean actual CPU predecessor')
    out = E / ('guarded-mlp-forward-phases-' + role + '-' + mode + '-cpu-v228-' + attempt)
    require(not os.path.lexists(out), 'fresh stage only')
    out.mkdir(mode=0o700)
    copied = {}
    for name, row in sorted(files.items()):
        body = read(AUTHOR / name, row)
        put(out / name, body)
        read(AUTHOR / name, row)
        copied[name] = row
    for name, source in (
            ('run_cpu.py', AUTHOR / 'run_cpu.py'),
            ('proposal.json', AUTHOR / 'proposal.json'),
            ('base-manifest.json', AUTHOR / 'base-manifest.json')):
        put(out / name, read(source))
    helper_base = base_root('worker', 'diagnostic')
    for name, helper_sha in HELPERS.items():
        body = read(helper_base / name)
        require(pin_bytes(body)['sha256'] == helper_sha, 'qualified helper identity')
        put(out / name, body)
    put(out / 'inputs/base-complete.json', complete_raw)
    metadata = complete['raw']['metadata.stdout']
    put(out / 'inputs/base-metadata.json', read(previous / 'evidence/metadata.stdout', metadata))
    cache_row = complete['cache_provenance']['manifest']
    cache_raw = read(previous / 'cargo-cache-manifest.json', cache_row)
    cache = json.loads(cache_raw)
    require(len(cache['files']) == (247 if role == 'parent' else 73), 'qualified private cache roster')
    put(out / 'cargo-cache-manifest.json', cache_raw)
    for name, row in cache['files'].items():
        require(relative(name) and name.startswith(('registry/', 'git/')), 'private cache member')
        put(out / 'cargo-home' / name, read(previous / 'cargo-home' / name, row))
    for name in ('run_cpu.py', 'supervisor.py', 'worker_support.py'):
        copied[name] = pin_bytes(read(out / name))
    inputs = dict(schema='ferric-forward-phases-cpu-input-v1', role=role, mode=mode,
                  attempt=attempt, root=str(out), proposal=pin_bytes(raw), files=copied,
                  predecessor=pin_bytes(complete_raw), predecessor_root=str(previous),
                  cache_manifest=compact(cache_row), tool_pins=complete['tool_pins'])
    put(out / 'input-manifest.json', encoded(inputs))
    require(shutil.disk_usage(E).free >= 38 << 30, '38 GiB stage free floor')
    signal.alarm(0)
    print(json.dumps(dict(staged=True, root=str(out),
                          input_manifest=pin_bytes(read(out / 'input-manifest.json')),
                          gpu_execution=False, project_code_executed=False), sort_keys=True))


def load_helper(name, digest):
    path = ROOT / name
    raw = read(path)
    require(pin_bytes(raw)['sha256'] == digest, 'authenticated helper')
    module = types.ModuleType(name.replace('.', '_'))
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def relocate(value, old):
    if isinstance(value, str):
        return value.replace(old, str(ROOT))
    if isinstance(value, list):
        return [relocate(v, old) for v in value]
    if isinstance(value, dict):
        return {k: relocate(v, old) for k, v in value.items()}
    return value


def run(digest):
    require(re.fullmatch('[0-9a-f]{64}', digest), 'literal input SHA')
    raw = read(ROOT / 'input-manifest.json')
    require(pin_bytes(raw)['sha256'] == digest, 'input manifest identity')
    inputs = json.loads(raw)
    role, mode = inputs['role'], inputs['mode']
    require(inputs['schema'] == 'ferric-forward-phases-cpu-input-v1'
            and role in ('worker', 'parent') and mode in ('default', 'diagnostic')
            and ROOT == Path(inputs['root']) and ROOT.parent == E
            and ROOT.name == 'guarded-mlp-forward-phases-' + role + '-' + mode + '-cpu-v228-' + inputs['attempt'],
            'exact owned CPU namespace')
    proposal = json.loads(read(ROOT / 'proposal.json', inputs['proposal']))
    base = json.loads(read(ROOT / 'inputs/base-complete.json', inputs['predecessor']))
    size, sha = BASE_PINS[role + '-' + mode]
    require(inputs['predecessor'] == dict(bytes=size, sha256=sha)
            and inputs['tool_pins'] == base['tool_pins'], 'qualified predecessor/tool join')
    old_root = inputs['predecessor_root']
    require(old_root == str(base_root(role, mode)), 'literal predecessor path')
    w = load_helper('worker_support.py', HELPERS['worker_support.py'])
    w.ROOT, w.FERRIC, w.RUNTIME = ROOT, ROOT / 'ferric', ROOT / 'fe2o3'
    w.WORKER = ROOT / (PP if role == 'parent' else WP)
    w.OUT, w.TARGET, w.TMP, w.CARGO_HOME = (ROOT / n for n in ('evidence', 'target', 'tmp', 'cargo-home'))
    h = w.load_supervisor()
    require(not any(os.path.lexists(p) for p in (h.OUT, h.TARGET, h.TMP)), 'fresh execution leaves')
    h.TOOLCHAIN = Path(inputs['tool_pins']['rustc']['path']).parent
    h.TOOLCHAIN_LIB = h.TOOLCHAIN.parent / 'lib'
    h.WHOLE_WALL, h.CLEANUP_RESERVE = WHOLE, RESERVE
    h.OUT.mkdir(mode=0o700)
    h.TMP.mkdir(mode=0o700)
    def snapshot():
        paths = [ROOT / n for n in ('run_cpu.py', 'supervisor.py', 'worker_support.py')]
        paths += h.files_below(ROOT / 'ferric') + h.files_below(ROOT / 'fe2o3')
        require(len(paths) <= 2163, 'bounded source closure')
        return {str(p.relative_to(ROOT)): h.pin(p) for p in sorted(paths)}
    h.sources = snapshot
    original_scratch = h.scratch_bytes
    def scratch():
        paths = h.files_below(w.CARGO_HOME, packed=False)
        require(len(paths) <= (150000 if role == 'parent' else 15000), 'bounded private cache roster')
        total = original_scratch()
        for path in paths:
            try:
                total += path.lstat().st_size
            except FileNotFoundError:
                # Cargo can retire its own temporary cache files between scans.
                pass
        return total
    h.scratch_bytes = scratch
    def configurations():
        directories = {ROOT, w.FERRIC, w.RUNTIME, w.WORKER, *ROOT.parents, *w.WORKER.parents}
        directories |= {p.parent for root in (w.FERRIC, w.RUNTIME) for p in root.rglob('Cargo.toml')}
        paths = {d / '.cargo' / n for d in directories for n in ('config', 'config.toml')}
        paths |= {d / n for d in (w.CARGO_HOME, Path('/home/harmenon/.cargo'))
                  for n in ('config', 'config.toml')}
        values = {str(p): h.pin(p) if os.path.lexists(p) else None for p in sorted(paths)}
        require(not any(values.values()), 'inherited Cargo configuration refused')
        return values
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'subreaper')
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)
    started = time.monotonic()
    deadline = started + WHOLE
    signal.setitimer(signal.ITIMER_REAL, WHOLE - RESERVE)
    phases, tests, artifacts, errors, dependencies = [], {}, {}, [], {}
    before = after = configuration = metadata = None
    failure = None
    cli_executable_before_tests = None
    cli_executable_unchanged = False
    inventory = []
    readset = {str(ROOT / n): h.pin(ROOT / n) for n in (
        'input-manifest.json', 'proposal.json', 'base-manifest.json',
        'inputs/base-complete.json', 'inputs/base-metadata.json', 'cargo-cache-manifest.json')}
    try:
        before = snapshot()
        require({n: compact(row) for n, row in before.items()} == inputs['files'], 'exact sealed sources')
        require({n: compact(row) for n, row in before.items() if n.startswith(('ferric/', 'fe2o3/'))}
                == proposal['files'], 'proposal source join')
        h.save('sources-before.json', before)
        configuration = configurations()
        cache = json.loads(read(ROOT / 'cargo-cache-manifest.json', inputs['cache_manifest']))
        require({str(p.relative_to(w.CARGO_HOME)) for p in h.files_below(w.CARGO_HOME, packed=False)}
                == set(cache['files']), 'fresh private immutable cache inputs only')
        for name, row in cache['files'].items():
            require(compact(h.pin(w.CARGO_HOME / name)) == row, 'cache byte identity')
            readset[str(w.CARGO_HOME / name)] = h.pin(w.CARGO_HOME / name)
        for row in inputs['tool_pins'].values():
            require(h.pin(Path(row['path'])) == row, 'qualified tool identity')
            readset[row['path']] = row
        baseline_phase = next(p for p in base['phases'] if p['label'] == 'metadata')
        command_path = Path(baseline_phase['command']['path'])
        command = json.loads(read(command_path, baseline_phase['command']))
        env = relocate(command['env'], old_root)
        require(env['CARGO_HOME'] == str(w.CARGO_HOME)
                and env['CARGO_TARGET_DIR'] == str(h.TARGET)
                and env['CARGO_BUILD_JOBS'] == '2'
                and all(env[n] == '' for n in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES')),
                'same bounded offline GPU-hidden environment')
        readset[str(command_path)] = h.pin(command_path)
        leaf_wall = 1200 if role == 'parent' else 1800
        def leaf(label, argv, seconds=None):
            seconds = leaf_wall if seconds is None else seconds
            h.run(label, argv, env, phases, deadline, before, seconds, w.WORKER)
        overlay = [str(ROOT / n) for n in proposal['overlay']]
        leaf('rustfmt-check', [str(h.TOOLCHAIN / 'rustfmt'), '--edition', '2024',
                              '--config', 'skip_children=true', '--check', *overlay], 120)
        worker_labels = {'rustc-version', 'metadata', 'worker-tests-build', 'worker-list',
                         'worker-ignored', 'worker-tests', 'worker-build'}
        recipes = [p for p in base['phases']
                   if (p['label'] in worker_labels if role == 'worker'
                       else p['label'] not in ('rustfmt', 'rustfmt-check'))]
        additions = proposal['new_tests'][role][mode]
        selected_new = set()
        for phase in recipes:
            label = phase['label']
            require(phase['argv'][:6] == ['/usr/bin/prlimit', '--as=12884901888', '--cpu=1200',
                                         '--fsize=1073741824', '--core=0', '--'], 'original bounded recipe')
            argv = relocate(phase['argv'][6:], old_root)
            recipe_path = Path(phase['command']['path'])
            recipe = json.loads(read(recipe_path, phase['command']))
            require(recipe['argv'] == phase['argv'] and relocate(recipe['env'], old_root) == env,
                    'original recipe and environment join')
            readset[str(recipe_path)] = h.pin(recipe_path)
            if label == 'worker-tests':
                cli_executable_before_tests = artifacts['worker']['pin']
                require(h.pin(Path(cli_executable_before_tests['path'])) == cli_executable_before_tests,
                        'actual CLI ELF unchanged immediately before integration probes')
            leaf(label, argv, min(leaf_wall, recipe['wall_timeout_seconds']))
            if label == 'worker-tests':
                require(h.pin(Path(cli_executable_before_tests['path'])) == cli_executable_before_tests,
                        'actual CLI ELF unchanged immediately after integration probes')
                cli_executable_unchanged = True
            stdout = (h.OUT / (label + '.stdout')).read_text()
            if label == 'metadata':
                metadata = json.loads(stdout)
                previous_meta = json.loads(read(ROOT / 'inputs/base-metadata.json',
                                                  base['raw']['metadata.stdout']))
                require(metadata == relocate(previous_meta, old_root), 'unchanged exact Cargo resolution')
                for package in metadata['packages']:
                    path = Path(package['manifest_path'])
                    require(path.resolve(strict=True) == path, 'ordinary resolved dependency')
                    if package['source'] is None:
                        require(path.is_relative_to(ROOT / 'ferric') or path.is_relative_to(ROOT / 'fe2o3'),
                                'local dependency in sealed tree')
                    else:
                        require(path.is_relative_to(w.CARGO_HOME), 'external dependency in private cache')
                        dep = path.parent
                        if package['source'].startswith('git+'):
                            dep = w.CARGO_HOME.joinpath(*path.relative_to(w.CARGO_HOME).parts[:4])
                        dependencies[str(dep)] = {str(p.relative_to(dep)): h.pin(p)
                                                  for p in h.files_below(dep, packed=False)
                                                  if '.git' not in p.relative_to(dep).parts}
                h.save('dependencies-before.json', dependencies)
            if label in ('worker-list', 'parent-lib-list'):
                inventory = w.inventory(stdout)
                if role == 'worker':
                    names = sorted(w.statuses(base['tests']['worker-tests']))
                else:
                    prior = next(p for p in base['phases'] if p['label'] == label)
                    path = Path(prior['stdout']['path'])
                    names = w.inventory(read(path, prior['stdout']).decode())
                    readset[str(path)] = h.pin(path)
                require(inventory == sorted(names + additions), 'all old and exact new named tests')
            if label == 'worker-ignored':
                require(w.inventory(stdout) == sorted(n for n, s in w.statuses(base['tests']['worker-tests']).items()
                                                       if s == 'ignored'), 'unchanged explicit ignored tests')
            if label in ('guarded-bin-list', 'readiness-bin-list', 'full2303-bin-list'):
                test_label = label.removesuffix('-list') + '-tests'
                require(w.inventory(stdout) == sorted(w.statuses(base['tests'][test_label])),
                        'unchanged exact parent binary test roster')
            if label in base['tests'] and (role == 'parent' or label == 'worker-tests'):
                value = w.outcomes(stdout)
                expected = w.statuses(base['tests'][label])
                if role == 'worker':
                    added = set(additions)
                elif '--lib' in argv:
                    selector = argv[argv.index('--lib') + 1]
                    added = {n for n in additions if n == selector or ('--exact' not in argv and selector in n)}
                else:
                    added = set()
                require(not selected_new & added, 'new cases selected once')
                selected_new |= added
                require(w.statuses(value) == expected | {n: 'ok' for n in added}
                        and value['failed'] == 0
                        and value['ignored'] == base['tests'][label]['ignored'], 'exact named outcomes: ' + label)
                tests[label] = value
            if label in ('worker-tests-build', 'worker-build', 'parent-builds'):
                records = h.build_records(h.OUT / (label + '.stdout'))
                for old_name, old_artifact in base['artifacts'].items():
                    if role == 'worker' and not old_name.startswith('worker'):
                        continue
                    old = old_artifact['cargo_artifact']
                    matches = [r for r in records if r.get('reason') == 'compiler-artifact'
                               and r.get('manifest_path') == str(w.WORKER / 'Cargo.toml')
                               and r.get('target', {}).get('name') == old['target']['name']
                               and r['target']['kind'] == old['target']['kind']
                               and r.get('profile', {}).get('test') == old['profile']['test']]
                    if not matches:
                        continue
                    require(len(matches) == 1 and matches[0]['features'] == old['features']
                            and matches[0]['target']['src_path'] == relocate(old['target']['src_path'], old_root),
                            'same product target/source/features')
                    row = matches[0]
                    path = Path(row['executable'])
                    require(path.resolve(strict=True) == path and path.is_relative_to(h.TARGET)
                            and row['filenames'].count(str(path)) == 1, 'owned product')
                    with path.open('rb') as stream:
                        require(stream.read(4) == b'\x7fELF', 'ELF product')
                    actual = dict(pin=h.pin(path), cargo_artifact=row)
                    require(old_name not in artifacts or artifacts[old_name]['pin'] == actual['pin'],
                            'worker CLI ELF unchanged across integration tests')
                    artifacts[old_name] = actual
        remaining = set(additions) - selected_new
        if remaining:
            require(role == 'parent' and mode == 'diagnostic'
                    and all(n.startswith('finite_guarded_mlp_readiness_forward_durations_v1::tests::')
                            for n in remaining), 'only new shared codec scope remains')
            phase = next(p for p in recipes if p['label'] == 'parent-currentness-duration-policy')
            argv = relocate(phase['argv'][6:], old_root)
            argv[argv.index('--lib') + 1] = 'finite_guarded_mlp_readiness_forward_durations_v1::tests::'
            leaf('parent-forward-phase-policy', argv)
            value = w.outcomes((h.OUT / 'parent-forward-phase-policy.stdout').read_text())
            require(w.statuses(value) == {n: 'ok' for n in remaining}, 'all new codec cases')
            tests['parent-forward-phase-policy'] = value
            selected_new |= remaining
        require(selected_new == set(additions), 'every new case executed')
        expected_products = set(base['artifacts'])
        if role == 'worker':
            expected_products = {n for n in expected_products if n.startswith('worker')}
        require(set(artifacts) == expected_products, 'all selected ELF products')
    except BaseException as error:
        failure = repr(error)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    def check(label, action):
        try:
            require(deadline - time.monotonic() > 1, 'postcheck deadline')
            signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - time.monotonic() - 1))
            action()
        except BaseException as error:
            errors.append(label + ': ' + repr(error))
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
    def post_sources():
        nonlocal after
        after = snapshot()
        h.save('sources-after.json', after)
        require(after == before, 'source drift')
    check('sources', post_sources)
    if configuration is not None:
        check('configuration', lambda: require(configurations() == configuration, 'Cargo config drift'))
    for name, row in readset.items():
        check('readset ' + name, lambda name=name, row=row: require(h.pin(Path(name)) == row, 'input/tool/cache drift'))
    for name, rows in dependencies.items():
        def dep_check(name=name, rows=rows):
            dep = Path(name)
            current = {str(p.relative_to(dep)): h.pin(p) for p in h.files_below(dep, packed=False)
                       if '.git' not in p.relative_to(dep).parts}
            require(current == rows, 'resolved dependency drift')
        check('dependency ' + name, dep_check)
    for name, artifact in artifacts.items():
        check('artifact ' + name, lambda artifact=artifact: require(
            h.pin(Path(artifact['pin']['path'])) == artifact['pin'], 'ELF drift'))
    raw_pins = {p.name: h.pin(p) for p in sorted(h.OUT.iterdir()) if p.is_file()}
    failure = failure or ('postcheck failures' if errors else None)
    result = dict(schema='ferric-readiness40-forward-phases-cpu-v1', role=role, mode=mode,
                  passed=failure is None, failure=failure, postcheck_errors=errors,
                  input_manifest=h.pin(ROOT / 'input-manifest.json'), proposal=inputs['proposal'],
                  predecessor=inputs['predecessor'], input_sources=before, final_sources=after,
                  source_unchanged=before is not None and before == after, phases=phases,
                  tests=tests, inventories=inventory, artifacts=artifacts, readset=readset,
                  dependencies=dependencies, tool_pins=inputs['tool_pins'], raw=raw_pins,
                  elapsed_seconds=time.monotonic() - started,
                  cli_executable_before_tests=cli_executable_before_tests,
                  cli_executable_unchanged_across_tests=cli_executable_unchanged,
                  limits=dict(whole_seconds=WHOLE, cleanup_reserve_seconds=RESERVE,
                              leaf_seconds=1200 if role == 'parent' else 1800,
                              affinity=[8, 9], nice=10, cargo_jobs=2, gpu_hidden=True,
                              initial_free_bytes=40 << 30, live_free_bytes=38 << 30,
                              address_space_bytes=h.AS_LIMIT, cpu_seconds=h.CPU_LIMIT,
                              scratch_bytes=h.CACHE_LIMIT, stream_bytes=h.STREAM_LIMIT),
                  runtime_source_changed=False, runtime_tests_repeated=False,
                  currentness_policy_changed=False, full2303_deadline_changed=False,
                  gpu_execution=False, native_admission=False, numerical_acceptance=False,
                  performance_claim=False)
    h.save('complete.json' if failure is None else 'failed.json', result)
    print(json.dumps(dict(passed=failure is None, failure=failure, role=role, mode=mode,
                          phases=len(phases), passed_tests=sum(v['passed'] for v in tests.values()),
                          output=str(h.OUT)), sort_keys=True))
    return 0 if failure is None else 1


if __name__ == '__main__':
    setup()
    if len(sys.argv) == 6 and sys.argv[1] == 'stage':
        stage(*sys.argv[2:])
    elif len(sys.argv) == 3 and sys.argv[1] == 'run':
        raise SystemExit(run(sys.argv[2]))
    else:
        raise SystemExit('usage: run_cpu.py stage ROLE MODE ATTEMPT PROPOSAL_SHA | run INPUT_SHA')
