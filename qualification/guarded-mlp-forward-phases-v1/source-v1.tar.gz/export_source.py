"""Export the reviewed remote overlay and draft documentation as data."""
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import tarfile

ROOT=Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-forward-phases-source-v228-v1")
assert os.getuid()==os.geteuid()==9661 and os.uname().nodename=='smci350-rck-g03-b19-03'
assert os.sched_getaffinity(0)=={8,9} and os.getpriority(os.PRIO_PROCESS,0)==10
assert shutil.disk_usage(ROOT).free>=40<<30
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
resource.setrlimit(resource.RLIMIT_FSIZE,(64<<20,64<<20))
resource.setrlimit(resource.RLIMIT_CPU,(60,60))
signal.alarm(90)

def pin(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    before=path.lstat()
    assert path.resolve(strict=True)==path and stat.S_ISREG(before.st_mode) and before.st_size<=32<<20
    raw=path.read_bytes()
    stamp=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert stamp(before)==stamp(path.lstat()) and len(raw)==before.st_size
    return raw

raw=read(ROOT/'proposal.json')
assert pin(raw)==dict(bytes=429829,sha256='7ecf02cba32b1435f1e01a0bd6ed100961f68495067419d5935bdc73e6a27c6a')
proposal=json.loads(raw)
base=json.loads(read(ROOT/'base-manifest.json'))
bodies={}
patch=[]
for name in proposal['overlay']:
    after=read(ROOT/name)
    assert pin(after)==proposal['files'][name]
    before=b''
    if name in base['sources']:
        row=base['sources'][name]
        before=read(Path(row['source']))
        assert pin(before)=={k:row[k] for k in ('bytes','sha256')}
    assert name.startswith('ferric/') and name.endswith('.rs')
    relative=name.removeprefix('ferric/')
    patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),
        fromfile='a/'+relative if before else '/dev/null',tofile='b/'+relative))
    bodies[name]=after
for name in ('run_cpu.py','seal_sources.py','export_cpu.py','export_source.py','proposal.json',
             'base-manifest.json','source-preformat.json','format-command.json','format-result.json',
             'format.stdout','format.stderr','docs-draft/progress/GFX950_FINITE_PREFIX_PROGRESS_V1.md',
             'docs-draft/causal/README.md'):
    bodies[name]=read(ROOT/name)
bodies['source.patch']=''.join(patch).encode()
manifest=dict(schema='ferric-forward-phases-source-export-v1',
    proposal=pin(raw),originals={n:pin(b) for n,b in sorted(bodies.items())},
    source_changes_authored_on='mi350',gpu_execution=False,native_admission=False)
bodies['export-manifest.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
out=ROOT.parent/'guarded-mlp-forward-phases-source-v228-v1.tar.gz'
with out.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as tar:
        for name,body in sorted(bodies.items()):
            member=tarfile.TarInfo(name);member.size=len(body);member.mode=0o600;member.mtime=0
            tar.addfile(member,io.BytesIO(body))
assert shutil.disk_usage(ROOT).free>=38<<30
signal.alarm(0)
print(json.dumps(dict(archive=str(out),**pin(read(out)),members=len(bodies),
    expanded_bytes=sum(map(len,bodies.values()))),sort_keys=True))

