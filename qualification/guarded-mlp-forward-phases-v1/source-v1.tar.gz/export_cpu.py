"""Export original CPU evidence and its closed data manifest, never ELF/cache bytes."""
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import sys
import tarfile

E=Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
assert os.getuid()==os.geteuid()==9661 and os.uname().nodename=='smci350-rck-g03-b19-03'
assert os.sched_getaffinity(0)=={8,9} and os.getpriority(os.PRIO_PROCESS,0)==10
assert shutil.disk_usage(E).free>=40<<30
resource.setrlimit(resource.RLIMIT_AS,(512<<20,512<<20))
resource.setrlimit(resource.RLIMIT_FSIZE,(128<<20,128<<20))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
signal.alarm(180)
assert len(sys.argv)==4 and sys.argv[1] in ('worker','parent') and sys.argv[2] in ('default','diagnostic')
role,mode,attempt=sys.argv[1:]
assert attempt in ('v1','v2')
root=E/('guarded-mlp-forward-phases-'+role+'-'+mode+'-cpu-v228-'+attempt)
assert root.resolve(strict=True)==root

def pin(raw):
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def read(path):
    before=path.lstat()
    assert path.resolve(strict=True)==path and stat.S_ISREG(before.st_mode) and before.st_size<=32<<20
    raw=path.read_bytes()
    stamp=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    assert stamp(before)==stamp(path.lstat()) and len(raw)==before.st_size
    return raw

paths=[root/n for n in ('run_cpu.py','supervisor.py','worker_support.py','input-manifest.json',
    'proposal.json','base-manifest.json','cargo-cache-manifest.json')]
paths+=sorted((root/'inputs').iterdir())
if attempt=='v1':
    assert role=='worker' and mode=='diagnostic'
    paths+=[root/'preflight-failure.json']
    assert not (root/'evidence').exists() and not (root/'target').exists()
    successful=False
else:
    result=json.loads(read(root/'evidence/complete.json'))
    assert result['passed'] is True and result['failure'] is None and result['postcheck_errors']==[]
    assert result['source_unchanged'] is True and result['input_sources']==result['final_sources']
    assert not result['gpu_execution'] and not result['native_admission']
    for phase in result['phases']:
        assert phase['exit_code']==0 and phase['natural_exit'] and phase['reaped']
        assert phase['process_group_absent'] and not phase['forced_cleanup']
    for row in result['final_sources'].values():
        assert pin(read(Path(row['path'])))=={k:row[k] for k in ('bytes','sha256')}
    for row in result['raw'].values():
        assert pin(read(Path(row['path'])))=={k:row[k] for k in ('bytes','sha256')}
    paths+=sorted((root/'evidence').iterdir())
    successful=True
bodies={str(path.relative_to(root)):read(path) for path in paths}
assert len(bodies)==len(paths)<=512 and sum(map(len,bodies.values()))<=96<<20
manifest=dict(schema='ferric-forward-phases-cpu-export-v1',role=role,mode=mode,attempt=attempt,
    successful_cpu_qualification=successful,gpu_execution=False,
    originals={n:pin(raw) for n,raw in sorted(bodies.items())})
bodies['export-manifest.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
out=E/(root.name+'.tar.gz')
with out.open('xb') as stream:
    with tarfile.open(fileobj=stream,mode='w:gz') as tar:
        for name,raw in sorted(bodies.items()):
            member=tarfile.TarInfo(name)
            member.size=len(raw);member.mode=0o600;member.mtime=0
            tar.addfile(member,io.BytesIO(raw))
for path in paths:
    assert read(path)==bodies[str(path.relative_to(root))]
assert shutil.disk_usage(E).free>=38<<30
signal.alarm(0)
print(json.dumps(dict(archive=str(out),**pin(read(out)),originals=len(paths),
    expanded_bytes=sum(map(len,bodies.values()))),sort_keys=True))
