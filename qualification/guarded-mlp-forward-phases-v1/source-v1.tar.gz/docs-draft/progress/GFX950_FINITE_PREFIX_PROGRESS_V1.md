# Finite Qwen3 Prefix Progress

This is an engineering checkpoint for [issue #42](https://github.com/harsh-nod/ferric/issues/42),
updated on 2026-10-08 UTC. It is not a production admission, a sustained decode
benchmark, or a claim that the 700 tokens/s target has been reached. All issue #42 M0-M7
milestones remain open. The checkpoint is being published incrementally on an
engineering branch; it does not change the production execution path.

Latest implementation: optional
[currentness-duration instrumentation](../qualification/guarded-mlp-currentness-duration-v1/README.md)
passes separate MI350 CPU builds: 1,180 runtime / 838 worker tests with the
feature off, and 1,192 runtime / 853 worker tests with it enabled. Each build
passed all 27 phases; existing ignores are unchanged. All 22 actual tested
runtime/worker files are integrated with a complete 827-runtime / 1,299-Ferric
source postcheck. The strict independent checker passes 126 synthetic tests.
Both initial failed attempts remain retained. The separate parent builds now
pass 584 selected tests in 68 phases with the feature off and 595 tests in
69 phases with it on. Their four actual tested source files are integrated
after original-data review and a complete 1,299-Ferric / 827-runtime postcheck,
preserving all 236 worker bodies. The live CPU admission gate passes against
37 real artifact inputs, and the separate synthetic native-workflow suite
passes all 171 tests in 88.796 seconds with clean child retirement and
independently reviewed originals. Actual request preparation also passed on
MI350 with all 25 inputs rehashed and the original prepared bodies independently
reviewed. The final bound diagnostic now passes its first MI350 GPU attempt:
40 prompt forwards, zero generated tokens, eleven cleanly retired phases and
three successful postflight idle checks. All forty records and four complete
payloads match the historical Ferric baseline; the evidence tool revalidated
167 original archive members. Measured callback categories account for
21.242500713 seconds of 68.571861417 warm-forward seconds. The reproducible
[report](../qualification/guarded-mlp-currentness-duration-v1/report-v1/README.md)
now passes all thirteen CPU tests and its actual-archive invocation on MI350.
Its chart and exact tables separate callbacks, the nested bank interval and
the unprofiled remainder. This is host attribution, not numerical acceptance
or a new inference speedup.

The preceding [Full2303 scoped-tail worker](../qualification/guarded-mlp-full2303-scoped-tail-v1/README.md)
passes all 27 MI350 CPU phases in 186.074 seconds: 1,180 runtime and 838 worker
passes, with eight/four existing ignores unchanged. Its twelve actual tested
Rust postimages are integrated after independent original-data review and a
complete 1,294-Ferric/825-runtime source postcheck. The separate
[parent qualification](../qualification/guarded-mlp-full2303-scoped-tail-v1/parent-cpu-v1/README.md)
passed all 68 phases and 584 selected tests across 58 scopes in 419.208 seconds,
with a 1,047-name library inventory and seven executables. Its six tested Rust
files are integrated; the full 1,295-Ferric source postcheck preserves all 232
worker bodies. The [admission checker](../qualification/guarded-mlp-full2303-scoped-tail-v1/admission-cpu-v1/README.md)
passed all 84 synthetic cases in 71.190 seconds. These add explicit worker and
parent full-request selectors but do not demonstrate
native Full2303 execution, one-hour feasibility or independent numerical
acceptance.

The [immutable kernel-admission CPU experiment](../qualification/guarded-mlp-owned-admission-v1/README.md)
now passes ten tests and twelve fixed alternating sample pairs on MI350.
Median time for 360 representative preparations is 16.8091955 ms with fresh
validation versus 0.041175 ms for retained owned access. This is loader-only
opportunity, not an inference speedup. The original harness failure is
retained beside the successful retry. The runtime reuse change is deferred
while the larger currentness costs are measured; no new GPU result is claimed.

The preceding [opt-in scoped tail runtime and worker](../qualification/guarded-mlp-scoped-tail-v1/README.md)
passed all 27 MI350 CPU phases in 173.159 seconds: 1,180 runtime passes and
820 worker passes, with the existing eight/four ignores unchanged. All nineteen
actual tested Rust postimages are integrated with a complete 825-runtime and
1,288-Ferric source postcheck. The strict Tail V4 checker also passed all 114
synthetic tests in 70.690 seconds. The first parent qualification failed during
test compilation because the shared sequence fixture referenced a worker-only
module. The [original failed attempt](../qualification/guarded-mlp-scoped-tail-v1/parent-cpu-failed-v1/README.md)
is retained. The [test-only repair passed a fresh 27-phase coupled qualification](../qualification/guarded-mlp-scoped-tail-v1/cpu-attempt-v2/README.md)
in 173.070 seconds with the same test outcomes, and is integrated after full
canonical source checks. The [fresh parent retry](../qualification/guarded-mlp-scoped-tail-v1/parent-cpu-v2/README.md)
passed all 68 phases and 568 selected tests across 58 scopes in 416.482 seconds,
with a 1,032-name library inventory and seven built executables. Its seven
actual tested Rust files are integrated with a complete 1,290-file source
postcheck, preserving all 228 worker bodies and the parent lockfile.
The [final bound report tool](../qualification/guarded-mlp-scoped-tail-v1/matched-timing-report-cpu-v1/README.md)
passed all 13 synthetic tests on MI350 in 0.221 seconds; independent review
closed its original 16-member capsule and clean process retirement.
The [fresh Census V3/Tail V4 native pair](../qualification/guarded-mlp-scoped-tail-v1/matched-timing-gpu-v2/README.md)
passes in one attempt per case: all 40 records and four complete payloads match
each other and the historical baseline, with healthy Close and clean retirement.
Its [MI350-generated tables and plots](../qualification/guarded-mlp-scoped-tail-v1/matched-timing-report-v2/README.md)
show warm-forward parent wall time falling from 72.284347 to 68.373602 seconds
(-5.410224%), while complete-parent time falls only 0.234021% and first-use
time rises 1.119270%. This is one ordered pair, not sustained throughput or
GPU time. The [community demo runbook](GFX950_COMMUNITY_DEMO_V1.md) now includes
both retained ablations with their limits; their gains are not multiplied.
That measured tail path is Readiness40-only. The separate CPU-qualified Full
worker does not resolve the independent position-5 discrepancy or admit
Full2303 execution.

The [first selected Down-dot diagnostic attempt](../qualification/guarded-mlp-readiness40-causal-layer0-v1/position5-down-dot-v1/RESULTS.md)
ran all 48 synthetic tests on MI350: 47 passed and one failed because a fixture
expected a list where the API returns an identical-valued tuple. It stopped
before model-shard reading or real-data dot analysis; the original failed
capsule is retained. The [separate repaired V2 attempt](../qualification/guarded-mlp-readiness40-causal-layer0-v1/position5-down-dot-v2/RESULTS.md)
passes all 48 tests and evaluates 60 exact own-input rank dots over 15 selected
rows. Both sides match their own exact dots rounded to BF16 in every selected
row. All 14 selected differences persist under idealized own-input Down and
common-residual calculation. This supports an upstream origin for those rows,
not a final-argmax explanation, full-model acceptance or an arithmetic change.

The preceding
[scoped allocation census runtime and worker](../qualification/guarded-mlp-scoped-capacity-census-v1/README.md)
are integrated after a fresh MI350 coupled CPU run: all 26 phases passed in
158.984 seconds, including 1,165 runtime tests with eight existing ignores and
779 worker tests with four existing ignores. The 25 actual tested Rust files
were integrated with a 2,100-body source postcheck. This opt-in warm-layer path
preserves complete allocation accounting and ordered rank checks while moving
two selected zero-add preflights inside the closed layer operation. The parent
now passes all 67 phases and 535 selected tests across 57 scopes in 416.111
seconds, with seven executables built. Its seven tested Rust files are
integrated with a complete 1,279-body source postcheck, preserving all 220
worker bodies. The strict checker passes all 98 synthetic tests. The fresh
[same-binary bank/census GPU pair](../qualification/guarded-mlp-scoped-capacity-census-v1/matched-timing-gpu-v1/README.md)
now passes in one attempt per mode: all 40 records and four complete payloads
match each other and the historical baseline, with healthy Close and clean
owned-process/device postchecks. Its
[eleven-test-qualified report](../qualification/guarded-mlp-scoped-capacity-census-v1/matched-timing-report-v1/README.md)
shows warm-forward parent wall totals of 109.162 versus 72.476 seconds
(33.607% lower), first-use totals 0.752% higher, and complete parent time of
480.326 versus 445.273 seconds (7.298% lower). All 243 original archive members
and the original archive are retained with reproducible plots and tables.
This is one ordered host-wall pair, not GPU timing, overlap, generated-token
throughput, repeated benchmark evidence or Full2303 admission. Both actual
products use optimization level 2 with assertions and overflow checks retained.

The separate [Full2303 bank/census worker](../qualification/guarded-mlp-full2303-bank-scoped-census-v1/README.md)
now passes all 26 MI350 CPU phases in 172.933 seconds: 1,165 runtime passes
and 799 worker passes, with the eight/four existing ignores unchanged.
Its fifteen actual tested worker files are integrated with complete source
postchecks. The parent also passes all 68 phases and 549 selected tests in
415.377 seconds; its six tested files are integrated with a complete
1,284-body source postcheck and all 224 workers preserved. The
[strict full-workload checker](../qualification/guarded-mlp-full2303-bank-scoped-census-v1/admission-cpu-v1/README.md)
now passes all 62 tests with no skips in a 50.382-second MI350 CPU run.
All 28 original archive members are retained. This qualifies the comparison
code, not a native/reference result: no native Full2303 execution or one-hour
launch feasibility is claimed by these synthetic full-schedule tests.

The preceding
[bank-scoped rearm path](../qualification/guarded-mlp-scoped-bank-rearm-v1/README.md)
is integrated after a fresh coupled MI350 CPU qualification. All 26 phases
passed in 166.963 seconds: 1,152 runtime tests with eight existing ignores,
760 worker tests with four existing ignores, nine focused scopes, ten selected
facade doctests and eight parser regressions. The original failed worker test
build and the successful test-local repair are both retained. The 12 runtime
and 11 worker actual Rust postimages were integrated with a 2,091-body source
postcheck. The separate bank admission checker passes 82 tests. Host integration
now also passes all 67 phases and 519 selected tests across 57 scopes; its seven
qualified Rust files are integrated with a complete 1,273-body source postcheck.
The [matched native bank-rearm A/B run](../qualification/guarded-mlp-scoped-bank-rearm-v1/matched-timing-gpu-v1/README.md)
now passes on MI350: both same-binary modes complete all 40 prompt forwards,
four complete payload captures, healthy Close and all 11 supervised phases.
All records and selected payloads match each other and the historical baseline.
Allocation preflights are unchanged.

The new [bank-rearm tables and plots](../qualification/guarded-mlp-scoped-bank-rearm-v1/matched-timing-report-v1/README.md)
show warm-forward parent wall spans totaling 202.891 versus 109.926 seconds,
45.820% lower in the candidate. First-use totals are 25.965 versus 26.373
seconds, 1.570% higher. Total parent wall time, including setup and shutdown,
is 575.036 versus 485.255 seconds, 15.613% lower. This is one ordered pair,
not GPU time, overlap, generated-token throughput or a repeated benchmark.
The original archive and nine-test-qualified reporting source are published
with data-only reproduction commands.

The earlier native comparison is the
[Default/scoped warm-layer pair](../qualification/guarded-mlp-scoped-currentness-v1/matched-timing-gpu-v3/README.md).
Both modes use the same parent/worker products and reproduce all 40 prompt
records and four complete captured payloads, including the historical Position5
baseline. Parent wall time was 938.053 seconds for Default and 576.777 seconds
for scoped layers, 38.513% lower in this ordered pair. Frame waits totaled
591.558 and 230.370 seconds, respectively. The
[tables and plots](../qualification/guarded-mlp-scoped-currentness-v1/matched-timing-report-v3/table.md)
separate disjoint parent spans; they are not GPU kernel time, an overlap trace,
generated-token throughput or a repeated benchmark.

The bank-rearm ablation is now a bounded community engineering checkpoint,
with zero generated tokens. The position-5 prompt diagnostic remains unresolved;
it is not an own-generated token mismatch and does not justify forcing framework-equal
arithmetic or introducing a new tensor tolerance. The separate sustained
2,048/256 gate requires exact independently generated ID/decoded-byte agreement
and full-request numerical acceptance. The 700 tokens/s performance demo is
not yet ready.

The earlier
[Readiness40 SharedFull route](../qualification/guarded-mlp-readiness40-shared-full-v1/README.md)
now passes a fresh same-binary timed Default/SharedFull pair on MI350, with
all 40 semantic records and four complete payloads equal between modes and
the historical Position5 run. Both cases close cleanly with 11 naturally
retired phases. The timed parent passes 478 selected tests and the combined
timing/parity checker passes 53 synthetic tests. All 238 original pair members
are retained. The 950.197/495.231-second outer totals include setup and audits,
not decode throughput. The [tested wall-span plot and tables](../qualification/guarded-mlp-readiness40-shared-full-v1/matched-timing-report-v1/README.md)
now show parent timelines of 943.327/488.197 seconds, with frame-wait sums
59.987% lower. Seven report tests pass on MI350. This is one
ordered pair with intervening host work, not a repeated controlled benchmark.

The [scoped warm-layer currentness implementation](../qualification/guarded-mlp-scoped-currentness-v1/README.md)
passes its repaired 70-test synthetic checker and complete coupled CPU
qualification on MI350. V3 passed all 26 phases in 151.522 seconds: 1,143
runtime tests with eight existing ignores, 726 worker tests with four existing
ignores, nine focused runtime scopes and ten facade doctests. All 207 original
evidence members are retained. The separate parent V3 run also passes all 65
phases and 492 selected tests across 55 scopes in 411.247 seconds. Its 483
original evidence members are retained. The seven tested parent changes are
integrated, with a complete 1,263-file source postcheck and all 209 worker
bodies unchanged. The earlier module-path and test-type failures remain
preserved as failures. The subsequent same-binary Default/scoped GPU pair is
described above; it establishes bounded prompt-forward parity, not full decode
acceptance.

The [Full2303 independent reference](../qualification/guarded-mlp-full2303-v1/README.md)
has completed two fresh-cache BF16 framework passes of the 2,048/256 workload.
Both independently generated 256 outputs agree. The scoped Full2303 admission
and exact full-request comparison checker now passes 42 tests on MI350.
The [scoped Full2303 worker and parent](../qualification/guarded-mlp-full2303-scoped-currentness-v1/README.md)
are integrated after full coupled CPU qualification and 504 selected parent
passes across 56 scopes. Neither CPU qualification nor the independent
reference executes Ferric's Full2303 GPU route or resolves the earlier numerical
discrepancy. Actual full-request comparison remains open.

The new [bounded 40-position readiness route](../qualification/guarded-mlp-readiness40-v1/README.md)
passes MI350 CPU qualification: 658 worker tests with four unchanged ignores,
428 selected parent tests across 51 scopes, and 16 independent synthetic
data-checker tests. All nine worker and 60 parent supervised phases pass.
The explicit route accepts the authentic full prompt and 144-page KV mapping,
but executes only 40 prompt positions, generating zero tokens. Complete
captures are selected at positions 0, 15, 16 and 39. The first native attempt
now passes all 40 positions, all 11 supervised phases, healthy Close and clean
owned-process/device postchecks. The retained original transcript and four
captures pass the qualified independent data checker. Full 2,303-forward
native admission remains refused. Independent framework comparison,
full-workload numerical acceptance and performance remain separate gates.

The independent BF16 reference now completes two repeatable 40-position
full-model passes on MI350. The authenticated comparison reports 39/40 argmax
agreement, with position 5 differing (reference token 2; Ferric token 9112).
No position-5 tensor was retained by either original run. The four originally
captured positions show 0.30-0.69% logits relative L2 error;
these are diagnostics, not an acceptance threshold. The separately scoped
position-5 capture below does not establish full-model correctness.

The [position-5 diagnostic route](../qualification/guarded-mlp-readiness40-position5-v1/README.md)
is now integrated after 663 worker passes, 433 selected parent passes and
17/7 synthetic checker/comparator passes on MI350. Its independent BF16
reference completes two repeatable fresh-cache passes. Its native run now
passes all 40 forwards and clean Close in one attempt. The authenticated
cross-run comparison confirms unchanged all-40 records and common captures.
At position 5 the reference ties tokens 2/9112 at 19.625; Ferric scores token
9112 at 19.75, one BF16 step higher. Layer 0 already differs in 14/4,096 words.
This explains the argmax switch but not the arithmetic cause or numerical
acceptability; operation-level investigation remains open. The original
comparison now has a
[layer-by-layer error plot and complete tables](../qualification/guarded-mlp-readiness40-v1/numerical-report-v1/README.md),
rendered on MI350 after ten passing tests. These add diagnostic visibility,
not numerical acceptance or a performance claim.

The [exact two-row head check](../qualification/guarded-mlp-readiness40-position5-v1/head-exact-v1/RESULTS.md)
now passes 12 synthetic tests and four exact 4,096-term dots on MI350. All
four observed BF16 values match exact-dot rounding on their respective
captured inputs. The head inputs already differ; final rounding of these
two rows does not explain the upstream discrepancy. Operation-level
diagnosis and full-model acceptance remain open.

The [seven Gate/Up exact-dot diagnostic](../qualification/guarded-mlp-readiness40-causal-layer0-v1/gate-up-exact-v1/RESULTS.md)
passes 20 tests and original-weight/input checks on MI350. Among the seven
selected differing position-5 scalars with identical captured inputs, native
matches once-rounded exact BF16 in six cases and the framework in one. This
does not justify a framework-equality math patch or establish numerical
acceptance. All 18 original diagnostic files are retained.

The [opt-in paired-terminal runtime API](../qualification/guarded-mlp-terminal-pair-v1/README.md)
is integrated after 1,119 KFD tests, 658 unchanged worker tests, ten facade
doctests and 23 clean MI350 CPU phases. It coalesces terminal validation for
retired reusable arenas while preserving queue/signal/ownership checks.
The new [warm-only worker caller](../qualification/guarded-mlp-warm-paired-terminal-v1/README.md)
now selects it through a separate reusable AR4 profile, after 673 passing
worker tests and four unchanged ignores on MI350. The parent also passes
438 selected tests across 51 scopes and 60 phases; its three changes are
integrated. Twenty synthetic native comparison tests pass. The matched native
control/candidate pair now passes in one attempt per mode, with all four full
payloads and histories equal, exact warm-only dispatch counts and healthy
Close. The [per-layer host plot and tables](../qualification/guarded-mlp-warm-paired-terminal-v1/host-timing-v1/README.md)
pass seven fixture tests and rendering on MI350. Warm segment sums are
25.483% lower in this pair; first-use sums are 0.386% higher. This is not GPU
timing, a repeated controlled benchmark or end-to-end throughput. Existing
entries retain their behavior, and both earlier failed worker attempts remain
preserved.

The reviewed [700 tokens/s bandwidth budget](../qualification/guarded-mlp-terminal-pair-v1/roofline-v1/README.md)
joins checkpoint bytes and actual TP2 weight/cache placement. Conditional on
8 TB/s peak HBM bandwidth per device, current rank-0 placement gives a
1.044 ms/token streaming floor at the mean decode context. The target requires
73.1% of rank 0's peak before other nonoverlapped overhead. Actual SKU,
sustained bandwidth, cache traffic and attainability remain unmeasured.

Current GPU bring-up: the guarded parent and worker completed both four-step
teacher-forced and autoregressive runs on MI350, through all 36 layers and
both ranks. The fresh autoregressive outer controller passes in one attempt,
producing the own-output chain `9112 -> 67 -> 25 -> 576 -> 2701`, with healthy
Close and clean process/device postchecks. This is a four-step diagnostic,
not sustained 2,048/256 decode or a throughput claim.

The original teacher-forced outer controller still records failure: its worker-announcement parser
expected `finite engineering`, while the qualified parent prints
`finite guarded`. Independent examination of the retained process ancestry
and all 76 raw files confirms the worker identity and clean shutdown.
The failed receipt is not being rewritten as a pass. Six parser tests and
[separate data-only revalidation](../qualification/guarded-mlp-model-runtime-v1/README.md)
now pass on MI350, including three JSON round-trip regressions. The
[fresh autoregressive evidence](../qualification/guarded-mlp-model-runtime-v1/README.md)
uses the corrected parser. Independent model numerical acceptance and
sustained throughput remain open.

The [independent guarded-model comparison](../qualification/guarded-mlp-model-runtime-v1/numerical-v1/README.md)
now completes on MI350: all eight selected TF4/AR4 tokens match the existing
two-pass framework references, while all 304 complete tensor slices differ
in at least one BF16 word. Logit relative-L2 errors range from 0.30% to 1.17%.
Five adapter regressions pass and all 250 input rehashes/postchecks are clean.
This is a numerical diagnostic, not full-model acceptance or a speedup.

The [AR4 host-counter analysis](../qualification/guarded-mlp-model-runtime-v1/host-timing-v1/README.md)
now isolates 6.25-6.31 seconds per forward inside guarded MLP dispatch spans,
including host preparation and currentness checks. Four parser regressions and
all 19 input posthashes pass on MI350. These are not GPU kernel timings or
complete-forward latency. The new
[guarded host-observation mode](../qualification/guarded-mlp-model-host-observation-v1/README.md)
passes fresh MI350 CPU qualification: 601 worker passes with four unchanged
ignores, 387 selected parent passes, and all 14 report/topology checker tests.
Its 587-snapshot schema separates layer boundaries while preserving the
existing runtime policy and GPU images. The native run now passes in one
attempt: 11 clean phases, healthy Close, and all four full observation payloads
byte-identical to ordinary AR4. Paired segments record 2,016 full-currentness
checks per rank per forward, motivating a separate shared-full-observation
experiment. Inclusive host counters cannot establish GPU overlap or throughput.

The opt-in [shared-full-currentness successor](../qualification/guarded-mlp-model-host-shared-currentness-v1/README.md)
now passes MI350 worker qualification: 607 passes, four unchanged ignores,
and all 15 report/topology checker tests. Six tested worker postimages are
integrated; all 184 worker source bodies join the actual qualification map.
It shares one fresh topology read within a group fence, retaining device and
queue checks and the conservative default. The parent also passes all 55
qualification phases and 391 selected tests across 47 scopes. Its two tested
changes are integrated; all 1,222 composed Ferric sources join the actual CPU
maps. The native shared-mode run now passes in one attempt with healthy Close
and all four complete payloads byte-identical to conservative and ordinary
AR4. The [plot and attribution](../qualification/guarded-mlp-model-host-shared-currentness-v1/comparison-v1/README.md)
show observed forward host brackets falling from 12.808-15.384 seconds to
5.598-6.271 seconds. Paired counters match the source prediction: 216 individual
checks per rank plus 900 group checks, versus 2016 individual checks per rank.
All 16 analysis tests and 27 input posthashes pass. This is one observation
per mode, not a controlled repeated benchmark, GPU overlap or sustained decode.

The [current captured R2 boundary replay](../qualification/guarded-mlp-model-current-r2-replay-v1/README.md)
also passes on MI350: 20 tests, all 8,192 native final-hidden encodings and
all 4,096 separate framework residual-control encodings match exactly. It
uses actual layer-zero, position-zero Down partials and first residuals,
with 24 clean input posthashes and no GPU/model rerun. An initial malformed
test-fixture failure remains retained; only that fixture and the fresh output
namespace changed for the successful attempt. This does not replay the Down
dot products or establish full-model numerical acceptance. The new
[matched-input MLP diagnostic](../qualification/guarded-mlp-model-matched-input-v1/README.md)
passes all 20 CPU regressions and four actual framework MLP calls on MI350
gfx950. Both original-input calls reproduce all ten historical stages byte-for-byte;
both native-input calls also repeat exactly. With identical MLP inputs,
36,848/36,864 native gate/up/product BF16 words match the framework. Eight gate/up
words differ by one BF16 step and eight product words by at most two. The
[table and plot](../qualification/guarded-mlp-model-matched-input-v1/README.md#actual-gpu-result)
isolate input propagation from arithmetic differences, not a performance gain.
All source/input postchecks and container retirement pass. Different
PyTorch/Python/NumPy versions remain explicit; this is not full-model acceptance.

The new [opt-in reusable-arena runtime](../qualification/guarded-mlp-reusable-arena-v1/README.md)
passes all 21 MI350 CPU phases: 1,101 KFD tests with eight unchanged ignores,
ten facade doctests, and 607 unchanged-worker tests with four unchanged ignores.
Its 14 tested postimages are integrated in fe2o3 `00e49fd8b0`. Private consuming
retirement proofs permit completed signal/kernarg arenas to be reused without
raising allocation limits or changing the fresh default. The initial Rustdoc
parser failure remains retained; eight parser regressions and a fresh full rerun
pass. This removes the runtime implementation blocker behind the fresh path's
forward-38 allocation limit. The [opt-in reusable AR4 worker](../qualification/guarded-mlp-reusable-ar4-v1/README.md)
now passes all nine MI350 CPU phases: 615 tests pass with four unchanged ignores.
Its twelve tested postimages are integrated, and all eight synthetic allocation
census checks pass. The parent also passes all 55 phases and 396 selected tests;
its three tested postimages are integrated. All 1,222 composed Ferric source
files join the actual CPU maps, and four separate payload-comparison checks
pass. The native MI350 run now passes in one attempt: actual allocation counts
plateau at 787/783 after both banks' first use, all four complete payloads and
input histories match ordinary AR4, and healthy Close plus all eleven owned
phases and device postchecks pass. The [allocation plot and table](../qualification/guarded-mlp-reusable-ar4-v1/README.md#native-result)
show measured capacity reuse, not throughput. The four-forward sequence limit,
bounded long-request transport, numerical acceptance and sustained performance
remain separate gates; no full 2,048/256 or 700 tokens/s claim is made.

The [paired hidden-read experiment](../qualification/guarded-mlp-peer-read-pair-v1/README.md)
now has an MI350-qualified runtime, parent, and corrected worker. The first
native comparison passed its control case, then failed before paired worker
bootstrap because of a CLI fallback routing omission. That failure and clean
shutdown evidence remain retained. The correction passes 623 worker tests
with four unchanged ignores, including two actual-executable routing tests.
The fresh comparison harness passes 26 tests and its graph generator passes
seven synthetic tests. A fresh native ABBA comparison now passes all four cases,
all 16 complete payload comparisons, and all 44 supervised phases. The
[plot and tables](../qualification/guarded-mlp-peer-read-pair-v1/README.md#native-comparison)
show a 71.9% reduction in outer hidden-read host wall time: 2,053.659 to
576.163 ms per four-forward run, averaging two independent runs per mode.
This is a host read-phase diagnostic, not GPU time, kernel overlap, sustained
decode or an end-to-end speedup. No result is inferred from the failed prefix.

The [historical O-projection replay](../qualification/o-projection-exact-replay-v1/README.md)
now completes on MI350 with 18 passing tests. All 8,192 captured FP32 partials
match the pinned kernel's modeled accumulation order. The derived native BF16
projection matches the once-rounded exact dot in 4,095 of 4,096 rows, versus
4,093 for the framework. The three differing projection rows and conditional
residual replay are fully retained. This explains isolated reduction-order
differences; it does not replace current guarded-stage capture, full-model
numerical acceptance, or a sustained performance measurement.

The [capture-enabled worker and parent pass fresh MI350 CPU qualification](../qualification/guarded-mlp-model-stage-capture-v1/README.md):
591 worker passes, four unchanged ignores, and 380 selected parent passes.
All nine worker and 54 parent phases pass, including the required executable
builds; source/dependency/cache/process postchecks are clean. The eight worker
and four parent changes are integrated from their tested, formatted bodies.
The separate capture/parser gate passes all 12 tests. This distinct opt-in mode
retains 34 layer-zero tensor parts only after healthy Close, without changing
kernel images or splitting the guarded segment. The fresh GPU capture now
passes in one attempt with healthy Close, 11 clean process phases and all
34 parts verified. Its four complete observation payloads are byte-identical
to the previous uncaptured guarded AR4 run. The
[independent current-stage diagnostic](../qualification/guarded-mlp-model-stage-capture-v1/numerical-v2/README.md)
also completes: eight tests, 200 clean input posthashes, and 12/26 complete
BF16 rows bit-exact. The first Q-projection difference is one word/one BF16 step;
layer-zero hidden relative L2 is 0.0591548%. All 32 primary/component metric rows
are independently recomputed from the bytes. Full-model numerical acceptance
remains open; this is not sustained decode or a throughput measurement.

Current integration: [the guarded parent passes 375 selected tests and all 54 CPU phases on MI350](../qualification/guarded-mlp-parent-cpu-v1/README.md).
All five selected parent binaries build, with clean source, dependency, cache
and process postchecks. This does not execute the entire parent library suite
or establish native model correctness. The earlier cache and toolchain
failures remain retained; the passing run uses Rust 1.97.1 without changing
the lockfile or minimum-version requirement.

The [guarded model observation validator passes all nine synthetic tests on MI350](../qualification/guarded-mlp-model-validator-cpu-v1/README.md).
This is a data-checker result, not model numerical acceptance. The
[parent build record](../qualification/guarded-mlp-parent-cpu-v1/README.md)
retains the private Git-cache and toolchain failures. Subsequent native
TF4/AR4 execution is recorded above; independent numerical acceptance remains
open.

Earlier integration: [the guarded model worker passes MI350 CPU qualification](../qualification/guarded-mlp-worker-cpu-v1/README.md).
All 586 tests pass with four deliberate ignores, including the 24 new tests,
and the final worker executable builds. The 19 tested worker source files and
their 29 cumulative runtime prerequisites are now integrated on engineering
branches. A real stack-overflow found during qualification is fixed by keeping
the large control payload on the heap; the wire format and default stack limit
are unchanged. Subsequent parent integration and real-model mixed-bank
execution are recorded above; independent numerical acceptance and sustained
throughput remain open.

Current runtime work: [the guarded model interface passes CPU and native component tests](../qualification/guarded-mlp-model-interface-v1/README.md).
MI350 qualification records 1,088 ordinary test passes, eight deliberate ignores,
nine compile-fail API tests, and a single successful GPU attempt through the
public allocation/binding/dispatch facade. The independent reference checks
557,056 computed values bit-for-bit. A new mixed Prefix284/Combined552 bank
transaction has 12 passing CPU tests. Subsequent native mixed-bank and
real-model TF4/AR4 execution are recorded above; independent numerical
acceptance remains open. This does not establish sustained decode or a
performance-demo date. The linked checkpoint lists the next demo gates.

Earlier runtime diagnosis: [fresh-process repeats reproduce the guarded MLP binary discrepancy](../qualification/guarded-mlp-interleaved-native-v1/README.md#fresh-process-repeats).
The unchanged original host executable fails twice at the typed allocation-role
check; the diagnostic-only executable passes twice, each with 557,056 bit-exact
computed values and the complete delayed two-bank reuse ledger. Both fresh
repeats ran on MI350 with clean process retirement and idle GPUs afterward.
This is synthetic component evidence, not a model-layer chain or throughput.
The cause of the host-binary difference remains open, ahead of full-model
integration and any live community performance demo.

Earlier compiler qualification: [the atomic-load alias refinement passes MI350 CPU qualification](../qualification/guarded-mlp-atomic-load-alias-v1/README.md).
All 176 phases and 77 scopes pass: 839 kernel-IR, 1,323 compiler and 1,516
Pliron executions, plus 162 focused repeats and extraction controls, total
3,840 passes and 26 ignores. The nine new alias tests and two existing
descriptor rejection controls pass. Sources, dependencies, artifacts and
process postchecks are clean. This is an explicit semantic alias-admission
refinement: atomic loads are not writers, while stores and read-modify-write
operations still require separation. Atomic identity, receipt encoding,
bounds/race and descriptor ownership checks remain unchanged. The
[fourteen actual binary-loader checks pass](../qualification/guarded-mlp-atomic-load-alias-tool-audit-v1/README.md)
with clean postchecks. [Actual guarded lowering now passes](../qualification/guarded-mlp-atomic-load-alias-lowering-v1/README.md)
and retains a 28,440-byte gfx950 HSACO with both v2 kernel exports.
No GPU, model-numerical or performance acceptance follows from the CPU run.
[34 tool-audit controller tests](../qualification/guarded-mlp-atomic-load-alias-tool-audit-v1/README.md)
and [31 lowering-controller tests](../qualification/guarded-mlp-atomic-load-alias-lowering-v1/README.md)
also pass on MI350 with clean source and process postchecks. These are
synthetic admission tests, distinct from the passing actual binary audit and
passing guarded compile. Runtime admission, GPU execution and independent
numerical tests remain separate open gates.
The [actual metadata and ISA review](../qualification/guarded-mlp-atomic-load-alias-lowering-v1/IMAGE-REVIEW.md)
records the two successful inspection-tool runs. R2's guard branch is
wave-wide any-valid without a visible per-lane execution mask. The intended
stable-guard lifecycle may make that equivalent, but its premise is not
established by the image; compiler uniformity and runtime custody remain
under investigation before GPU admission.

Previous compiler qualification: [the bounded memory-bounds DAG solver passes MI350 CPU qualification](../qualification/guarded-mlp-memory-bounds-dag-v1/README.md).
All 45 phases and 32 scopes pass: 1,323 compiler and 1,516 Pliron tests,
with focused repeats and extraction controls totaling 2,990 passing executions
and 25 unchanged ignores. The nine new tests pass full and focused suites.
All children exit naturally, are reaped and leave no process groups; source,
dependency and process postchecks are clean. The
[14 actual binary-loader checks pass](../qualification/guarded-mlp-memory-bounds-dag-tool-audit-v1/README.md),
as do 26 loader and 19 lowering controller fixtures. The
[new guarded compile reaches allocation alias analysis](../qualification/guarded-mlp-memory-bounds-dag-lowering-v1/README.md)
and fails because relative base offsets between two potentially aliasing
origins are unavailable. This is a missing-proof refusal, not an observed GPU
race. No guarded HSACO or GPU acceptance is established. Existing admitted inputs keep their
exact old bound and solver;
the new route requires a runtime-validated DAG and zero ownership contracts.
That generation changed no work limit, access predicate or atomic ordering.

The [combined-state candidate passes MI350 CPU qualification](../qualification/guarded-mlp-combined-state-cpu-v1/README.md):
all ten phases and 39 tests pass, with clean source, dependency and process
postchecks. Its versioned validator takes one genuine 552-word atomic allocation,
keeping the old 548-word API unchanged. Both earlier test-related failures
remain retained. The exact passing Rust sources are in the experimental v2 crate.
The [matching owner passes full runtime CPU qualification](../qualification/guarded-mlp-combined-state-owner-v1/README.md):
1,008 KFD passes, three unchanged ignores and 14 focused passing repeats.
The owner remains isolated from the canonical runtime and inference path.
The new alias-qualified backend now compiles the guarded gfx950 image;
GPU execution remains unqualified. Separately,
[25 combined-state lowering-controller fixtures pass](../qualification/guarded-mlp-combined-state-lowering-v1/README.md).
They are synthetic admission tests, not a new kernel compile or GPU result.
The [offline vendor preparation also passes](../qualification/guarded-mlp-combined-state-vendor-v1/README.md).
The subsequent real combined-state compile failed at descriptor admission,
as recorded below; a passing candidate CPU suite is not successful lowering.

Previous completed compiler qualification: [bounded chain fusion passes on MI350](../qualification/guarded-mlp-ranked-cfg-linear-fusion-v1/README.md).
All 44 phases and 31 test scopes pass: 1,323 compiler and 1,507 Pliron tests,
with focused repeats and extraction controls totaling 2,972 passing executions
and 25 unchanged ignores. Sources, dependencies and process postchecks are clean.
The [parser correction passes 17 separate MI350 checks](../qualification/guarded-mlp-libtest-progress-parser-v1/README.md);
V3 controller fixtures pass 26 loader and 19 lowering tests. Both earlier failed
CPU attempts remain retained unchanged. All
[14 fresh binary-loader checks pass](../qualification/guarded-mlp-ranked-cfg-linear-fusion-tool-audit-v1/README.md),
and the fresh guarded compile reported a memory-bounds preflight refusal.
No guarded HSACO, GPU, model or performance acceptance is established by this
compiler qualification.

Latest retained guarded lowering: [the atomic-load alias attempt passes](../qualification/guarded-mlp-atomic-load-alias-lowering-v1/README.md)
after 394.288906 seconds (399.441433 seconds for the whole controller).
The child exits naturally, is reaped and leaves no process group. The 5,308
source rows and 308 input pins are unchanged, with clean postchecks. Both
the exact-output-replay observation and its 28,440-byte code-object-6 HSACO
are retained. All publication/load/launch grants remain false. Image
inspection is retained with the caveat above; the private atomic-read runtime
join still precedes GPU tests.

Previous retained guarded lowering: [the combined-state attempt](../qualification/guarded-mlp-combined-state-lowering-v1/README.md)
exits naturally with status 1 after 363.190239 seconds (366.924882 seconds
for the whole controller). It reports an internal formal-alias obligation
not discharged by Rust ownership at descriptor construction. Raw output
identifies no root, caller or parameter pair. Source/input and process
postchecks are clean; no artifact was produced by that earlier attempt.

Earlier guarded lowering: the DAG-qualified compiler exits naturally with
status 1 after 132.322763 seconds at `FE2O3-RACE-002`, with clean source/input
and process postchecks. The rendered guard graph is byte-identical to the
prior memory-bounds refusal: 567 blocks, 1,122 edges, 2,240 operations and 552
bounds guards. No artifact is produced. Compiler alias proofs and an explicit
state/guard allocation contract are being investigated without inventing
relative offsets or relaxing safety checks.

Previous guarded lowering: [chain fusion reaches the memory-bounds preflight](../qualification/guarded-mlp-ranked-cfg-linear-fusion-lowering-v1/README.md).
The actual MI350 compile renders 567 blocks, 1,122 edges and 2,240 operations,
down from the prior 1,675 / 2,230 / 3,348. Independent reconstruction reproduces
all 1,108 chain merges and each resulting block's ordered operations, predicates
and targets. All 548 Acquire reads, three Relaxed writes and one Release write
are preserved. The child exits naturally with status 1 after 127.021051 seconds
and is reaped, with 214 unchanged input pins, unchanged sources and clean
postchecks. No HSACO is produced.

That earlier memory-bounds refusal is a static upper-bound estimate, not runtime-counter
exhaustion. One intersection-work term alone is 9,340,170, above the unchanged
8,388,608 cap. The graph is a DAG with 552 distinct bounds facts. The CPU-qualified
candidate is an authenticated topological schedule with matching one-pass
execution and admission accounting. No structural or resource limit is being
raised, and all bounds predicates remain. The compiler source, nine tests,
both failed CPU qualifications and the passing third qualification are retained.

The [previous compaction-only guarded compile](../qualification/guarded-mlp-ranked-cfg-compaction-lowering-v1/README.md)
rendered 1,675 blocks and 2,230 raw edges, failing the independent 1,024-block
identity limit. Its diagnostic's 1,025 was the first refused count, not the
graph total. This historical failure remains retained unchanged.

The [CFG compaction change passes full MI350 CPU qualification](../qualification/guarded-mlp-ranked-cfg-compaction-v1/README.md).
It shares eligible empty trap blocks and fuses successful accesses with their
continuations, preserving predicates, atomic effects, source/wave identities,
and all resource limits. Nine new regression tests cover differential traces,
layout identities, refusals, and block/edge boundaries. All 43 phases passed
across 30 scopes: 1,314 compiler tests and 1,507 Pliron tests, with focused
repeats and extraction controls totaling 2,954 passing executions and 25
unchanged ignores. Source/dependency and process cleanup checks are clean.
All 26/19 controller fixtures and 14 actual loader checks also pass.
Guarded lowering still fails as described above. This is not GPU, numerical, or
performance acceptance; all milestones and the 700 tokens/s target remain open.

Previously, [the guarded compile identifies the exact CFG expansion blocker](../qualification/guarded-mlp-ranked-cfg-expansion-diagnostic-lowering-v1/README.md).
The state-guard kernel `ferric_qwen3_mlp_state_guard_v1` projects to 2,778
blocks against the unchanged 2,048 limit; its declared semantic body has
1,121 blocks. The child exits naturally with status 1 after 117.460291
seconds, is reaped and leaves no process group. Sources and postchecks are
clean; no HSACO is produced. This attribution comes from pinned raw stderr,
not the controller's unchanged predeclared diagnostic-identification flags.
The subsequent compaction work targeted generated trapping-control blocks,
preserving every bounds check and atomic effect without raising that limit.

The [bounded projected-CFG diagnostic passes full MI350 qualification](../qualification/guarded-mlp-ranked-cfg-expansion-diagnostic-v1/README.md).
All 42 phases pass across 29 scopes: 1,305 compiler and 1,507 Pliron tests,
with focused repeats and extraction controls totaling 2,936 passing
executions and 25 unchanged ignores. The loader/lowering fixtures pass
26/19 tests, and all 14 fresh binary-loader checks pass. Source, dependency
and process cleanup checks remain clean. This diagnostic-only change reports
the existing projected block count and root context without increasing the
2,048-block limit or changing admission. This qualification and the failed
guarded attempt establish no HSACO, GPU, model numerical or
performance result. All milestones and the 700 tokens/s target remain open.

Previously, [the borrow-lookup-qualified guarded compile reaches a ranked block-limit refusal](../qualification/guarded-mlp-indexed-atomic-borrow-lookup-lowering-v1/README.md).
The [new compiler qualification](../qualification/guarded-mlp-indexed-atomic-borrow-lookup-v1/README.md)
passes all 41 phases across 28 scopes: 1,302 compiler and 1,507 Pliron tests,
with focused repeats and extraction controls totaling 2,930 passing
executions and 25 unchanged ignores. The loader/lowering fixtures pass 26/19
tests, and all 14 real binary-loader inspections pass. The guarded compiler
then exits naturally with status 1 after 117.666543 seconds; it is reaped,
leaves no process group, and preserves source/input checks with no posterrors.
Its raw diagnostic is `semantic CFG projection exceeds the ranked block limit`.
Qualified-source inspection ties that message to projected CFG expansion,
but the failing root and expanded count are not yet recorded. No HSACO,
GPU, alias verdict, model numerical or performance result is produced.
The next step is a bounded diagnostic, not an unmeasured limit increase.
All milestones and the 700 tokens/s target remain open.

Previously, [the use-lookup-qualified guarded compile reaches the address-permission scan](../qualification/guarded-mlp-indexed-atomic-use-lookup-lowering-v1/README.md).
The actual rejection is now `permits_address` at `indexed_atomic_v1.rs:84:14`:
a 1,656-unit scan would raise graph work from 3,145,230 to 3,146,886, above
the unchanged 3,145,728 limit. The compiler exits naturally after 117.361738
seconds and is reaped, with unchanged sources and clean postchecks. All
[14 fresh loader inspections](../qualification/guarded-mlp-indexed-atomic-use-lookup-tool-audit-v1/README.md)
passed. No HSACO, GPU, alias verdict or model result is produced. A bounded
address lookup is being investigated; no milestone or performance target is
closed.

Previously, [the bounded atomic-use lookup passes full MI350 CPU qualification](../qualification/guarded-mlp-indexed-atomic-use-lookup-v1/README.md).
All 40 phases pass across 27 scopes: 1,293 compiler tests and 1,507 Pliron
tests, with focused repeats and extraction controls totaling 2,912 passing
executions and 25 unchanged ignores. Every child exited naturally and was
reaped, with unchanged inputs and clean postchecks. The lookup reduces the
measured 552-entry query's analytical bound to ten comparisons without new
storage or increased limits. Controller fixtures pass 26 loader and 19
lowering tests after a production adapter schema repair; its failed first
attempt is retained. CPU qualification alone does not establish guarded
compilation, GPU/model correctness or performance. All milestones remain open.

Previously, [the census-qualified guarded compile reaches the atomic-use lookup work charge](../qualification/guarded-mlp-indexed-atomic-dead-cast-census-lowering-v1/README.md).
The compiler now reports `validate_statement` at `indexed_atomic_v1.rs:101:14`:
a 552-entry scan requests work at 3,145,488, exceeding the unchanged 3,145,728
ceiling. The compile exits naturally after 117.357422 seconds, is reaped, and
leaves no process group; sources and postchecks are clean. No HSACO or GPU
result is produced. A bounded lookup over the existing ordered use inventory
is the next candidate, not a work-limit increase.

The [bounded dead-cast census](../qualification/guarded-mlp-indexed-atomic-dead-cast-census-v1/README.md)
passed full MI350 qualification: 39 phases, 26 scopes, 2,894 passing executions
and 25 unchanged ignores. Compiler and Pliron suites pass 1,284 and 1,507 tests.
The [fresh tools](../qualification/guarded-mlp-indexed-atomic-dead-cast-census-tool-audit-v1/README.md)
pass 14 loader checks. Controller fixtures pass 26 and 19 tests after a
test-data-only repair to the loader's positive fixture; that failed first
attempt remains retained. These are compiler and admission results, not
model numerics or performance. All milestones remain open.

Previously, [the membership-qualified guarded compile reaches a new work-limit charge site](../qualification/guarded-mlp-indexed-atomic-membership-lowering-v1/README.md).
The actual rejection is now in `indexed_atomic_temporary_unused_v1`, at
`indexed_atomic_dead_cast_v1.rs:99:23`: a statement scan requests one work unit
with the counter already at the unchanged 3,145,728 limit. The child exits
naturally after 117.360708 seconds and is reaped with clean source/input
postchecks. No HSACO or GPU result is produced. All 14 fresh loader inspections
passed. A bounded local-mention census is being investigated to remove repeated
whole-function scans; it is not yet implemented or qualified. All milestones
remain open.

Previously, [the bounded membership lookup passes full MI350 CPU qualification](../qualification/guarded-mlp-indexed-atomic-membership-v1/README.md).
All 38 phases pass: 1,275 compiler tests and 1,507 Pliron tests, with focused
repeats and extraction controls totaling 2,876 passing executions across 25
scopes. The same 25 historical ignores remain explicit. Sources, dependencies
and cleanup checks are clean. The updated [loader controller](../qualification/guarded-mlp-indexed-atomic-membership-tool-audit-v1/README.md)
and [lowering controller](../qualification/guarded-mlp-indexed-atomic-membership-lowering-v1/README.md)
also pass 26 and 19 synthetic fixtures. This compiler-analysis optimization
reduces the measured 1,656-entry query's bound to 11 comparisons without new
storage, changed semantic predicates or higher limits. Actual guarded
compilation and GPU/model evaluation remain separate, uncompleted gates;
no speedup or milestone closure is claimed.

Previously, [the guarded compile identifies the exact work-limit charge site](../qualification/guarded-mlp-ranked-graph-work-diagnostic-lowering-v1/README.md).
The MLP state-guard kernel fails in `AuthenticatedAtomicAllocationsV1::contains_local`:
a charge for a 1,656-entry membership query attempts to move the work counter
from 3,144,193 to 3,145,849, exceeding the unchanged 3,145,728 limit. The new
deployment passes
[all 14 loader inspections](../qualification/guarded-mlp-ranked-graph-work-diagnostic-tool-audit-v1/README.md).
The compile exits naturally with clean source, input and process postchecks;
no HSACO or GPU result is produced. A bounded lookup over the already sorted
membership list is the next optimization, not a limit increase. No milestone
or model-performance target is closed.

Previously, [the corrected graph-work diagnostic passes full CPU qualification](../qualification/guarded-mlp-ranked-graph-work-diagnostic-v1/README.md).
All 37 phases pass on MI350: 1,266 compiler tests and 1,507 Pliron tests,
with focused repeats and extraction controls totaling 2,858 passing executions
across 24 scopes. All 25 historical ignores remain explicit. Sources,
dependencies and cleanup checks are clean. Only one test assertion changed
from the retained failed first attempt. The graph-work ceiling and production
predicates remain unchanged. Actual guarded lowering, GPU execution, independent
model numerics and sustained performance remain separate gates.

Previously, the diagnostic generation's [26 loader-controller tests](../qualification/guarded-mlp-ranked-graph-work-diagnostic-tool-audit-v1/README.md)
and [19 lowering-controller tests](../qualification/guarded-mlp-ranked-graph-work-diagnostic-lowering-v1/README.md)
pass on MI350. Both bounded children exited naturally and were reaped with
unchanged sources and clean postchecks. These synthetic tests do not establish
actual loader inspection or guarded HSACO/GPU execution. The corrected
compiler's full qualification is still running; no milestone is closed.

Previously, [the graph-work diagnostic build exposes one incorrect test expectation](../qualification/guarded-mlp-ranked-graph-work-diagnostic-v1/README.md).
The MI350 compiler suite reports 1,265 passed, one failed and 24 ignored;
Pliron passes 1,507 tests with one ignore. The failing fixture expects a
graph-budget error on a path that first encounters the unchanged alias-budget
overflow. Its correction changes only that assertion and checks counter
preservation. The failed attempt is retained; full requalification is required.
No loader, guarded compile or GPU run used the failed generation.

Previously, [the DAG-qualified guarded compile still reaches the graph-work limit](../qualification/guarded-mlp-indexed-atomic-dag-lowering-v1/README.md).
The real compiler process exited naturally after 117.555086 seconds, with
unchanged source and clean postchecks. No HSACO or GPU execution resulted.
The [fresh deployment passed all 14 loader checks](../qualification/guarded-mlp-indexed-atomic-dag-tool-audit-v1/README.md),
but the DAG cache did not remove the measured rejection. Its function and
charge site remain unidentified. Bounded failure-path instrumentation is next;
the work ceiling and safety predicates are not being relaxed.

Previously, [the cached indexed-atomic DAG experiment passes full CPU qualification](../qualification/guarded-mlp-indexed-atomic-dag-v1/README.md).
All 36 phases pass on MI350, including 1,257 compiler and 1,507 Pliron tests.
Focused repeats and extraction controls bring the total to 2,840 passing
executions; the 25 historical ignores remain explicit. Sources, dependencies
and process cleanup checks are clean. The graph-work ceiling stays unchanged.
This result does not establish that the guarded kernel compiles; actual
lowering, GPU execution, model numerics and performance remain separate gates.

Previously, the DAG generation's [26 loader-controller fixtures](../qualification/guarded-mlp-indexed-atomic-dag-tool-audit-v1/README.md)
and [19 lowering-controller fixtures](../qualification/guarded-mlp-indexed-atomic-dag-lowering-v1/README.md)
pass on MI350. Both bounded children exited naturally and were reaped with
unchanged sources and clean postchecks. These are synthetic admission tests,
not actual loader, HSACO or GPU results. Full compiler qualification is
still finishing extraction controls; no milestone is closed.

Previously, [guarded gfx950 lowering reaches the independent CFG-analysis work limit](../qualification/guarded-mlp-ranked-cfg-cap-lowering-v2/README.md).
The earlier block-count rejection is no longer reported. The new diagnostic
does not identify the function or charge site, and does not establish whether
alias checks pass or fail. The compiler exited naturally after 117.958347
seconds and was reaped with clean integrity checks. The refreshed deployment
passed [all 14 loader inspections](../qualification/guarded-mlp-ranked-cfg-cap-tool-audit-v2/README.md).
No HSACO or GPU result is claimed. The next work is to identify and reduce
repeated graph analysis under the unchanged work ceiling; all milestones
remain open.

Previously, [the bounded CFG capacity experiment passes full CPU qualification](../qualification/guarded-mlp-ranked-cfg-capacity-v1/README.md).
The corrected second attempt passes all 35 phases on MI350: 1,248 compiler
and 1,507 Pliron tests, with focused repeats and extraction controls bringing
the total to 2,822 passing executions. All 25 historical ignores remain
explicit. Every child exited naturally and was reaped, with unchanged
sources and clean postchecks. Only the block cap expands; independent edge,
fact, work and storage limits remain unchanged. The failed first attempt is
retained. Fresh loader inspection and actual guarded gfx950 lowering are
separate gates; this is not a GPU, model-numerics or performance result.

Previously, the capacity generation's [26 loader-controller fixtures](../qualification/guarded-mlp-ranked-cfg-cap-tool-audit-v2/README.md)
and [19 lowering-controller fixtures](../qualification/guarded-mlp-ranked-cfg-cap-lowering-v2/README.md)
pass on MI350. Each bounded child exited naturally and was reaped with clean
source and tool postchecks. These are synthetic admission tests, not an
actual binary-loader audit or guarded HSACO result. The corrected full
compiler qualification remains pending; no milestone is closed.

Previously, [the bounded block-cap experiment reaches one inherited fixture failure](../qualification/guarded-mlp-ranked-cfg-capacity-v1/README.md).
The Pliron library passed 1,507 tests with one historical ignore. The compiler
library's raw output reports 1,247 passed, one failed and 24 ignored, so this
generation is not qualified. The failing positive switch fixture still tied
its raw-edge count to the block cap and exceeded the unchanged edge budget.
The retry corrects that fixture to the exact edge boundary without changing
the production edge check. All fifteen processes exited naturally and were
reaped with clean integrity checks. No fresh loader, HSACO or GPU result is
claimed; all milestones remain open.

Previously, [the diagnostic identifies 1,121 blocks in the MLP state-guard kernel](../qualification/guarded-mlp-ranked-cfg-lowering-v1/README.md).
The actual gfx950 lowering retry rejects `ferric_qwen3_mlp_state_guard_v1`
against the unchanged 1,024-block cap before loop analysis. The compiler
exited naturally and was reaped with clean integrity checks; no HSACO or GPU
execution occurred. The refreshed deployment passed fourteen loader checks.
Separate synthetic runs passed 24 loader and 17 lowering fixtures. A bounded
block-cap experiment with independent edge, fact and work limits is recorded
above; it changes no current production authority.

Previously, [the corrected ranked CFG diagnostic passes full CPU qualification on MI350](../qualification/guarded-mlp-ranked-cfg-diagnostic-v1/README.md).
All 33 phases exited naturally and were reaped, with unchanged sources and
clean integrity checks. The compiler passed 1,247 tests and pliron passed
1,504; focused repeats and extraction controls bring the total to 2,814
passing executions, not unique tests. All 25 historical ignores remain
explicit. The first attempt's compile failure is retained alongside the fix.
The CFG limit and atomic rules remain unchanged. The actual rejected
function/count is now recorded above; no HSACO/GPU, numerical or performance
milestone is closed.

Previously, [optimized-inlining guarded lowering reaches the ranked CFG limit on MI350](../qualification/guarded-mlp-lowering-attempt-v3/README.md).
The earlier atomic-ordering rejection is no longer observed. The new failure
occurs during semantic-to-ranked projection before loop analysis; the message
does not identify the function or actual block count. The compiler exited
naturally after 117.371 seconds and was reaped, with unchanged sources and
clean integrity checks. Fifteen synthetic controller fixtures passed
separately. No HSACO was emitted; this does not establish whether the possible
alias issue passes or fails.
Bounded diagnostics and a smaller equivalent CFG are the next investigation;
no verifier limit or production authority is relaxed.

Previously, [the refreshed driver deployment passes all fourteen loader checks on MI350](../qualification/guarded-mlp-s-rpo-tool-audit-v2/README.md).
Only the driver changes; the other six tools and full combined compiler
provenance remain intact. Eighteen synthetic loader-admission fixtures passed
separately. All actual inspections exited naturally and were reaped, with
clean integrity checks. The optimized-inlining guarded lowering retry is
next; this is not an HSACO, GPU, model-correctness or performance result.

Previously, [the updated engineering driver builds and passes its 18 focused tests on MI350](../qualification/guarded-mlp-driver-cpu-v1/README.md).
All seven phases exited naturally and were reaped, with unchanged sources and
clean postchecks. The complete 402-name compiled inventory and five ignored
names are retained, but the full driver suite was not executed. The final
driver now supports explicit optimized MIR inlining, matching the passing
atomic extraction control. A fresh loader audit and guarded lowering retry
are next; no GPU, model-correctness or performance milestone is closed.

Previously, [the refreshed guarded gfx950 lowering reaches an atomic-ordering rejection](../qualification/guarded-mlp-lowering-attempt-v2/README.md).
The previous provider-source mismatch is no longer the observed failure.
Source collection now rejects a core atomic load without a concrete ordering
argument. The compiler exited naturally after 117.259 seconds and was reaped;
integrity postchecks passed, with no timeout, forced cleanup or HSACO.
Seven synthetic controller tests passed separately. The expected alias gate
was not reached. The next attempt uses the qualified newer driver's explicit
normalization mode; atomic admission rules remain unchanged.

Previously, [the final runtime compiler binaries passed all fourteen loader checks](../qualification/guarded-mlp-s-rpo-tool-audit-v1/README.md).
The extractor resolves the exact new backend; the other five deployed tools
are unchanged. All inspection leaves exited naturally and were reaped, with
clean postchecks. Ten synthetic loader-admission tests passed separately.
The [guarded candidate dependency refresh also passes its 27 CPU tests](../qualification/guarded-mlp-dependency-refresh-v1/README.md).
Its two dependency pins now select published fe2o3 `5a500d63`, with unchanged
Rust kernels and guard protocol. These checks do not close guarded gfx950
lowering/GPU, independent model numerics or performance. All milestones remain
open. Fresh offline vendoring also passed for 145 packages with unchanged
sources and lockfiles; the new guarded gfx950 lowering attempt is next.

Previously, [the full combined runtime compiler qualification passed on MI350](../qualification/guarded-mlp-s-rpo-qualification-v1/README.md).
All 32 phases exited naturally and were reaped, with clean integrity checks.
The full compiler library passed 1,239 tests and pliron passed 1,504; 43
focused repeats and twelve extraction/rejection controls bring the total to
2,798 passing executions, not unique tests. All 25 historical ignores remain
explicit. Eleven synthetic controller tests passed separately. Final build
products and the exact derived source lineage are retained. Loader inspection,
guarded gfx950 HSACO/GPU execution, model numerics and performance remain
open; this is not production admission or a 700 tokens/s result.

Previously, [445 scoped compiler tests passed, including attention extraction](../qualification/guarded-mlp-core-kernel-error-identity-qualification-v1/README.md).
The exact core `KernelError` identity check and six new tests passed on MI350,
including eight identity/signature refusals and 38 MIR mutations. Every
earlier 438 named passing test remains green, and the unchanged attention
control now reaches gfx942 LLVM. All 39 phases returned zero naturally and
were reaped, with unchanged source/dependency maps and clean postchecks.
This completes the scoped control run, not the full runtime compiler/pliron
qualification. No production dependency, gfx950 HSACO, GPU, numerical or
performance gate has changed. Full compiler qualification and loader checks
are next; all issue #42 milestones remain open.

The [sixteen S/RPO harness helper tests also pass on MI350](../qualification/guarded-mlp-s-producer-helper-tests-v1/README.md).
They validate exact full-suite outcomes/ignored identities and final backend
rlib selection. One bounded child exited naturally and was reaped, with
unchanged inputs and clean postchecks. These synthetic harness tests are
separate from the 445 compiler tests and do not qualify the full S/RPO build.

Previously, [438 tests passed, including all checked-integer and Option wrappers](../qualification/guarded-mlp-core-checked-attention-qualification-v1/README.md).
Both builds pass on MI350. The fourth attempt corrects the observed FnOnce
kind and exact direct closure resolution. All six integer and ten Option
tests pass, including 458 and 198 MIR mutations respectively, plus two actual
closure resolutions and twelve new refusal assertions. All earlier 422
passing controls remain green, including eight atomic controls, both
unsafe-source checks and matrix extraction. Attention now reaches an
independent rejection of core's identity `From<KernelError>` conversion;
it still does not pass. All 38 phases exited naturally and were reaped, with
unchanged sources and clean postchecks. All four attempts are retained.
Full compiler qualification remains incomplete; no production dependency,
gfx950 GPU or performance gate has changed.

The [remaining `KernelError` conversion now has a complete diagnostic capture](../qualification/guarded-mlp-core-kernel-error-identity-diagnostic-v1/README.md).
An isolated compiler on MI350 passed both builds and six renderer tests,
then preserved the original attention rejection. The captured core body has
two normalized `KernelError` locals and one move followed by return. All 19
phases exited naturally and were reaped; source/dependency postchecks were
clean. This is evidence for a narrow follow-up check, not a new admission
rule, additional production qualification or GPU result.

Previously, [ten checked-arithmetic and Option helper bodies were captured from attention](../qualification/guarded-mlp-core-checked-attention-diagnostic-v1/README.md).
The second isolated diagnostic compiler built on MI350 and all six renderer
tests passed. It adds the standalone `u32::overflowing_mul` body to the nine
previously captured helpers. The unchanged attention control still rejects
`usize::checked_add`; the capture grants no admission. All ten selected bodies
were fully rendered within one 64 KiB limit, with no partial bodies or omissions.
All 19 phases exited naturally and were reaped, with unchanged sources and
clean integrity postchecks. Production recognizers and their qualification
remain pending. Both attempts and their unmodified raw records are retained.

Previously, [422 tests and matrix extraction passed; attention reached a checked-add refusal](../qualification/guarded-mlp-core-u32-widening-qualification-v1/README.md).
The exact widening recognizer and six new tests built and passed on MI350,
including 49 real-MIR mutations and eight identity/signature refusals. All
415 previously passing controls remained green. The unchanged matrix control
now reaches gfx942 LLVM and checks MFMA and workgroup storage; this does not
authorize an artifact or GPU launch. Attention still rejects the genuine core
`usize::checked_add` helper. All 36 phases exited naturally and were reaped,
with unchanged sources and clean integrity postchecks. The original run
completed through a transient SSH disconnect; it was not restarted.
Full qualification remains incomplete; Ferric's production dependency is unchanged.

Previously, [the rejected core u32-to-u64 conversion's complete MIR was captured](../qualification/guarded-mlp-core-u32-widening-diagnostic-v1/README.md).
A separate diagnostic compiler built on MI350, and all six bounded-renderer
tests passed. The unchanged matrix control retained its original rejection;
the observed helper contains one integer widening cast followed by return,
with no calls, cleanup blocks or inline origins. All 19 phases exited naturally
and were reaped, with unchanged sources and clean integrity postchecks.
The subsequent recognizer/test run is linked above. The capture itself does
not admit the conversion or qualify any provider, GPU, model or performance gate.

Previously, [415 compiler tests passed before the core conversion refusal](../qualification/guarded-mlp-core-result-qualification-v1/README.md).
Both compiler and test binaries built on MI350. V7 supplies genuine AMD-target
`core` and `compiler_builtins` metadata without changing the production matcher.
All 15 Result tests passed, including 172 MIR mutations, alongside the previous
390 tests, eight atomic controls and two unsafe/inlined-origin rejection tests.
The unchanged matrix control now gets past the Result wrappers and rejects
the concrete core `From<u32> for u64` conversion in `accessed_extent`.
That helper's body is now captured above; there is no general `From`
admission. All 34 phases exited naturally and were reaped, with unchanged
sources and clean integrity postchecks. Attention was not reached.
Ferric's dependency remains unchanged; no provider, GPU, model or performance
gate is claimed passed.

Previously, [the actual core FromResidual wrapper was captured alongside branch](../qualification/guarded-mlp-core-result-residual-diagnostic-v1/README.md).
The second diagnostic compiler built on MI350 and all ten rendering/census
tests passed. The complete observation includes the residual discriminant
assumption and its real error-conversion call; neither is implicitly trusted.
All 19 phases exited naturally and were reaped, with clean integrity postchecks.
The unchanged matrix test still returned 101 at its original rejection.
Exact body matchers and mutation tests are in progress; no provider, GPU,
model or performance gate is claimed passed.

Previously, [the rejected core Result helper's actual MIR was captured](../qualification/guarded-mlp-core-result-diagnostic-v1/README.md).
The diagnostic compiler built on MI350, six rendering tests passed, and the
unchanged matrix test retained its original rejection. The complete bounded
observation includes five blocks, six locals and three source scopes, with no
calls or inlined scopes. All 19 phases exited naturally and were reaped, with
clean integrity postchecks. This enables an exact helper-body check; it grants
no admission, provider qualification, GPU result or performance claim.

Previously, [the matched baseline confirms that the matrix refusal predates provider alignment](../qualification/guarded-mlp-provider-baseline-v1/README.md).
The published previous revision failed at the same core `Result::branch`
source-safety check, using matching build selections, tools and environments.
All 18 baseline phases exited naturally and were reaped; integrity postchecks
passed. This identifies a preexisting compiler gap, not a passing pipeline
control. The provider remains unqualified, its proposed revision unpublished,
and Ferric's dependency unchanged. No new GPU or performance result is claimed.

Previously, [the aligned provider generation passed 398 CPU tests but remains unqualified](../qualification/guarded-mlp-provider-generation-v1/README.md).
The full device library, both UI targets, trusted-provider cohort, scalar-pipeline
controls and eight selected gfx950 atomic extraction tests passed on MI350.
The existing matrix-pipeline test then failed while authenticating a core
`Result::branch` helper; the attention control was not reached. Integrity
postchecks passed. Thirteen harness fixtures passed separately, and all earlier
failed attempts are retained. The proposed dependency remains unpublished;
Ferric's kernel dependency is unchanged. No new HSACO, GPU or performance
result is claimed, and all model milestones remain open.

Previously, [the first guarded MLP lowering attempt reached device extraction but was refused](../qualification/guarded-mlp-lowering-attempt-v1/README.md).
The transferred extractor's reviewed device-source closure does not match the
candidate's pinned dependency generation. The compiler exited naturally after
116.347 seconds, with clean integrity postchecks, no timeout and no emitted
HSACO. Its trust check remains intact. A coherent published compiler/device
generation and fresh qualification are next; no new GPU or performance result
is claimed.

Previously, [locked offline dependencies are prepared for guarded MLP lowering](../qualification/guarded-mlp-dependency-preparation-v1/README.md).
Vendoring passed for 145 packages with unchanged kernel sources and lockfiles.
A separate fetch command downloaded missing crates but failed its preservation
check after older extracted cache packages disappeared. All 133 affected
packages were restored from unchanged archives with exact original content
hashes and no overwrites; that failed attempt remains retained as failed.
Four cache fixtures and eight restoration fixtures passed on MI350. This is
preparation only, not compiler emission, GPU execution or model acceptance.

Previously, [all seven compiler tools passed their MI350 loader audit](../qualification/guarded-mlp-compiler-tools-v1/README.md).
All fourteen inspection commands completed naturally with clean integrity
postchecks. The earlier loader-path failure is retained, and about 1.05 GB of
owned failed-build caches was reclaimed without deleting sources or evidence.
This establishes deployment and library resolution only. Locked dependency
preparation and actual checked gfx950 lowering remain next; no new HSACO or
GPU result is claimed.

Previously, [the full-state validator and guarded final residual passed CPU qualification on MI350](../qualification/guarded-mlp-segment-cpu-v1/README.md).
All 27 kernel tests and seven harness regression tests passed. Ten bounded
phases completed naturally, including the non-test typed Marker roster and
host library build, with clean integrity postchecks. Both earlier harness
failures are retained. The CPU crate binding is explicitly a host-only fixture,
not compiler authority. These new kernels are not yet connected to inference;
checked gfx950 emission, GPU guard controls, reusable arena validation and the
matched full-worker comparison remain next. All model and performance gates remain open.

Previously, [the finite two-rank peer-dependency graph passed native GPU qualification on MI350](../qualification/peer-dependency-signal-completion-gpu-v1/README.md).
The V3 runtime passed 1,064 Rust tests with three artifact-dependent ignores;
45 controller tests then passed before one native attempt on GPUs 1 and 2.
All sixteen signals completed, all ten guarded buffers matched, the delayed
peer-publication witness passed, and queue-first Close completed. Actual
completion-sample counters were (write, read) = (8, 3) on both queues: completed
work does not fabricate ring capacity. The 94.083 ms aggregate host interval is
not GPU time or model throughput. A previous busy-GPU preflight refusal is retained.
Reusable arena reset, full MLP-state validators, guarded final residuals and a
matched full-worker comparison are next. All milestones, numerical acceptance,
sustained 2,048/256 and 700 tokens/s remain open.

Previously, [ordered peer dependency packets passed CPU qualification on MI350](../qualification/peer-dependency-aql-cpu-v1/README.md).
All 43 Rust tests passed, including ten new dependency/publication tests. A C
oracle matched the 64-byte packet encoding and system-scoped `0x1503` header
against the installed ROCm header. All seven bounded phases exited naturally.
The exact tested Rust/C sources are pushed to both fe2o3 forks; the existing
publication gate remains unchanged. This is a packet-layer prerequisite, not
GPU peer synchronization or model qualification. Native signal ownership,
mixed-packet submission and a two-rank producer/consumer test are next. All
milestones, numerical acceptance, sustained 2,048/256 and 700 tokens/s remain open.

Previously, [the shared-full / ordered-segment GPU comparison completed on MI350](../qualification/projection-ordered-segment-pair-v1/README.md).
Both one-attempt four-forward runs passed structural and lifecycle checks;
all four payloads, covering 152 captured tensor slices per arm, are byte-identical.
The four-forward host-time sum was 21.908947 seconds shared versus 21.000850
seconds ordered, a ratio of 1.043 and 4.145% less observed wall time. Plots,
tables and all 144 combined-segment timing rows are published. This single
fixed-order pair is subject to cache warming and cold ordered arena costs;
it is not GPU timing, independent numerical acceptance or sustained 2,048/256
throughput. All milestones and the 700 tokens/s target remain open.

Previously, [both ordered-comparison parents and the common worker passed fresh MI350 runtime audits](../qualification/projection-ordered-segment-runtime-v1/README.md).
All six bounded readelf/ldd commands exited naturally, with complete library
closures and unchanged topology. Both matched input assemblies completed,
each checking 1,847 recorded identities. They retain the same model, images,
prompt, worker and lossless device IDs while selecting distinct shared-full
and ordered parents. This is preparation, not a completed native comparison,
independent numerical acceptance or sustained throughput result. All milestones
and the 700 tokens/s target remain open.

Previously, [the ordered comparison harness passed 174 policy tests on MI350](../qualification/projection-ordered-segment-gpu-preparation-v1/README.md).
Sixteen deployment-selector and thirteen input-assembler tests also passed,
with unchanged sources. The preceding V2 missing-artifact error and its fix
are retained explicitly. These are synthetic CPU tests, not a new native
GPU result. Fresh runtime audits, reviewed inputs and the matched shared-full /
ordered comparison remain separate gates. All milestones and the performance
target remain open.

Previously, [the projection-residual / MLP ordered segment passed CPU qualification on ASROCK](../qualification/projection-ordered-segment-cpu-v1/README.md).
All 75 phases passed, including the corrected default-feature check: 1,848
Rust test executions passed with seven historical ignores, five executables
were built, and all integrity postchecks passed. Seventeen controller policy
tests passed separately. The exact 36 Ferric and 24 fe2o3 source bodies are
integrated. The opt-in path combines two dispatch rounds and uses distinct
per-rank Down-output scratch to avoid a cross-rank alias race, without changing
kernel images or arithmetic. This is CPU qualification only; fresh MI350
runtime audits and matched GPU comparison remain separate execution gates.
All milestones, independent numerical acceptance, sustained 2,048/256 and
700 tokens/s remain open.

Previously, [the matched default/shared-full GPU pair completed on MI350](../qualification/projection-ar4-shared-host-pair-v1/README.md).
Both one-attempt AR4 runs passed structural and lifecycle checks. All four
606,976-byte payloads are identical across routes, covering 152 captured tensor
slices. Forward host wall time changed from 10.56-12.49 seconds to 5.25-5.77
seconds; the ratio of four-forward sums is 2.092. Plots and tables include
rank/group/publication counters and separate setup, configuration and Close.
This is one fixed-order diagnostic, subject to warmed-cache/order effects,
not GPU timing, independent numerical acceptance or sustained throughput.
All milestones and the 700 tokens/s target remain open.

Previously, [both observer parents and their shared worker passed fresh MI350 runtime audits](../qualification/projection-ar4-shared-host-runtime-v1/README.md).
All six readelf/ldd commands exited naturally, with complete library closures and
unchanged topology. Both input assemblies completed with exact same-model,
same-image requests and lossless device identities. Preparation corrections are
documented without weakening the checks. This checkpoint does not establish a
completed paired GPU run, numerical acceptance or a speedup.

Previously, [the shared-full comparison harness passed 122 policy tests on MI350](../qualification/projection-ar4-shared-host-gpu-preparation-v1/README.md).
Fourteen deployment-selector and eleven input-assembler tests also passed.
The paired supervisor checks same-build inputs, honest payload-byte comparison,
separate configuration timing and rank/group/publication currentness accounting.
This is CPU-only harness qualification, not a completed GPU comparison, numerical
acceptance or performance result. All milestones and the 700 tokens/s target remain open.

Previously, [the explicit shared-full projection AR4 route passed Rust qualification on ASROCK](../qualification/projection-ar4-shared-host-v1/README.md).
All 883 selected Rust tests passed, with four historical ignores; all 63 bounded
phases exited naturally, four executables were built and integrity postchecks
passed. Fifteen controller policy tests also passed. Fourteen exact tested source
bodies are integrated, preserving the default route and introducing an explicit
shared-full selector with separately measured configuration time. No kernel or
arithmetic changed. Fresh MI350 executable audits are linked above; the
same-generation default/shared GPU comparison is a separate execution gate.
All M0-M7, numerical acceptance, sustained 2,048/256 and 700 tokens/s remain open.

Previously, [the projection AR4 host observer completed on MI350](../qualification/projection-ar4-host-native-v1/README.md).
Four own-output forwards passed structural checks in one attempt without retry;
all 152 tensor slices, 576 terminal states, seven naturally exited/reaped leaves
and six surrounding audits passed. Forward host wall times were 10.593, 10.599,
12.531 and 12.582 seconds. Thousands of full-currentness checks per forward
dominate the nested host counters; the published table is not GPU timing or an
additive cost breakdown. The next optimization is a separately qualified
shared-full group-fence route. Numerical acceptance, sustained 2,048/256,
throughput and all milestones remain open.

Previously, [fresh observer executable audits and request assembly completed on MI350](../qualification/projection-ar4-host-runtime-v1/README.md).
Four bounded readelf/ldd commands exited naturally with complete library closures;
fourteen selector tests and eight assembler tests passed with unchanged sources.
The new request preserves the kernels, model, prompt, devices and deadlines and
changes only the worker, session and output path. This is validated preparation,
not a completed native observation or a numerical/performance result.

Previously, the [opt-in projection AR4 host-observation route passed its Rust qualification on ASROCK](../qualification/projection-ar4-host-observation-v1/README.md).
All 855 scoped Rust tests passed, with four historical ignores; thirteen controller
policy tests also passed. All 61 phases completed naturally, three executables
were built, and source/dependency/old-target postchecks passed. The seventeen
tested source bodies are integrated without changing the plain decode route or
runtime safety checks. The new counters separate inclusive host costs for diagnosis;
the subsequent GPU measurement is linked above. This is not numerical, throughput
or sustained 2,048/256 acceptance, and all milestones remain open.

Previously, the [projection AR4 host-observation supervisor passed 91 policy tests on MI350](../qualification/projection-ar4-host-supervisor-v1/README.md).
There were no failures, errors or skips, and the tested source snapshots are
unchanged. The new validator binds the stdout wrapper, native summary and
host-counter sidecar while retaining the existing image, lifecycle and audit
checks. This is synthetic CPU qualification of the Python supervisor only;
it is not a new Rust, GPU, numerical or performance result.

Previously, an [exact integer QKV audit completed on MI350](../qualification/layer0-exact-dot-v1/README.md).
All 6,144 retained layer-zero native QKV words match the once-rounded exact
BF16 dot products; the genuine framework matches 6,143. The previously
flagged Q row 168 is closer to the exact value in Ferric, so disagreement
with the framework alone is not evidence of a native arithmetic bug.
The original shard and six uploaded matrix slices were authenticated, and
all 24 arithmetic/mapping tests passed. This is a position-zero operator
diagnostic, not new-image internal capture, an FP32 reduction-order contract,
full-model numerical acceptance or a throughput result.

Previously, the [new linked RoPE AR4 numerical comparison completed on MI350](../qualification/rope-indexed-ar4-comparison-v1/README.md).
All 152 tensor slices share comparable input histories, but none matches the
independent framework reference bitwise. New logit relative-L2 errors are
0.0030448043, 0.0094134774, 0.0117436782 and 0.0050785906: unchanged at
position 0, improved at position 1, and worse at positions 2 and 3. Across
all slices, 90 improve, 24 regress and 38 are unchanged on that metric.
All eighteen comparator tests passed with unchanged source hashes. The
full before/after table is published, including the regressions. This is
not numerical acceptance; localizing the remaining differences is the next
gate before the sustained 2,048/256 workload or throughput claims.

Previously, the [new linked RoPE image completed native AR4 on MI350](../qualification/rope-indexed-ar4-native-v1/README.md).
The own-output chain was 9112 -> 67 -> 25 -> 576 -> 2701. All 152 tensor
slices, 576 terminal states, seven naturally exited/reaped leaves and six
surrounding audits passed structural checks in one attempt without retry.
Only the prefix image, session and output path changed. The 391.571-second
controller duration includes setup and audits and is not GPU throughput.
Independent tensor comparison subsequently completed as above; no numerical
or sustained 2,048/256 acceptance is claimed.

Previously, the [linked RoPE AR4 supervisor passed all 74 policy tests](../qualification/rope-indexed-ar4-supervisor-v1/README.md)
on MI350, with no failures, errors or skips and unchanged source snapshots.
The new admission path binds the actual emitted image to separate retained
producer and qualified consumer generations while preserving the runtime,
own-output recurrence and lifecycle checks. This is CPU-only synthetic
qualification, not GPU execution or numerical acceptance. The subsequent
GPU observation and independent tensor comparison are recorded above.

Previously, [linked indexed RoPE emission produced a new gfx950 HSACO](../qualification/rope-indexed-checked-emission-v1/README.md).
All eight staged phases and sixteen controller-policy tests passed. The
54,344-byte image has a 376-byte kernarg segment, Wave64, 512 bytes of fixed
LDS and zero private-segment bytes; ELF notes also report sixteen scalar
register spills. The continuation authenticates the retained successful
compiler leaves and uses the separately qualified indexed consumer, without
relabeling the original failed aggregate. All owned processes were reaped
and postchecks passed. This is checked emission, not GPU numerical acceptance
or a performance result. The subsequent GPU evaluation is recorded above.

Previously, the [indexed inert join V2 passed all thirteen staged CPU phases](../qualification/kir-indexed-formal-join-v2/README.md).
The full lower library passed 785 tests without ignores; its twenty indexed
tests also passed a separate repeat. The finalizer passed 190 default tests
with fifteen historical ignores, followed by an explicit passing actual
retained-handoff join. Twenty controller-policy tests passed separately.
The original work/storage limits remain unchanged, all owned processes were
reaped, and postchecks passed. This clears the measured inert-join refusal;
checked HSACO emission and GPU numerical evaluation subsequently completed
as above, without numerical acceptance.

Previously, an [unchanged-source control](../qualification/kir-indexed-baseline-control-v1/README.md)
reproduced the existing nested-enum location assertion in both a focused run
and the full original library (764 passed, 1 failed, 0 ignored). The 5,783-file
original RPO copy had no overlay or formatting changes. All six phases
completed naturally with clean postchecks. This establishes that the failure
predates the indexed join; it does not qualify the failing library. The next
candidate changed only that expectation in addition to the indexed-join source,
retained the alias-only rejection check, and passed the staged suite above.

Previously, the [indexed inert-join attempt](../qualification/kir-indexed-formal-join-attempt-v1/README.md)
compiled and passed all twenty new tests, but the full lower-library suite
stopped at 784 passed / 1 failed / 0 ignored. An existing nested-enum test
expected diagnostic location `(7, Some(4), 5)` and observed `(8, Some(7), 5)`.
The subsequent unchanged-RPO control above reproduced the same assertion;
the failure was not suppressed.
The subsequent finalizer and actual-handoff stages were not attempted.
All process groups exited naturally and postchecks passed; no new image,
GPU execution or numerical/performance qualification follows.

Previously, the [canonical KIR work diagnostic](../qualification/kir-join-work-diagnostic-v1/README.md)
localized the actual refusal to the inert formal layout join: 318 evidence
rows, 1,019 blocks and 6,096 nodes cause a 1,044,025,344-unit pending charge
after 40,799,816 units have already been accepted. The limits are unchanged.
All 190 default finalizer tests and 16 controller-policy tests passed; the
separate actual-capture test reproduced the expected exit-101 refusal.
All owned processes exited naturally and postchecks passed. An indexed join
was subsequently qualified for the staged CPU join as recorded above. No new
image or GPU result follows from this diagnostic.

Previously, the [RoPE/RPO checked-lowering attempt](../qualification/rope-materialized-rpo-lowering-v1/README.md)
cleared the previous semantic storage refusal and passed actual compiler
replay, then failed the finalizer's canonical-kernel work budget:
1,084,825,160 at refusal against the unchanged 1,073,741,824 limit. No HSACO
was emitted. All process groups exited naturally and postchecks passed.
The indexed join subsequently cleared this refusal without weakening its checks;
the later linked continuation emitted an image as recorded above.

Separately, the [actual four-step coefficient audit](../qualification/ar4-rope-input-audit-v1/README.md)
found all 512 BF16 coefficients identical to the retained framework tables.
Eleven synthetic tests passed. Raw FP32 differences remain at positions 1-3
but disappear at the BF16 boundary. This does not validate the new arithmetic
image or remove the position-zero residual differences.

The [RoPE/RPO four-step supervisor passed all 65 policy tests](../qualification/rope-materialized-rpo-ar4-supervisor-v1/README.md)
on MI350, with unchanged source snapshots and no errors or skips. These are
CPU-only synthetic admission and lifecycle tests, not a new GPU result. The
RoPE/RPO compiler result is recorded above; no new image is admitted.

Previously, the [independent genuine AR4 framework comparison completed](../qualification/projection-ar4-framework-v1/README.md)
on ASROCK. Two fresh-KV framework runs produce the same four-token sequence
as native: 67, 25, 576, 2701. All 152 tensor slices are comparable, but none
matches bitwise. Logit relative-L2 errors are 0.0030448043, 0.0140315337,
0.0043564111 and 0.0045131941; the table retains the larger position-1 error
and layer-level differences. All 25 child/utility leaves completed naturally
and all seven surrounding audits passed. This is a four-step diagnostic,
not numerical acceptance or the sustained 2,048/256 performance target.

Previously, the [RPO finalizer passed CPU qualification](../qualification/fe2o3-partial-move-rpo-finalizer-v1/README.md)
on ASROCK: 190 tests passed, with 15 historical actual-capture tests still
ignored. All six phases and postchecks passed. Three new finalizer products
join five preserved compiler products by their recorded identities. The
actual-capture tests still require explicit runs on a fresh checked handoff;
no new HSACO, GPU accuracy or performance result follows from this suite.

Previously, the [reverse-postorder partial-move compiler passed CPU qualification](../qualification/fe2o3-partial-move-rpo-v1/README.md)
on ASROCK: 2,700 Rust tests passed, including seventeen new scheduler and
differential tests, with 25 unchanged historical ignores. All twelve phases
and source/input postchecks passed. The four tested Rust overlays and raw
evidence are published without changing compiler limits or Ferric's production
route. Finalizer qualification subsequently completed as recorded above;
actual RoPE lowering and GPU numerical comparison remain separate gates.
No new HSACO or speedup is claimed here.

Previously, the [AR4 runtime completed four full-model forwards on MI350](../qualification/projection-ar4-native-v1/README.md).
The input chain was 9112, 67, 25, 576; outputs were 67, 25, 576, 2701.
Each next input equals the preceding checked argmax. All 152 tensor slices,
576 terminal state records, seven natural/reaped process leaves and six idle
audits passed structural checks in one attempt without retry. Fresh runtime
audits bind both CPU1037 executables. This is a native execution result, not
independent numerical acceptance. Genuine framework comparison subsequently
completed as recorded above; numerical acceptance, sustained 2,048/256
qualification and the 700-token/s target remain open.

Previously, the [AR4 supervisor and independent-reference policy suites passed](../qualification/projection-ar4-supervisor-v1/README.md):
52 CPU-only policy tests on MI350 and 38 on ASROCK, with unchanged source
snapshots. The framework result is explicitly retained as a primary-agent SSH
output observation, distinct from the bounded MI350 wrapper receipt. The tests
cover own-output recurrence, nonrecovering history comparability, separately
labeled conditional replay and the existing owned lifecycle. No model or GPU
kernel was executed by these suites. The separate native observation completed
as recorded above, followed by independent framework comparison. Numerical
acceptance, the long workload and 700 tokens/s remain open.

Previously, the [projection-residual autoregressive route passed fresh CPU qualification](../qualification/projection-ar4-cpu-v1/README.md)
on ASROCK through `mi350-2`: 1,037 Rust tests passed, with four unchanged worker
ignores, across all 87 build/test phases. Nine source files add explicit AR4
support while preserving the teacher-forced format and image bindings. Each
next input must equal the previous checked output; wrong trajectories, mode
mismatches and premature Close remain rejection cases. All seventeen selected
executables were rebuilt and all source/input postchecks passed. This is CPU
qualification, not a GPU observation. The matching GPU AR4 run completed as
recorded above, followed by independent history-aware framework comparison.
The 2,048/256 workload, numerical acceptance and 700 tokens/s target remain open.

The [branch-reduced RoPE candidate passed fresh CPU qualification](../qualification/rope-materialized-cpu-v2/README.md)
on ASROCK: all 33 Rust tests and eleven build/test phases passed with clean
postchecks. Only seventeen pure finite-check conjunctions changed; arithmetic,
all eighteen predicates and compiler limits are unchanged. Its subsequent
[checked gfx950 lowering attempt](../qualification/rope-materialized-lowering-attempt-v2/README.md)
hit the same semantic SSA partial-move storage limit. Both failed process trees
exited naturally and were reaped with clean postchecks. Neither attempt emitted
a candidate HSACO. Compiler state propagation and accounting are under review;
no compiler limit or proof check has been relaxed.

The earlier [RoPE checked-lowering attempt](../qualification/rope-materialized-lowering-attempt-v1/README.md)
stopped at the existing semantic SSA partial-move storage limit. No candidate
HSACO was emitted or launched. The failed process tree exited naturally and was
reaped; all input postchecks passed. The exact refusal and earlier manifest
syntax failure are retained. The subsequent branch-reduced validity expression
is the experiment recorded above; its fresh CPU qualification passed, but its
checked lowering also failed at the same limit.

The [BF16 RoPE candidate passed CPU qualification](../qualification/rope-materialized-cpu-v1/README.md)
on ASROCK: twenty new tests and thirteen reciprocal regression tests, including
the separately selected exhaustive case. All eleven build/test phases completed
with unchanged source and provider snapshots. The full tested fixture is
published; the default device crate and production route are unchanged. Checked
gfx950 lowering was subsequently attempted as above; GPU execution remains pending.

An [independent RoPE materialization diagnostic](../qualification/rope-framework-reference-v1/README.md)
completed on ASROCK. All 38,528 conditional BF16 words match the installed
framework when coefficients and products use its BF16 boundaries; fourteen
reference tests passed. Keeping products in FP32 produces differences at all
six nonzero captured-input probes. A separate FP64 table-construction model
still differs at position 2303. These are CPU operator diagnostics, not genuine
later-position model captures or validation of a new Rust GPU image.

Previously, the [SiLU image completed four full 36-layer forwards on MI350](../qualification/silu-materialized-decode-native-v1/README.md)
and its [independent framework comparison](../qualification/silu-materialized-decode-comparison-v1/README.md)
completed on ASROCK. All 152 tensor slices were compared; all four output tokens
match, but no complete tensor slice is bitwise identical. Logit relative-L2
errors are 0.0030448043, 0.0056276866, 0.0061773318 and 0.0079468052.
This improves three positions versus the corrected-residual baseline but worsens
position 2. The full tables retain that regression without fitting an acceptance
threshold. Seventeen comparator tests passed. Full-model acceptance, the long
workload and sustained performance remain open.

The [SiLU four-step supervisor](../qualification/silu-materialized-decode-supervisor-v1/README.md)
passed all 43 CPU policy tests on MI350, with unchanged source snapshots and no
skips. It selects the new MLP image using the existing CPU1022 executables and
preserves the original bootstrap images and lifecycle. These tests do not run
the full model; the separate native attempt and comparison completed as above.

The [BF16 SiLU image executed on MI350](../qualification/silu-materialized-native-capture-v1/README.md)
and its [independent layer-zero comparison](../qualification/silu-materialized-comparison-v1/README.md)
completed on ASROCK. All 28 arrays and 22 unchanged pre-SwiGLU arrays passed
structural checks. Final-hidden exact words improved from 2,728 to 3,807/4,096,
relative-L2 error fell from 0.0017142513 to 0.00059154807, and maximum absolute
error halved to 0.00390625. All 16,384 conditional residual words match; same-gate
materialized-product controls now match all 11,869 eligible words. Twelve
comparator tests passed. QKV and later framework differences remain; no numerical
acceptance threshold, full-model acceptance or throughput claim is introduced.

The [BF16 SiLU candidate completed checked gfx950 emission](../qualification/silu-materialized-lowering-v1/README.md)
on ASROCK, including all nine stages, actual replay and natural/reaped owner
completion. The 33,320-byte image retains the same ABI, 106 SGPRs, 106 VGPRs,
512 bytes LDS and zero reported spills/private scratch. Actual LLVM contains
the new BF16 narrow/widen before the up product. Separate policy suites passed
27 lowering and 36 capture tests. Layer-zero GPU execution and diagnostic
comparison completed as recorded above; numerical acceptance remains open.

The [explicit BF16 SiLU candidate](../qualification/silu-materialized-cpu-v1/README.md)
passed all 38 Rust tests and twelve controller-policy tests on ASROCK. The
candidate adds BF16 rounding between SiLU and its up product; existing
exponential arithmetic and Down2 scheduling are unchanged. The full tested
fixture is published separately because its dependencies differ from the live
default device crate. Checked lowering, layer-zero GPU execution and diagnostic
comparison completed as recorded above. Full-model validation remains a separate
gate. No production route or acceptance threshold changed.

The [independent four-step framework comparison](../qualification/projection-residual-decode-comparison-v1/README.md)
completed on ASROCK across all 152 tensor slices. All four output tokens match;
no complete tensor slice is bitwise identical. Logit relative-L2 error is
0.332344%, 0.757311%, 0.410781% and 0.859355% at positions 0-3.
The twelve comparator tests passed separately. Full tables and per-layer
trajectories retain every difference without introducing an acceptance
threshold. Numerical acceptance and sustained performance remain open.

The [projection-residual four-step GPU run](../qualification/projection-residual-decode-native-v1/README.md)
passed on `mi350`: four full 36-layer forwards, all 152 tensor captures,
576 terminal state records, six idle-device audits and seven natural/reaped
process leaves. One attempt completed without retry or forced cleanup.
Output tokens were 67, 198, 25 and 16. This establishes execution and structural
validity. Independent framework comparison completed as recorded above;
full-model acceptance and sustained performance remain open.

The [four-step candidate supervisor](../qualification/projection-residual-decode-supervisor-v1/README.md)
passed 35 synthetic policy tests on `mi350`; the separate executable-selector
suite passed all nine tests. Both retained unchanged sources with no skips.
These suites did not run a model or GPU kernel. The selected executables also
completed separate runtime dependency audits; the new GPU attempt completed
as recorded above.

The [projection-residual four-step decode route](../qualification/projection-residual-decode-cpu-v1/README.md)
passed joint CPU qualification on ASROCK through `mi350-2`: 1,022 passed,
four unchanged ignores, all 87 commands naturally completed and reaped,
and all 17 executables built. The 21 integrated source bodies match the
remotely tested files. The opt-in route selects the corrected residual image
across all 36 layers while preserving existing routes. Its GPU run completed
as recorded above; independent numerical acceptance remains pending.

The [captured SiLU diagnostic](../qualification/silu-materialization-diagnostic-v1/README.md)
passed all 18 synthetic tests on ASROCK. Its actual retained-data run reproduced
all 12,288 framework products from captured BF16 SiLU and up. With native gate
and up both identical to the framework, 1,542/5,702 rank-0 and 1,473/5,723 rank-1
products still differ. This localizes a remaining activation-path difference;
it does not establish missing materialization as the only cause. No new GPU
candidate, tolerance or full-model acceptance is claimed by this diagnostic.

The [projection-residual native capture and comparison](../qualification/projection-residual-native-capture-v1/README.md)
completed on `mi350`, with the independent comparison on `mi350-2`. All 28 arrays,
fourteen unchanged upstream arrays, full KV checks and six audits passed. Both
residual stages matched the independent conditional oracle on both ranks:
16,384/16,384 BF16 words. Against the genuine framework, final-hidden exact words
improved from 1,834 to 2,728/4,096 and maximum absolute error fell from 0.0625 to
0.0078125. Remaining stage differences are retained; full-model numerical
acceptance and performance remain open.

The [projection-residual capture supervisor](../qualification/projection-residual-capture-supervisor-v1/README.md)
passed all 34 synthetic policy tests on `mi350`, with unchanged sources and no
skips. No model binary or GPU kernel ran in that suite. Fresh runtime checks and
the genuine candidate capture/comparison subsequently completed as recorded above.

The [additive projection-residual parent/worker route](../qualification/projection-residual-runtime-v1/README.md)
passed joint CPU qualification on `mi350-2`: 988 passed, four unchanged worker
ignores, all 84 commands naturally completed and reaped. Both executables built;
the default-feature check and all postchecks passed. All 22 integrated source
files match the actual tested bodies. The separate route selects the new image
for both residual stages while preserving existing routes. Native candidate
execution completed as recorded above; independent model numerical acceptance
remains pending.

The [projection-residual comparison helper](../qualification/projection-residual-comparison-v1/README.md)
passed all twenty synthetic tests on `mi350-2`, including exact checks for both
residual stages, logical KV indexing, and retained framework differences. This
is comparator qualification, not a candidate GPU result. Its subsequent genuine
candidate comparison is recorded above, without full-model acceptance.

The [projection-residual candidate's checked gfx950 lowering](../qualification/projection-residual-lowering-v1/README.md)
passed on `mi350-2`, including exact-output replay and all postchecks. The
10,864-byte image also passed descriptor, ELF and ISA inspection: Wave64,
22 explicit arguments, six VGPRs, 36 SGPRs, and no reported spills. Manual
data-flow review finds the projection rounding before residual addition.
The candidate now has the separately qualified opt-in runtime route above.
GPU execution completed as recorded above; independent model numerical
acceptance remains open.

The separate [BF16 projection-residual candidate](../qualification/projection-residual-cpu-v1/README.md)
passed 17 new Rust tests and all 14 unchanged V18 regression tests on
`mi350-2`, with no ignores. All 18 bounded commands and source/tool/input
postchecks passed. The new kernel materializes the combined projection in
BF16 before residual addition; it does not alter the current runtime route.
Checked lowering and the subsequent layer-zero hardware result are recorded
above. Model numerical acceptance remains open.

The [projection-rounding replay](../qualification/output-residual-boundary-v1/README.md)
completed on `mi350-2`. The current formula reproduces all 4,096 captured native
residual values on both ranks. Materializing the projection in BF16 before
residual addition improves framework agreement from 2,886 to 4,094 values;
the projection sum itself still differs at three values. All twelve diagnostic
tests passed. This is conditional captured-data arithmetic, not a new GPU
kernel result or full-model numerical acceptance.

The [current layer-zero native capture](../qualification/layer0-native-capture-v1/README.md)
passed on `mi350`: 28 typed arrays were retained, both final hidden states
match the current native baseline byte for byte, and untouched KV regions
passed checks. One attempt, six selected-device audits and seven natural/reaped
process leaves completed without retries or forced cleanup. The controller's
40 tests also passed. The [independent 24-row stage comparison](../qualification/layer0-native-capture-v1/comparison/README.md)
also completed: both input norms and attention outputs match exactly. One
rank-0 QKV word differs, while the larger difference appears at output
projection/first residual. The comparison adapter and comparator separately
passed 15 and 18 tests. Numerical acceptance and performance remain open.

The [candidate-only native capture parent](../qualification/layer0-native-capture-parent-v1/README.md)
passed 289 Rust tests, including 14 new tests, with no ignores on `mi350-2`.
All fourteen executables, the default-feature check, 46 bounded commands and
source/input/artifact postchecks passed. Twenty separate controller tests and
format checks also passed. Its genuine current-image layer-zero intermediate
capture has now run as described above, without establishing numerical
acceptance or performance.

The [independent layer-zero capture](../qualification/layer0-framework-capture-v1/README.md)
passed on `mi350-2`: 33 genuine BF16 framework intermediates repeated exactly
across two fresh-KV passes. The new layer-zero output matches the original
framework reference byte for byte. Separate capture, launcher and comparison
suites passed 16, 18 and 14 tests. The actual CPU comparison still finds a
Ferric/reference difference: 1,834/4,096 equal words, maximum absolute error
0.0625 and relative L2 0.0035785690. Current native internal-stage capture is
the next numerical gate; no new tolerance or numerical acceptance is claimed.

The [paired-row MLP GPU comparison](../qualification/paired-row-mlp-native-v1/README.md)
passed on `mi350`: four complete output buffers and all 152 tensor comparisons
were byte-identical to the unchanged clock-enabled baseline. All 288 MLP
dispatches bind the new checked image. One attempt, six audits and seven
natural/reaped process leaves completed without retries or forced cleanup.
This follows fourteen CPU tests and nine checked lowering/replay/emission
stages on `mi350-2`. The checkpoint includes baseline/candidate raw-counter
tables and four plots; the report's twelve tests passed separately on `mi350`.
Independent numerical acceptance and calibrated/repeated timing remain open.

The [native clock V2 capture](../qualification/native-device-clock-observation-v1/README.md)
passed on `mi350`: sixteen clock samples, all 1,172 dispatch rows and exact
agreement across four complete output buffers and 152 tensor comparisons.
One attempt, six audits and seven natural/reaped process leaves completed
without forced cleanup. The report includes raw clock tables, per-device tick
distributions and layer/position plots. The controller passed 61 tests; separate
audit, input-preparation and report suites passed 7, 5 and 5 tests. Clock-domain
validation, calibration, aligned overlap and sustained throughput remain open.

The [matching clock parent](../qualification/gfx950-clock-parent-v1/README.md)
passed 275 Rust tests with no ignores, twenty separate controller tests, all
thirteen executable builds and the default-feature check on `mi350-2`.
All 44 bounded commands and source/input/artifact postchecks passed. The route
requires its own request, worker selector and sixteen-sample V2 sidecar, while
preserving the existing raw Control/capture joins and evidence limits. Its
locked parent dependencies remain distinct from the worker's newer runtime.
Both binaries subsequently passed runtime audits and the native capture above.

The [versioned clock recorder](../qualification/gfx950-clock-recorder-v1/README.md)
passed 669 selected Rust tests with four existing ignores on `mi350-2`.
All 21 new tests passed, the worker was rebuilt, and all 33 commands exited
naturally with unchanged input/source postchecks. Fifteen separate controller
tests passed. The new route retains the V1 dispatch report and samples both
ranks before and after each forward; errors poison the real owner even after
a committed forward. Native clock sampling passed in the capture above;
calibrated timings remain pending. No kernel image or arithmetic changed.

The [gfx950 raw clock-sampling API](../qualification/gfx950-clock-sampling-v1/README.md)
passed 648 selected Rust tests with four existing worker ignores on `mi350-2`.
This includes 14 new device/group clock tests, a fresh worker compatibility
build, 33 naturally completed commands and unchanged source/input postchecks.
A separate 14-test controller-policy run also passed. The API retains owned
descriptors, full currentness checks, rank identity and host sampling brackets.
The later worker checkpoint above wires it into Ferric's dispatch recorder;
native sampling is now observed, while calibration remains unqualified.

The [timestamp-enabled parent and worker run on MI350](../qualification/native-device-observation-v1/README.md).
The four-forward Qwen3-8B BF16 TP2 capture contains all 1,172 raw dispatch rows,
with 592/580 per rank. All four payloads, 152 tensors and output tokens are
byte-identical to the native baseline. All six audits and natural Close/reap
passed. The page includes actual per-device tick tables, ranges and layer/position
heatmaps. Raw ticks still provide no calibrated latency, cross-device alignment,
overlap, full-model numerical acceptance or sustained 2,048/256 result.

The first controller's real admission failed on a legacy-import dependency
before native launch. The successor binds all five authenticated dependencies
and restores imports on success/failure; all 47 tests passed on MI350 before the
successful GPU run. The original controller and failure account are retained. The native binaries
remain the separate [257-test parent](../qualification/native-device-parent-v1/README.md)
and [609-test worker](../qualification/native-device-routing-v1/README.md)
cohorts, with [actual runtime audits](../qualification/native-device-runtime-v1/README.md).
Those tests are distinct runs, not a combined suite. Existing plain/host-only
selectors and the V7 kernel image are unchanged.

The [resident-state GPU comparison](../qualification/resident-state-decode-observation-v1/tf4/README.md)
passes on MI350: all 152 tensors and four tokens are bitwise unchanged, with
576 fewer full group checks per forward and unchanged publication/rank operation
counts. Six audits and clean Close/reaping passed. The four host forward times
total 26.212 seconds versus 30.030 seconds in the retained control; this is one
diagnostic pair, not a qualified speedup or GPU/sustained-throughput measurement.
The page includes measured tables and a plot. Its comparison reader passed
21 tests; deployment/controller tests remain a separate 116-test checkpoint.

The [conditional final-norm/head replay](../qualification/tail-capture-diagnostic-v1/README.md)
completed eight diagnostics and 22 policy/layout tests on MI350. All 16,384 norm
words match; 40 of 607,744 logits differ, with all four argmax tokens matching.
Each stage uses its own captured immediate input and authentic original weights.
No head acceptance bound was invented; full-model numerical acceptance remains open.

The [paired resident-state fence candidate](../qualification/resident-state-fence-consolidation-v1/README.md)
passed 522 selected CPU tests with four ignored on `mi350-2`; a fresh worker
was built and all 17 bounded commands exited naturally. It removes redundant
private-observer fences while retaining the coordinator's outer fences and
public observers. The predicted 576 fewer group checks per forward have now
been measured on GPU with the new engineering worker. The production path is unchanged.

The [V7 all-layer autoregressive run](../qualification/independent-decode-observation-v1/ar4/README.md)
completed four own-token forwards on MI350 with six audits and clean Close/reap.
Outputs 67, 25, 576 and 2701 match the independent framework; all 152 complete
tensor rows still differ. Logit relative-L2 errors range from 0.00387545 to
0.00660156. This is not the sustained 2,048/256 target or numerical acceptance.

The [V7 all-layer teacher-forced run](../qualification/independent-decode-observation-v1/tf4/README.md)
completed four forwards through all 36 layers on MI350 with clean Close/reap
and all six audits. All four tokens match the independent framework reference,
but all 152 complete tensor rows differ; logit relative-L2 errors range from
0.00438509 to 0.01326323. Numerical acceptance remains open. These four payloads
are byte-identical to the prior native route, not a regression unique to V7.

The [historical two-residual replay](../qualification/historical-residual-capture-replay-v1/README.md)
matches all 32,768 captured BF16 words exactly across both residual stages,
both ranks and both profiles. This checks historical layer-0 residual boundaries,
not V7. The separate [historical MLP replay](../qualification/historical-mlp-capture-replay-v1/README.md)
now passes all 20 conditional stage checks and 41 CPU tests, with no bound
violations. It checks captured immediate inputs and authentic weights, not
all-layer or full-model acceptance. The all-layer observation controller passed
84 CPU policy tests and the separate framework diagnostic reader passed 12.

The [six-case new-image matrix](../qualification/independent-prefix-case-matrix-v1/README.md)
passes GPU execution and separate conditional numerical checks on MI350.
It covers genuine positions 0/4 and patterned positions 15/16/2,047/2,048,
not a full-model prefill or sustained decode. The observations below preserve
earlier checkpoints and their limitations at the time they were recorded.

## Observed Results

| Check | Observed result | Boundary |
| --- | --- | --- |
| Independent layer-zero framework capture on `mi350-2` | 33 BF16 stages x two passes repeated exactly; output matches original reference; separate 16, 18 and 14-test suites passed | Current Ferric layer-zero output still differs; first internal divergence and full-model acceptance remain open |
| Gfx950 clock-sampling API on `mi350-2` | 648 Rust tests passed, four existing ignores; fresh worker; separate 14 controller tests | CPU-only raw-sampler checks; no native ioctl qualification, calibration or recorder integration |
| Timestamp-enabled parent/worker on `mi350` | 1,172 raw rows; 152 tensors and four payloads/tokens unchanged; six audits and clean Close/reap; 47 controller tests | Per-device raw-tick plots, not calibrated GPU latency, overlap or sustained throughput |
| Device-tick parent/worker runtime audits on `mi350` | Both exact CPU-qualified ELFs inspected; four natural exits/reaps; all dependencies resolved | Seven auditor tests and 44 controller tests are separate; real admission failed before native launch |
| Corrected finite parent/worker CPU suite on `mi350-2` | 605 passed, 4 ignored; 34 owned commands | Includes 24 tests for the opt-in host-observation extension; no GPU execution |
| Historical KFD host-observation suite on `mi350-2` | 1,776 selected tests passed | Overlapping selections, including 15 new tests; separate source generation |
| Fresh Git-source worker build on `mi350-2` | 387 passed, 4 ignored; binary built from an empty target | Published Ferric/fe2o3 source pair; cached registry/toolchain, no parent or GPU run |
| Fresh-source V2 host-policy parent/worker cohort on `mi350-2` | 633 passed, 4 ignored; 12 binaries built and default-library check passed | Exact 13-file overlay; CPU checks alone do not qualify GPU execution |
| V2 host-policy baseline on `mi350` | 152 retained native tensor rows bitwise equal; six device audits and clean Close/reap | Newly built CPU633 binaries; no V2 autoregressive or sustained benchmark |
| V2 admission-cache arm on `mi350` | 152 native rows bitwise equal; repeated admissions fall to zero; six audits and clean Close/reap | No reliable overall latency improvement from the A/B/A diagnostic |
| V2 baseline repeat on `mi350` | 152 native rows bitwise equal; six audits and clean Close/reap; baseline operation counts restored | Baseline drift exceeds the initial aggregate cache delta; no confidence interval |
| V2 shared-currentness arm on `mi350` | 152 native rows bitwise equal; six audits and clean Close/reap; forward host total 61.458 seconds | Shorter than both baselines in this diagnostic, not a qualified speedup or isolated benchmark |
| Consolidated group-fence candidate on `mi350-2` | 475 selected CPU tests passed, 4 ignored; new worker built | 77 runtime plus 398 worker tests; parent remains separately qualified CPU633 |
| Consolidated group-fence worker on `mi350` | 152 native rows bitwise equal; six audits and clean Close/reap; forward host total 30.394 seconds | 18,720 duplicate full checks removed versus old shared worker; unisolated diagnostic, not sustained decode |
| Four teacher-forced forwards on `mi350` | 152 retained native tensor rows bitwise equal to the prior native route | All 36 layers, TP2, finite engineering images; not an independent full-model numerical bound |
| Four autoregressive forwards on `mi350` | 152 retained native tensor rows bitwise equal to the prior native route | Own-token history; no 2,048/256 workload or sustained throughput measurement |
| Six prefix-stage numerical cases | All 24 rank/profile rows satisfy the declared conditional norm/QKV bounds | Independent conditional arithmetic check of retained captures, not a new GPU run |
| Idempotent partial-move compiler candidate on `mi350-2` | 2,675 CPU tests passed, 25 ignored; fresh compiler built | Six new regressions executed; actual prefix-tile replay remains ignored |
| Matching finalizer tools on `mi350-2` | 190 default example tests passed, 15 ignored; three tools rebuilt | Same compiler source generation; actual-capture inert join remains ignored, no new HSACO |
| Checked reciprocal probe with new compiler on `mi350-2` | Previous storage gate cleared; canonical semantic capture emitted | Ranked projection rejects 1,027 blocks against the unchanged 1,024 limit; no HSACO or GPU run |
| Reduced-CFG reciprocal V3 on `mi350-2` | Exact census measures 1,013 blocks, 14 fewer; CFG-size gate cleared | Checked lowering now rejects an unsupported induction-latch form; no HSACO or GPU run |
| Canonical-counter reciprocal V4 on `mi350-2` | CPU arithmetic passes; fresh checked probe fails cumulative partial-move storage limit | No semantic capture or HSACO; prior V3 compiler successes do not transfer |
| Independent per-profile comparator on `mi350-2` | 20 CPU tests and eight historical rank rows passed | No paired bitwise prerequisite; unchanged bounds; not a new GPU run or new-image acceptance |
| Ordinary induction temporary compiler candidate on `mi350-2` | 2,683 CPU tests passed, 25 ignored; fresh backend and extractor built | Eight new regressions executed; actual prefix replay remains pending |
| Ordinary induction matching finalizer tools on `mi350-2` | 190 default tests passed, 15 ignored; three tools rebuilt | Exact new compiler generation; actual-capture inert join remains a separate gate |
| V3 checked probe with ordinary-induction compiler on `mi350-2` | All nine phases passed; actual replay and inert join passed; fresh 53,560-byte gfx950 HSACO emitted | Eight runtime obligations remain; no fresh GPU execution, numerical acceptance or throughput result |
| Independent-profile observation adapter on `mi350-2` | 23 synthetic policy tests passed, no skips | No launcher; mathematical return values are mocked; real-capture integration pending |
| Independent native-profile adapter on `mi350-2` | 98 tests passed, one ignored; fresh test and native executables built | All 14 new tests ran; no deployment or new GPU execution yet |
| Independent runtime-audit collector on `mi350-2` | 18 synthetic policy tests passed, no skips | New deployment namespace; actual MI350 ELF/library audit still pending |
| First new independent prefix case on `mi350` | Both profiles and both ranks pass GPU execution and separate conditional numerical checks at genuine position 0 | 8,192 attention BF16 values exact; maximum output error/bound ratio 0.015053; not full-model or throughput acceptance |
| Complete new-image prefix matrix on `mi350` | Six cases and 24 profile/rank rows pass; 49,144 attention values exact and eight within one BF16 step | No norm/QKV bound violations; maximum output error/bound ratio 0.0229955; patterned long KV is not authentic model prefill |
| Historical two-residual capture replay on `mi350` | 32,768 BF16 words exact; 14 policy/layout tests passed | Original layer-0 captures and authenticated embedding row; no new GPU run, V7 or MLP acceptance |
| New V7 image through 36-layer TF4 on `mi350` | 152 captures, four matching framework argmax tokens, six audits and clean Close/reap | All 152 complete tensor rows differ from framework; no numerical or performance acceptance |
| New V7 image through 36-layer AR4 on `mi350` | Four own-token forwards, matching framework histories and outputs, 152 captures, six audits and clean Close/reap | All 152 complete tensor rows differ from framework; not the 2,048/256 workload or numerical acceptance |
| Historical MLP capture replay on `mi350` | All 20 conditional stage checks and 41 CPU tests pass; maximum down error/bound ratio 0.0148193 | Original layer-0 captures; no new GPU run, V7 or all-layer acceptance |
| Paired resident-state fence candidate on `mi350-2` | 522 CPU tests passed, four ignored; fresh worker built; 17 natural command exits | Eight exact source files and six new regressions; predicted counter reduction is not a GPU or performance result |
| Resident-state deployment/controller on `mi350` and `mi350-2` | 116 CPU policy tests pass; actual worker export verifies source/build/test evidence | No GPU execution of the new worker yet; parent, prior worker and V7 provenance remain distinct |
| Resident-state worker on `mi350` | 152 tensor rows bitwise equal; 2,304 fewer full group checks; six audits and clean Close/reap; 21 comparison tests pass | One unchanged-V7 TF4 pair; 26.212 vs 30.030 seconds host forward total, not a qualified speedup or sustained benchmark |
| Conditional final norm/head replay on `mi350` | 16,384 exact norm words; 40 differing logits of 607,744; four matching argmax tokens; 22 tests pass | Eight immediate-input diagnostics, not a chained reference, justified MFMA error bound or full-model acceptance |

Both four-forward runs completed their Close protocol, reaped their owned
processes, and passed their six surrounding device-state audits. The CPU suite
also completed with no forced cleanup. The V1 host-instrumented (CPU605)
generation has independently completed its teacher-forced run, described below. Its
autoregressive run has not yet been repeated with instrumentation.

The six numerical cases cover genuine positions 0 and 4, plus patterned
positions 15, 16, 2,047 and 2,048. They check first normalization, QKV projection,
head normalization, split-half RoPE and exact current-value append. The checks
are conditional on captured preceding-stage values and the declared floating
point premises: at most one FP32 ULP for the square-root sequence and correctly
rounded FP32 division. A universal proof of these instruction sequences is
still open. The candidate cap and numerical policy were not loosened to obtain
these results. The older attention/output-projection check remains separate.

A subsequent exact binary32 CPU diagnostic found six standalone reciprocal
counterexamples and 21 chained counterexamples over permitted synthetic raw
seeds. For example, with denominator `1 - 2^-24` and reciprocal seed `1`, the
correction can round a midpoint back to `1`, although the correctly rounded
reciprocal is the next FP32 value. These are not observations of the GPU's
actual seed selection or model failures. They show that the assumed division
rounding does not follow from the tested instruction model and seed envelope;
the prerequisite remains unresolved. No threshold was widened. The diagnostic
receipt is `9af99ee3b0b4247a0a7b504f8364fc6ad1dd6f8c825b37f05aedc330140722d8`.

The first fresh checked compiler probe for a separate exact-reciprocal candidate
passed metadata but failed semantic-SSA partial-move validation before producing
an HSACO. Its cumulative storage budget first rejected charge 2,097,153 against
the existing 2,097,152-word limit. This does not mean that one additional word
would suffice for the whole function. The limit was not raised. Source and
old-target postchecks passed; the failed owned process tree exited without
forced cleanup and was reaped. The [failure record](assets/finite-prefix-v228/reciprocal-probe-failure.json)
keeps this distinct from successful CPU arithmetic checks and from the existing
GPU images. A smaller candidate control-flow graph needs its own arithmetic and
checked compiler validation before any GPU claim.

The revised candidate now uses masked subtraction and boolean nearest-even
rounding within the same 24-step restoring algorithm. Bounded integer
operations use wrapping methods to avoid unnecessary checked-MIR branches;
only creation of the all-ones subtraction mask intentionally wraps. The
positive-normal domain, power-of-two path, two prefix wrappers, shared V3
arithmetic, kernel body and independent numerical references remain unchanged
relative to the first candidate.
No compiler storage cap or numerical tolerance was increased.

Its fresh [CPU validation](assets/finite-prefix-v228/reciprocal-cpu-branchless.json)
passed 11 ordinary arithmetic tests, six source contracts, the explicitly
selected exhaustive test over 8,388,608 significands in one binade, and all
1,007 independent Fraction nearest-neighbor vectors. The exhaustive test is
ignored by the ordinary invocation but was separately executed successfully.
All nine owned phases exited naturally, source/dependency postchecks passed,
and all 50 raw records plus both test binaries were rehashed locally. The
additional source contract pins macro-rule structure; it is not an independent
numerical reference.

The revised candidate has now undergone a fresh checked compiler probe on
`mi350-2`, but [lowering still fails](assets/finite-prefix-v228/reciprocal-probe-branchless-failure.json)
at the same first rejected cumulative partial-move storage charge:
2,097,153 against 2,097,152. The branchless rewrite did **not** unblock the
retained compiler. No HSACO was emitted and no GPU execution was attempted.
The probe driver passed 23 pure tests; its owned outer supervisor passed 14.
Before compilation, both joined the exact passing candidate CPU receipt,
seven Rust source bodies and 53 device-provider sources. Metadata passed,
Cargo then exited 101, and all source/tool/configuration/dependency/old-target
postchecks passed. The owned process tree exited naturally and was reaped.

The [next compiler candidate](../qualification/fe2o3-partial-move-idempotent-v1/README.md)
removes a redundant clear/reinsert when a local is already marked wholly moved.
Its [fresh CPU validation](../qualification/fe2o3-partial-move-idempotent-v1/cpu-result.json)
passed 1,487 Pliron tests and 1,188 compiler tests, with 25 ignored. All six new
exact-limit, cumulative-charge, moved-read and unchanged-join regressions ran;
the full default suites also exercised existing CFG, loop and replay coverage.
Actual prefix-tile replay is among the ignored tests and remains unqualified.
The fresh backend and extractor built, all ten commands exited naturally, and
source/dependency/tool/old-target checks passed. The compiler patch, regression
tests and precise source boundary are published separately from runtime code.

The first CPU controller attempt rejected libtest's passing `should panic`
annotation. Its failure was retained; the parser fix passed nine policy tests,
then both suites and the compiler build were rerun under fresh paths. The
completed run's 59 raw records, full copied compiler source and five selected
artifacts were retained and rehashed locally. This is not evidence that the
complete reciprocal function fits. The [matching finalizer build](../qualification/fe2o3-partial-move-idempotent-v1/finalizer-result.json)
subsequently passed 190 default tests with 15 ignored, rebuilt three tools,
and preserved all five qualified compiler products. Its six commands exited
naturally; source, dependency and prior-target checks passed. The 36 raw
records and three new tools were retained and rehashed locally. The actual
V6 capture join remains ignored.
Compiler limits, numerical tolerances and production admission remain unchanged.

The [fresh checked probe](../qualification/fe2o3-partial-move-idempotent-v1/checked-probe-result.json)
with those exact compiler/finalizer products cleared the partial-move storage
gate. It emitted a canonical V41 semantic capture, then rejected the unchanged
ranked CFG block limit. A matching-decoder [read-only census](../qualification/fe2o3-partial-move-idempotent-v1/semantic-census.json)
measured one kernel-root function containing 1,027 stored blocks, three above
the per-function limit of 1,024. All source/tool/dependency/prior-target
postchecks passed and the owned processes exited naturally and were reaped.
This is not ranked or target KIR acceptance, replay, HSACO emission or GPU
validation. The next source change targets avoidable reciprocal branches;
the numerical policy and compiler caps remain unchanged.

The [reduced-CFG V3 candidate](../qualification/exact-prefix-reciprocal-v3/README.md)
now removes the reciprocal domain and power-of-two branches while preserving
the 24-step recurrence and rejection sentinel. Its actual `mi350-2` CPU run
passed 12 ordinary tests, six source contracts, the explicit exhaustive
8,388,608-significand test and all 1,007 Fraction vectors. The unapplied source
patch and exact source pins are published with the result. All nine commands
exited naturally and source/dependency checks passed.

Its [fresh checked probe](../qualification/exact-prefix-reciprocal-v3/checked-probe-result.json)
has now cleared the CFG-size gate. The new exact-decoder census measures
1,013 stored blocks, 14 fewer than V2 and 11 below the unchanged cap. Lowering
then rejects an induction latch that does not copy field zero of a checked
result. The owned tree exits naturally and is reaped; all source/tool/dependency
and prior-target checks pass. There is still no new ranked/target KIR, handoff,
HSACO or GPU result. This block-count reduction is not a GPU speedup.

The [V4 source candidate](../qualification/exact-prefix-reciprocal-v4/README.md)
now changes only the bounded reciprocal counter to `step += 1_u32`, with its
matching macro contract. The actual V3 capture identifies both rejected
counter latches as plain temporary copies. V4 passed the same 12 ordinary
tests, six contracts, explicit exhaustive test and 1,007 Fraction vectors on
`mi350-2`. The source patch and exact CPU result are published separately from
runtime adoption. Its [fresh checked probe](../qualification/exact-prefix-reciprocal-v4/checked-probe-result.json)
has now failed semantic-SSA partial-move validation before emitting a capture:
the first rejected cumulative charge is 2,097,153 against the unchanged
2,097,152-word budget. The new checked counter changes the MIR; V3's successful
storage and CFG checks cannot be carried forward. All postchecks passed and
the owned tree exited naturally and was reaped. The latch fix remains
unqualified, with no new HSACO or GPU result.

The new [per-profile comparator](../qualification/prefix-profile-numerical-v1/README.md)
checks each implementation against the independent norm/QKV/head/RoPE,
attention and output references without first requiring V5/V6 bitwise parity.
All 20 CPU tests passed on `mi350-2`, including nonzero historical KV across a
page boundary and rejection of a finite historical-value corruption. Four
independent replays of retained position-15/16 profiles passed, covering eight
rank rows. All 16,384 attention BF16 words match the rounded reference; the
largest O error/bound ratio is below 0.011039. These are conditional checks of
older captures, not new GPU execution or validation of the reciprocal candidate.
The future native-child adapter still must authenticate ownership, captures,
untouched KV and actual-image arithmetic/ISA prerequisites.

The [next compiler candidate](../qualification/fe2o3-ordinary-induction-alias-v1/README.md)
recognizes only the adjacent ordinary-Add temporary seen in the V3 capture.
It retains exact type/definition custody, no-address-escape, positive-step,
unsigned no-overflow and replay checks, without granting assertion-elision
authority or changing caps. A fresh `mi350-2` run passed 1,487 Pliron and 1,196
compiler tests, with 25 unchanged ignored selections. All eight new regressions
ran; the extractor/backend built and all postchecks passed. The complete
5,780-file prior source generation was joined before applying the two-file
change. The patch, source pins and actual result are published; this CPU result
does not yet establish full checked lowering or a new GPU image.

The [matching finalizer tools](../qualification/fe2o3-ordinary-induction-alias-v1/finalizer-result.json)
have now built against that same generation. Their 190 default tests and 14
controller policy tests passed; 15 finalizer tests remain ignored, including
the actual-capture inert join. All six commands exited naturally, all five
compiler products stayed unchanged, and source/dependency/tool/configuration
and four old-target postchecks passed. The complete archive and selected
products were retained and rehashed locally.

Fresh V3 checked lowering has now [passed as a separate leaf](../qualification/fe2o3-ordinary-induction-alias-v1/checked-lowering-checkpoint.json)
in 1,771.339 seconds, naturally exiting zero before the unchanged 1,800-second
deadline. The actual outputs include semantic MIR, neutral/target KIR V11,
gfx950 LLVM and a 4,022,416-byte inert handoff. This clears the previous latch
refusal. That record remains an interim checkpoint; the subsequent
[terminal nine-phase probe](../qualification/fe2o3-ordinary-induction-alias-v1/checked-probe-result.json)
passed actual-capture replay in 1,401.55 seconds and the separately selected
inert-join test. All nine phases exited naturally; source/dependency/tool and
five prior-target postchecks passed, and the owned tree was reaped. All 92
archive members were rehashed locally. A fresh 53,560-byte gfx950 HSACO was
emitted, with SHA-256
`4885204c8d510122588549107f42d2bc6f180f48fbc4eddd3bb1260e8d6629c5`.
This is an engineering image: eight runtime requirements remain undischarged,
generic proofs remain unsupported and production authority is absent. New
actual-image reviews, deployment and MI350 numerical checks are still required;
there is no new GPU or performance result.

A separate [observation adapter](../qualification/independent-profile-observation-v1/README.md)
now validates the new independent-profile reports while preserving the existing
child-custody validator and numerical references. All 23 synthetic policy tests
passed on `mi350-2`, including first-read authentication failures that occur
before the original Reader registers a pin. Those failures abort, whereas
ordinary numerical rejections remain specific to each profile. Its tested
source is published, but it has no launcher and has not yet replayed real new
captures through the full adapter. Mock reference returns in these tests are
not numerical evidence or a new GPU result.

The matching [native adapter](../qualification/independent-native-profiles-v1/README.md)
has now passed a fresh 98-test CPU suite, with one existing test ignored. All 14
new tests ran alongside the preserved historical inventory. Its new explicit
modes retain the existing owned child, request, review, finite-output, untouched
KV and Close checks, while capturing each profile without requiring paired
bitwise equality. The old paired mode remains unchanged. Both executables built;
all six phases exited naturally and source/dependency/fixture/tool and six
prior-target postchecks passed. All 5,856 archive members were rehashed locally.
This is a tested host adapter, not deployment or GPU numerical acceptance.

The [runtime-audit successor](../qualification/independent-runtime-audit-v1/README.md)
also passed all 18 synthetic policy tests. It changes only deployment/output
namespace handling and preserves the existing ELF, library identity, process
ownership and resource checks. It does not mint reviews or launch authority;
an actual audit of the new deployed executable on MI350 remains required.

The [new deployment](../qualification/independent-deployment-v2/README.md)
has now been exported and verified on MI350. Its receiver checks both complete
evidence archives, all 5,783 native source files and the exact emitted image and
native executable. All 30 policy tests passed, including actual-command
regressions for the string-valued byte-count bug found during the first export.
The unchanged numerical reference suite also passed all 20 tests on MI350.
These are deployment and CPU-reference checks, not new GPU captures or an
end-to-end model throughput result.

The [first new GPU case](../qualification/independent-prefix-first-case-v1/README.md)
has now completed on MI350 after the actual executable/library audit. Both
profiles closed naturally, all eight owned leaves completed, and six device
audits passed. Separate CPU reference checks accepted all four profile/rank
rows: no normalization or QKV bound violations, exact current KV append,
8,192 exact attention BF16 values, and output partials within the unchanged
bound. The maximum output error uses about 1.51% of that bound. All 64 candidate
workgroups on each rank performed useful work in this observation; that is
not a scheduling guarantee or a performance measurement. This publication
covers only genuine position 0 and preserves the conditional arithmetic and
runtime limitations. It does not establish complete model decoding or the
700 tokens/s target.

The subsequent [complete matrix](../qualification/independent-prefix-case-matrix-v1/README.md)
now covers all six selected positions with the same image, executable and
fixed numerical policies. All 48 owned leaves completed naturally and all 36
surrounding device/process audits passed. The local audit rehashed all 366
case files, including 24 full rank captures. Eight of the 49,152 attention
values differ by one BF16 step; all others match exactly. The largest output
error/bound ratio is 0.0229954713, about 2.30% of the allowed bound. Every case
observed useful work from all 64 candidate workgroups on each rank. No bound
was widened, and no full-model or performance acceptance follows from this
prefix-only result. The matrix page reports each case separately.

The next [residual-capture comparator](../qualification/independent-residual-reference-v1/README.md)
has passed 18 focused CPU tests on MI350. It reuses the unchanged integer
FP32/BF16 rounding oracle and checks both residual boundaries, explicitly
feeding the post-attention residual into the post-MLP residual check. The
tests cover exact output words, cancellation, rounding, overflow, corrupt
captures and incorrect stage chaining. These are synthetic component tests,
not new full-layer GPU evidence or validation of the intervening MLP.
The subsequent [historical capture replay](../qualification/historical-residual-capture-replay-v1/README.md)
now checks the actual retained residual boundaries with all 32,768 BF16 words
exact. That result still does not validate upstream MLP partial arithmetic.

The V7 image has also completed a new finite all-layer teacher-forced run.
Its four host-inclusive forward durations were 7.2200, 7.2450, 7.8164 and
7.7490 seconds. These are engineering diagnostics, not GPU latency or sustained
throughput, and do not establish a speedup. The separate independent framework
comparison reports all 152 tensor differences without inventing an acceptance
threshold. Four matching tokens do not qualify full-model correctness.

## Source Publication

The [source index](assets/finite-prefix-v227/source-index.json) binds the 289
imported files to the build-host source snapshot. All 355 Ferric paths in the
CPU cohort's source map were checked against the published tree. Cargo path
dependencies and literal source/fixture includes were audited separately;
the 167-file finite test census alone was not a complete source closure.
That index describes the original CPU605 generation. The separately tested
[V2 overlay](assets/finite-prefix-v228/host-policy-source.json) records later
changes without rewriting the original source evidence.

This includes the finite parent/worker, shared wire imports, consumed tokenizer
fixtures, and required device source/test dependencies. Only the four shared
wire files were added under the legacy v4 worker. Its Cargo manifest, lockfile,
main program and unrelated experiment additions were left unchanged.

The matching sibling runtime is now published at
[fe2o3 `6964f6129`](https://github.com/harsh-nod/fe2o3/commit/6964f6129c4c42d343117f61cdbcfe6166392535)
in both fe2o3 repositories. The bounded runtime export retained 765 files,
checked all 479 mapped runtime inputs, and imported exactly 84 changed paths
against its pinned base. The parent uses its own locked fe2o3 Git dependency;
the two dependency generations are not interchangeable.

A fresh Git-archive build paired Ferric `9eca2576` with that fe2o3 commit on
`mi350-2`. With an empty target directory, all 387 selected worker tests passed
and four were ignored; the worker binary also built. Cargo metadata verified
the exact ten local packages and 29 registry packages, and all 6,921 extracted
source files remained unchanged. The registry cache and toolchain were reused.
The [fresh-build record](assets/finite-prefix-v228/clean-worker-build.json)
and [worker instructions](../adapters/tp-peer-finite-engineering-worker-v1/README.md)
record the exact pair. This does not reproduce the parent, compiler/HSACO
pipeline, or GPU run from clean source, and is not a workspace-wide test pass
or a newly qualified legacy-worker build. Full workspace formatting, Clippy
and regression gates remain required before merging to production.

## Measured Host Overhead

The instrumented teacher-forced run completed on `mi350`: all 152 native
tensor rows matched the prior native baseline bit-for-bit, all three pre-run
and three post-run device audits passed, and Close/EOF/owned process reap
completed without forced cleanup. Its receipt is
`5825e7859db0066b13f3f844d6a103dec5d0d6ec428973426a2d6d4529bc6304`.
The selected parent and worker are the corrected CPU605 binaries, not the
earlier uninstrumented binaries. All 57 pinned case outputs were independently
rehashed after retention on the local machine.

The [machine-readable host summary](assets/finite-prefix-v227/host-observation.json)
retains nanosecond values and counter names. These are **inclusive, nested host
scopes**, not calibrated GPU durations or additive contributions. Currentness
checks revalidate device, topology, allocation and queue state. Do not add
rank times, subtract them from wall time, infer overlap, or turn four
teacher-forced forwards into a target-workload tokens/s result.

| Position | Forward Wall (ms) | Full Currentness R0 (ms) | Full Currentness R1 (ms) | Admission R0 (ms) | Admission R1 (ms) | Full Checks R0 / R1 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 0 | 18,240.289 | 8,512.988 | 8,477.279 | 14.444 | 10.846 | 5,068 / 5,048 |
| 1 | 18,252.250 | 8,523.919 | 8,486.701 | 14.496 | 10.812 | 5,068 / 5,048 |
| 2 | 20,186.874 | 9,484.764 | 9,451.487 | 14.461 | 10.819 | 5,644 / 5,624 |
| 3 | 20,203.428 | 9,499.867 | 9,463.653 | 14.412 | 10.813 | 5,644 / 5,624 |

The setup snapshot interval was 167.644 seconds and Close took 26.703 seconds.
The parent diagnostic took 413.571 seconds including its setup, forwards,
readbacks and teardown; the surrounding controller took 430.597 seconds.
These boundaries differ and must not be mixed into a performance comparison.
This is one diagnostic run with all performance opt-ins off, not an ablation
or a statistically qualified latency measurement.

The observations make repeated currentness checks the first optimization
candidate to investigate. The controlled comparisons separately
enable immutable kernel-admission caching and sharing a fresh full-currentness
observation within a group fence. Mutable allocation, pointer, ABI, geometry
and queue checks must remain. Round publication already shares a fresh
observation in the baseline, so that existing behavior cannot be claimed as a
new optimization. No speedup is claimed until the separate variants pass their
own numerical, ownership and measurement checks.

The explicit V2 policy implementation has now passed a fresh-source CPU
cohort: 398 worker/shared-wire tests, 224 disjoint parent-library tests and
11 parent CLI tests, with four ignored. All 12 binaries built, the default
parent library check passed, and all 6,928 post-overlay source files stayed unchanged.
All 213 retained raw records and 12 binary bodies were rehashed after transfer.
The [policy guide](GFX950_HOST_POLICY_V2.md) documents the checks each arm
retains and the [CPU record](assets/finite-prefix-v228/host-policy-cpu.json)
identifies this new generation. Its separate V2 baseline has now completed on
`mi350`, with all 152 native tensor rows bitwise equal, six passing device audits
and clean Close/reap. The [GPU record](assets/finite-prefix-v228/host-policy-baseline.json)
retains the new identities and host counters. All 57 final output files were
independently rehashed locally. Forward host durations were 18.266, 18.304,
20.174 and 20.171 seconds. These are not GPU durations or qualified throughput.
The separate admission-cache arm also passed native parity and lifecycle checks.
Per-forward repeated admissions fell from 148 / 145 to zero, while initial
admission, dispatch, full-currentness and I/O counts remained unchanged.
Its four forward host durations sum to 76.933 seconds versus baseline's
76.916 seconds: no overall improvement is established. The
[cache record](assets/finite-prefix-v228/host-policy-cache.json) and
[comparison table](GFX950_HOST_POLICY_V2.md#admission-cache-observation) retain
this observation without a speedup claim. The
[repeated baseline](assets/finite-prefix-v228/host-policy-baseline-repeat.json)
also passed parity, six audits and clean Close/reap; all 57 final outputs were
rehashed locally. Its forward host durations sum to 77.471 seconds, so the
cache total lies between the two baseline totals. The observed baseline drift
exceeds the initial aggregate cache delta. These three runs establish no
reliable end-to-end cache improvement or confidence interval.

The separate [shared-currentness arm](assets/finite-prefix-v228/host-policy-shared.json)
has now passed the same parity, six audits and shutdown checks; its 57 final
outputs were rehashed locally. The four forward host durations total 61.458
seconds versus 76.916 and 77.471 seconds for the baselines. New shared-group
checks replace repeated per-rank full checks; admissions, dispatches and I/O
counts remain unchanged. The [plot and counter table](GFX950_HOST_POLICY_V2.md#shared-currentness-observation)
show the observed effect and limits. Another compiler job was observed during
C preflight on the shared host. This is not an isolated or statistically
qualified performance result, GPU timing, kernel overlap or sustained decode.
The [consolidation candidate](GFX950_HOST_POLICY_V2.md#consolidation-candidate)
has since passed 475 selected CPU tests with four ignored, and its new worker
built from fresh sources. It removes duplicate rank currentness checks after
a fresh group fence while retaining queue and poison validation. Its runtime
source is published at
[fe2o3 `725ecc6a5`](https://github.com/harsh-nod/fe2o3/commit/725ecc6a500ff49e7dfaefb38b027f6bcc223ebf)
in both repositories. Its own GPU comparison and the V2 autoregressive diagnostic
remain pending; no earlier GPU result is transferred to the new binary.

## Changes And Retained Failures

The finite route uses an explicit bounded parent/worker protocol, typed
generation and bank checks, and ownership-bound shutdown. Host observation is
opt-in and keeps operational optimizations off. Its nested counters measure
host activity, not GPU elapsed time, kernel overlap, or tokens/s.

A parent compile failure exposed a `u32` image-size versus `u64` request-size
comparison. The correction widens the image size with `u64::from`, and adds
regressions rejecting oversized requests with identical low 32 bits. The
corrected 605-test run is a new result; the failed run is retained.

Portable-deployment tests also exposed aliasing in a cached test fixture.
The test-only correction deep-copies the fixture and adds a mutation-isolation
regression: all 23 tests passed. The production reader and exporter were
unchanged. The earlier 22-test run remains a failure, not a passing result.

## Evidence Identities

These are SHA-256 identities of retained receipts, not links to publicly
downloadable artifacts. Large logs, captures, model weights, compiler caches
and runtime binaries are deliberately excluded from Git. A receipt digest
alone is not a self-contained reproducer or proof.

| Retained receipt | SHA-256 |
| --- | --- |
| Corrected CPU605 completion | `f9b4da95d00cb62a3eadb33d86ee942d0bdf0ecb5c559650161846f4dcd081e8` |
| Fresh-source V2 CPU633 completion | `1fc4d17534161e6e7f96e6d0eba0a2455227ba2166623823f6a74f845b93deae` |
| V2 baseline GPU completion | `8d46f69e481ea906733765dffee163a0a6ba33bf7816316741e867880a82ea5f` |
| V2 admission-cache GPU completion | `0952f130801dcf3c958f5dff8b1228a401f436640ee7591465947edcc3881cac` |
| V2 repeated-baseline GPU completion | `4f5cbd384e136d5c5a05cf0a9d87733b249ee85fec5cd421d3164df87af4110d` |
| V2 shared-currentness GPU completion | `6aad2f46f234a98ac9f792a6108e98e6bbb6269ad81a6913aa1524f8972cd097` |
| Consolidated group-fence CPU475 completion | `0231c40bf9a5ff285e041f29b2c958e26972e73f6a4485072e153a0bd178171b` |
| Consolidated group-fence GPU completion | `ebecff7a6e459cbb6fa8b4c750bc9c524adb417405e2827608175ba0a2c66a5f` |
| Exact-reciprocal checked probe failure | `3d3fd530e171a6e2977d995c78d5665d9e5a728e173eb21b445891148ba61e0d` |
| Branchless reciprocal CPU completion | `d16dd989342d6092445d6fc3d046184ddf160527b1681d713e9b1291f6b106a4` |
| Corrected CPU605 owner | `dde383021440a721bd2c41bff614ea1156a3b36c6fa48cd2ad27c95337af7cb2` |
| Historical KFD completion | `e6cdd55c6a2dda4dafdd25a4c8d5e3670312c912cdbc1f20258a6e93db48e603` |
| Teacher-forced four-forward completion | `56f72c0c8c76e7c2c3f00ca767d5a7b53c66ba4b2c17589059565c2c2532fb8b` |
| Autoregressive four-forward completion | `0553862c7e65b74020028421b3bb668ff6eaf0080ba4a1bc405587707a403d77` |
| Numerical case: genuine position 0 | `a1990e1f8153aa8df23a8db175e293bff7d17b0f3c7fc181b223158df9a41586` |
| Numerical case: genuine position 4 | `81d9b3b17d7763b5c9d40db023c6ba1cf0eb61c61d429d1f1214fbef55475adb` |
| Numerical case: patterned position 15 | `fa7795a3ff7968c212600e2ba30dca7c39b4ccf29ac2b075d42a18377b66fa9e` |
| Numerical case: patterned position 16 | `39ae8374a10ea306e0f1426c87e9c3184f04de250e9f82695973158ad941e1e4` |
| Numerical case: patterned position 2,047 | `7cb4e5ee27e423b96f2eae3fbb2518e14da4f546066cdb08bf5d251f2df32fca` |
| Numerical case: patterned position 2,048 | `676d7e878105972365b15c9aba5f5361825a7761e04f761178487271fae491de` |
| Portable test-only correction, 23 tests | `0481e077defafed91c2272984b3d5d1da5d97cb9da9431ba307760000698de8a` |

## Next Gates

1. Attribute the remaining host-inclusive Readiness40 cost before changing
   execution policy. The opt-in currentness diagnostic accounts for 31.01%
   of warm parent-forward time using disjoint callback/bank intervals; the
   remaining 47.308 seconds across 38 warm forwards is not yet attributed.
   Whole-forward phase timings must distinguish input preparation, metadata,
   embedding, bank, layers, tail, frame construction, fence and commit.
   These are host intervals, not GPU kernel timings or evidence of overlap.
2. Establish launch feasibility for the CPU-qualified Full2303 route before
   running it on the GPU. The distinct long wire and bounded four-capture
   selection are implemented; readiness still executes only forty prompt
   forwards and generates zero tokens. Reduce the measured runtime overhead
   without raising the one-hour abort bound or weakening retirement checks.
   Test the actual full page transitions, KV lifetime, own-output history and
   cleanup before treating it as sustained decode. The independent full
   framework reference and strict generated-output comparator already exist.
   Bind the actual full-run preparer, launcher, worker ELF and retainer to
   their own qualified sources. Existing reference and synthetic admission
   checks are prerequisites, not substitutes for this native run.
3. Qualify the full target workload: single-request Qwen3-8B, BF16,
   target-only decoding, 2,048 prompt tokens and 256 generated tokens. Report
   post-first-token throughput as `255 / (last_delivery - first_delivery)`.
   Require exact agreement of all 256 generated IDs and decoded bytes with
   the independent reference. If that gate fails, investigate the first
   generated-ID mismatch at position `2047 + output_index`; after divergent
   generated histories, label comparisons as different-input trajectories.
4. Retain the [causal layer-zero and KV captures](../qualification/guarded-mlp-readiness40-causal-layer0-v1/README.md)
   and conditional component checks as separate diagnostic evidence. The
   39/40 prompt-position argmax agreement is not a failed generated-output
   gate: both runs generate zero tokens, and neither position-five prediction
   becomes the next input. Selected exact-dot checks favor either implementation
   at different boundaries; they do not establish a native arithmetic bug or
   full-model numerical acceptance. Preserve the historical bitwise check
   separately and do not fit tolerances to observed disagreements.
5. Run equal-work baselines and paired optimization ablations. Host-inclusive
   diagnostics are not GPU overlap graphs or a qualified vLLM comparison.

The selected TP2 experiments do not satisfy the issue's original single-GPU
matrix. No M0-M7 milestone is closed by this checkpoint. Assurance properties
without closed, identity-bound proof remain `Contracted` or `Unsupported`, as
required by [the proof policy](PROOF_DEVELOPMENT.md).
