"""Closed data-only admission of the observed layer-phase diagnostic CPU triple.

No native execution or performance authority is granted; runtime requalification is authenticated.
The reader owns canonical regular-file custody; every returned byte string and pin
is independently authenticated here. Source maps are compared, not live-expanded.
"""
import hashlib
import json
import re
from pathlib import Path

E = "/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220"
ROOTS = {role: E + '/guarded-mlp-layer-phases-' + role + '-diagnostic-cpu-v228-'
         + ('v3' if role == 'runtime' else 'v1') for role in ('runtime', 'worker', 'parent')}
OLD_ROOTS = {"runtime":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-currentness-duration-diagnostic-cpu-v228-v2","worker":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-currentness-duration-diagnostic-cpu-v228-v2","parent":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-currentness-duration-diagnostic-parent-cpu-v228-v2"}
FEATURE = 'engineering-currentness-duration-diagnostics'
WP = 'ferric/adapters/tp-peer-finite-engineering-worker-v1/'
PP = 'ferric/adapters/m1-engineering-execution-v1/'
PARENT_NAME = 'ferric-qwen3-guarded-mlp-readiness-engineering'
WORKER_NAME = 'ferric-tp-peer-finite-engineering-worker-v1'
PARENT_FEATURES = sorted([FEATURE, 'guarded-mlp-full2303-engineering',
    'guarded-mlp-model-engineering', 'guarded-mlp-readiness-engineering',
    'tp-batch-engineering', 'tp-engineering'])
PINS = {"runtime_cpu":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/evidence/complete.json","bytes":3301993,"sha256":"5d1d0d6ac7af9cf94a5883486d41f61812238ac1ae593f26830e3113c1673d13"},"runtime_sources":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/evidence/sources-after.json","bytes":876134,"sha256":"4a9a3370f55ce81e7ce4e8367f38922a4fd69e274f579349f5f66564c4f3a1e1"},"worker_cpu":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/evidence/complete.json","bytes":3090092,"sha256":"b5a0c018ed45b739b535901831e6914a68c7c17dee202a4c67077075cea10c7d"},"worker_sources":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/evidence/sources-after.json","bytes":873993,"sha256":"767da06dcaeb617b1f4555b354b4125ea34f0ad315d1ad43aa3096e3d381326b"},"worker":{"bytes":6683640,"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/target/debug/ferric-tp-peer-finite-engineering-worker-v1","sha256":"a907e189118a35842f45c8c5f0bb43cc37c540e862d274386184ab4ce85af784"},"parent_cpu":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/evidence/complete.json","bytes":7627326,"sha256":"22cf285a8c3caef27c366424c817e0126d1df80dccc7dea36814f01281744078"},"parent_sources":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/evidence/sources-after.json","bytes":873993,"sha256":"30a55c3955c7d43833652c9c7cf4c10ce4b6f1589b7573da815340a9cf7651c2"},"parent":{"bytes":14397976,"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/target/debug/ferric-qwen3-guarded-mlp-readiness-engineering","sha256":"84fb1d82a7e598e393d7a02642b6f001c4ac85222da621c4d2a50b3be1ad74d2"}}
FIXED = {"runtime":{"input-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/input-manifest.json","bytes":422636,"sha256":"56ec122d1529b4227ce907c39749f825d1e2beb108538346992deccc84d7eb27"},"proposal.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/proposal.json","bytes":440584,"sha256":"937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f"},"base-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/base-manifest.json","bytes":905626,"sha256":"672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a"},"inputs/base-complete.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/inputs/base-complete.json","bytes":2569774,"sha256":"5a27b9983ecd0d523226cbf2db4070108cd6deaf75d2ee6fe528274d2f8a5ac2"},"run_cpu.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/run_cpu.py","bytes":32526,"sha256":"6735ed9c959704e58e18c26d86d7a7cb8e33c2654a93a8a5220c6187c316f770"},"supervisor.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/supervisor.py","bytes":41485,"sha256":"8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"},"worker_support.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-v3/worker_support.py","bytes":41316,"sha256":"4d12ba86c4014adaaea1c5c49c3790dffcca78af8326ae09cb085840347a518a"}},"worker":{"input-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/input-manifest.json","bytes":422634,"sha256":"f0b55888376cd9d673d0e917477b2f5f7473fc91b2293093a8cccd8bdee52483"},"proposal.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/proposal.json","bytes":440584,"sha256":"937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f"},"base-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/base-manifest.json","bytes":905626,"sha256":"672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a"},"inputs/base-complete.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/inputs/base-complete.json","bytes":2569774,"sha256":"5a27b9983ecd0d523226cbf2db4070108cd6deaf75d2ee6fe528274d2f8a5ac2"},"run_cpu.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/run_cpu.py","bytes":32526,"sha256":"6735ed9c959704e58e18c26d86d7a7cb8e33c2654a93a8a5220c6187c316f770"},"supervisor.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/supervisor.py","bytes":41485,"sha256":"8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"},"worker_support.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-worker-diagnostic-cpu-v228-v1/worker_support.py","bytes":41316,"sha256":"4d12ba86c4014adaaea1c5c49c3790dffcca78af8326ae09cb085840347a518a"}},"parent":{"input-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/input-manifest.json","bytes":422553,"sha256":"7549f2cf30948583d0728dcac5c5056f802e66c5cd4dc67c72e458d72f41dd66"},"proposal.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/proposal.json","bytes":440584,"sha256":"937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f"},"base-manifest.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/base-manifest.json","bytes":905626,"sha256":"672b40dceaaccb9604b93cb3bd1f165951c0e78404af6a8830762dd7bc29c39a"},"inputs/base-complete.json":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/inputs/base-complete.json","bytes":4165800,"sha256":"f253584fcc0fde7087614c2d9469f37ff950aeb48825fc64d1be1614d6596602"},"run_cpu.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/run_cpu.py","bytes":32526,"sha256":"6735ed9c959704e58e18c26d86d7a7cb8e33c2654a93a8a5220c6187c316f770"},"supervisor.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/supervisor.py","bytes":41485,"sha256":"8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"},"worker_support.py":{"path":"/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220/guarded-mlp-layer-phases-parent-diagnostic-cpu-v228-v1/worker_support.py","bytes":41316,"sha256":"4d12ba86c4014adaaea1c5c49c3790dffcca78af8326ae09cb085840347a518a"}}}
WORKER_LABELS = {'rustc-version', 'metadata', 'worker-tests-build', 'worker-list',
                 'worker-ignored', 'worker-tests', 'worker-build'}
PREFIX = ['/usr/bin/prlimit', '--as=12884901888', '--cpu=1200',
          '--fsize=1073741824', '--core=0', '--']
SOURCE_PREDECESSOR = dict(path=E + '/guarded-mlp-layer-phases-source-v228-v2/predecessor-proposal.json',
    bytes=429829, sha256='7ecf02cba32b1435f1e01a0bd6ed100961f68495067419d5935bdc73e6a27c6a')
FALSE_FLAGS = ('currentness_policy_changed', 'full2303_deadline_changed',
               'gpu_execution', 'native_admission', 'numerical_acceptance', 'performance_claim')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def same(left, right):
    return encoded(left) == encoded(right)


def compact(value):
    return {key: value[key] for key in ('bytes', 'sha256')}


def pin(value, path=None, compact_only=False):
    require(type(value) is dict and set(value) == ({'bytes', 'sha256'} if compact_only
            else {'path', 'bytes', 'sha256'}), 'closed pin fields')
    require(type(value['bytes']) is int and 0 <= value['bytes'] <= 128 << 20
            and type(value['sha256']) is str
            and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, 'typed bounded pin')
    if not compact_only:
        name = value['path']
        require(type(name) is str and name.startswith('/') and str(Path(name)) == name
                and '..' not in Path(name).parts and '\x00' not in name
                and (path is None or name == path), 'canonical exact pin path')
    return value


def parse(raw):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON field')
            out[key] = value
        return out
    def constant(value):
        raise RuntimeError('non-finite JSON constant: ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def blob(read, expected, limit=16 << 20):
    pin(expected)
    require(expected['bytes'] <= limit, 'fixed read extent')
    raw, actual = read(Path(expected['path']), expected, limit=limit, retain=True)
    require(type(raw) is bytes and len(raw) <= limit, 'reader returned bounded bytes')
    observed = dict(path=expected['path'], bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    require(same(pin(actual), observed) and same(observed, expected), 'independent raw byte pin')
    return raw


def document(read, expected):
    return parse(blob(read, expected))


def relocate(value, old, new):
    if isinstance(value, str):
        return value.replace(old, new)
    if isinstance(value, list):
        return [relocate(row, old, new) for row in value]
    if isinstance(value, dict):
        return {key: relocate(row, old, new) for key, row in value.items()}
    return value


def source_map(value, root):
    require(type(value) is dict and len(value) == 2141, 'closed 2141 source map')
    for name, row in value.items():
        require(type(name) is str and not name.startswith('/') and str(Path(name)) == name
                and '..' not in Path(name).parts, 'source-relative identity')
        pin(row, root + '/' + name)
    return {name: compact(row) for name, row in value.items()}


def statuses(value):
    require(type(value) is dict and type(value['named']) is list, 'named test outcomes')
    out = {}
    for row in value['named']:
        require(type(row) is dict and set(row) == {'name', 'outcome'}
                and type(row['name']) is str and re.fullmatch('[A-Za-z0-9_:]+', row['name'])
                and row['name'] not in out and row['outcome'] in ('ok', 'ignored'),
                'unique successful or explicitly ignored named test')
        out[row['name']] = row['outcome']
    for key, outcome in (('passed', 'ok'), ('ignored', 'ignored')):
        require(type(value[key]) is int and value[key] == sum(v == outcome for v in out.values()),
                'named/count agreement')
    require(type(value['failed']) is int and value['failed'] == 0, 'no failed test')
    return out


def healthy(value):
    require(value['passed'] is True and value['failure'] is None
            and value['postcheck_errors'] == [] and value['source_unchanged'] is True
            and same(value['input_sources'], value['final_sources'])
            and value['gpu_execution'] is False, 'qualified successful CPU-only source-stable receipt')


def phases(value, previous, proposal, role):
    root, old = ROOTS[role], OLD_ROOTS[role]
    recipes = [p for p in previous['phases'] if (
        p['label'] in WORKER_LABELS if role == 'worker' else
        p['label'] not in (WORKER_LABELS - {'rustc-version'}) | {'rustfmt', 'rustfmt-check'}
        if role == 'runtime' else p['label'] not in ('rustfmt', 'rustfmt-check'))]
    labels = ['rustfmt-check'] + [p['label'] for p in recipes]
    if role == 'parent':
        labels += ['parent-forward-phase-policy', 'parent-layer-phase-policy']
    require(len(value['phases']) == {'runtime': 20, 'worker': 8, 'parent': 70}[role]
            and [p['label'] for p in value['phases']] == labels, 'exact original phase order')
    expected = {p['label']: relocate(p['argv'], old, root) for p in recipes}
    expected['rustfmt-check'] = PREFIX + [value['tool_pins']['rustfmt']['path'],
        '--edition', '2024', '--config', 'skip_children=true', '--check',
        *[root + '/' + n for n in proposal['overlay']]]
    if role == 'parent':
        for label, module in (
                ('parent-forward-phase-policy', 'finite_guarded_mlp_readiness_forward_durations_v1'),
                ('parent-layer-phase-policy', 'finite_guarded_mlp_readiness_layer_durations_v2')):
            argv = list(expected['parent-currentness-duration-policy'])
            argv[argv.index('--lib') + 1] = module + '::tests::'
            expected[label] = argv
    for row in value['phases']:
        label = row['label']
        require(type(row['exit_code']) is int and row['exit_code'] == 0
                and all(row[k] is True for k in ('natural_exit', 'reaped', 'process_group_absent'))
                and all(row[k] is False for k in ('timed_out', 'forced_cleanup'))
                and row['observed_signals'] == [] and row['adopted_reaped'] == []
                and row['exception'] is None and row['storage_failure'] is None
                and type(row['pid']) is int and row['pid'] > 0 and row['pgid'] == row['pid']
                and type(row['elapsed_ns']) is int and row['elapsed_ns'] >= 0,
                'natural retired owned phase without cleanup')
        require(same(row['argv'], expected[label]) and row['argv'][:6] == PREFIX,
                'unchanged qualified bounded recipe')
        for key, suffix in (('command', 'command.json'), ('stdout', 'stdout'), ('stderr', 'stderr')):
            name = label + '.' + suffix
            pin(row[key], root + '/evidence/' + name)
            require(same(row[key], value['raw'][name]), 'phase/raw original pin join')
    raw_names = {label + '.' + suffix for label in labels
                 for suffix in ('command.json', 'started.json', 'result.json', 'stdout', 'stderr')}
    raw_names |= {'dependencies-before.json', 'sources-before.json', 'sources-after.json'}
    require(set(value['raw']) == raw_names
            and len(value['raw']) == {'runtime': 103, 'worker': 43, 'parent': 353}[role],
            'closed original raw roster')
    for name, row in value['raw'].items():
        pin(row, root + '/evidence/' + name)

def names(value, previous, proposal, role):
    additions = proposal['new_tests'][role]['diagnostic']
    require(additions == sorted(set(additions))
            and len(additions) == {'runtime': 17, 'worker': 58, 'parent': 46}[role]
            and proposal['new_tests'][role]['default'] == [], 'exact feature-only additions')
    phase_labels = {p['label'] for p in value['phases']}
    old_tests = {label: row for label, row in previous['tests'].items() if label in phase_labels}
    new_scopes = {'parent-forward-phase-policy', 'parent-layer-phase-policy'} if role == 'parent' else set()
    require(set(value['tests']) == set(old_tests) | new_scopes, 'closed original and new test scopes')
    by_label = {p['label']: p for p in value['phases']}
    selected = set()
    for label in sorted(value['tests']):
        if label == 'interface-doc-tests':
            require(same(value['tests'][label], previous['tests'][label])
                    and value['tests'][label]['passed'] == 10, 'unchanged selected runtime docs')
            continue
        if label in ('kfd-tests', 'worker-tests'):
            added = set(additions)
        else:
            argv = by_label[label]['argv']
            selector = argv[argv.index('--lib') + 1] if '--lib' in argv else None
            added = {n for n in additions if selector is not None
                     and (n == selector or ('--exact' not in argv and selector in n))}
        if role != 'runtime':
            require(not selected & added, 'new names selected only once')
        selected |= added
        expected = statuses(old_tests[label]) if label in old_tests else {}
        require(not set(expected) & added, 'genuinely new names')
        require(statuses(value['tests'][label]) == expected | {n: 'ok' for n in added},
                'all original names and statuses preserved')
    require(selected == set(additions), 'all new names selected')
    primary = 'kfd-tests' if role == 'runtime' else 'worker-tests'
    old_inventory = (sorted(statuses(previous['tests'][primary])) if role != 'parent'
                     else previous['inventory'])
    require(value['inventories'] == sorted(old_inventory + additions)
            and len(value['inventories']) == {'runtime': 1217, 'worker': 915, 'parent': 1104}[role],
            'actual complete inventory census')
    if role == 'parent':
        require(sum(v['passed'] for v in value['tests'].values()) == 641
                and sum(v['ignored'] for v in value['tests'].values()) == 0,
                'actual selected parent scope census, not globally unique names')
    else:
        require(value['tests'][primary]['passed'] == (1209 if role == 'runtime' else 911)
                and value['tests'][primary]['ignored'] == (8 if role == 'runtime' else 4),
                'actual primary suite census, excluding focused reruns and docs')

def products(value, previous, role):
    root, old = ROOTS[role], OLD_ROOTS[role]
    prior = {n: v for n, v in previous['artifacts'].items()
             if role == 'parent' or (n.startswith('worker') if role == 'worker' else not n.startswith('worker'))}
    require(set(value['artifacts']) == set(prior)
            and len(prior) == {'runtime': 6, 'worker': 5, 'parent': 7}[role], 'all qualified product roles')
    features = ([FEATURE] if role == 'worker' else PARENT_FEATURES if role == 'parent'
                else ['default', FEATURE, 'engineering-gfx950'])
    package = WP if role == 'worker' else PP if role == 'parent' else 'fe2o3/crates/fe2o3-kfd/'
    for name, row in value['artifacts'].items():
        current, before = row['cargo_artifact'], prior[name]['cargo_artifact']
        for field in ('target', 'profile', 'features', 'manifest_path', 'package_id'):
            require(same(current[field], relocate(before[field], old, root)), 'unchanged Cargo product ' + field)
        require(current['reason'] == 'compiler-artifact' and current['features'] == features
                and current['manifest_path'] == root + '/' + package + 'Cargo.toml'
                and current['profile']['opt_level'] == '2'
                and current['profile']['debug_assertions'] is True
                and current['profile']['overflow_checks'] is True
                and current['profile']['debuginfo'] == 0, 'exact opt2 diagnostic product')
        product = pin(row['pin'])
        require(product['path'].startswith(root + '/target/debug/')
                and current['executable'] == product['path']
                and current['filenames'].count(product['path']) == 1,
                'qualified target executable identity')
    if role == 'worker':
        require(value['cli_executable_unchanged_across_tests'] is True
                and same(value['cli_executable_before_tests'], value['artifacts']['worker']['pin']),
                'same real worker executable before and after integration probes')
    else:
        require(value['cli_executable_before_tests'] is None
                and value['cli_executable_unchanged_across_tests'] is False,
                'no invented parent worker CLI test assertion')


def metadata(read, value, previous, role):
    root, old = ROOTS[role], OLD_ROOTS[role]
    label = 'runtime-metadata' if role == 'runtime' else 'metadata'
    before_pin = dict(path=root + '/inputs/base-metadata.json',
                      **compact(previous['raw'][label + '.stdout']))
    before = document(read, before_pin)
    current = document(read, value['raw'][label + '.stdout'])
    require(same(current, relocate(before, old, root)), 'exact unchanged resolved Cargo graph')
    package = WP if role == 'worker' else PP if role == 'parent' else 'fe2o3/crates/fe2o3-kfd/'
    packages = [p for p in current['packages'] if p['manifest_path'] == root + '/' + package + 'Cargo.toml']
    require(len(packages) == 1, 'one exact root package')
    nodes = [n for n in current['resolve']['nodes'] if n['id'] == packages[0]['id']]
    features = ([FEATURE] if role == 'worker' else PARENT_FEATURES if role == 'parent'
                else ['default', FEATURE, 'engineering-gfx950'])
    require(len(nodes) == 1 and nodes[0]['features'] == features, 'diagnostic resolved features')
    command = document(read, value['raw'][label + '.command.json'])
    phase = next(p for p in value['phases'] if p['label'] == label)
    requested = ([FEATURE] if role == 'worker' else [
        'guarded-mlp-readiness-engineering', 'guarded-mlp-full2303-engineering', FEATURE]
        if role == 'parent' else [FEATURE, 'engineering-gfx950'])
    argv, env = command['argv'], command['env']
    cwd = root + '/' + (package.rstrip('/') if role != 'runtime' else 'fe2o3')
    require(argv == phase['argv'] and argv[argv.index('--features') + 1].split(',') == requested
            and '--offline' in argv and '--locked' in argv and command['cwd'] == cwd,
            'original requested features and offline metadata command')
    require(all(env[k] == '' for k in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES'))
            and env['CARGO_BUILD_JOBS'] == '2' and env['CARGO_NET_OFFLINE'] == 'true'
            and env['CARGO_TARGET_DIR'] == root + '/target', 'GPU-hidden owned build environment')
    for profile in ('DEV', 'TEST'):
        require(env['CARGO_PROFILE_' + profile + '_OPT_LEVEL'] == '2'
                and env['CARGO_PROFILE_' + profile + '_DEBUG_ASSERTIONS'] == 'true'
                and env['CARGO_PROFILE_' + profile + '_OVERFLOW_CHECKS'] == 'true',
                'observed opt2 assertions and overflow checks')

def admit(plan, read):
    """Return original (runtime, worker, parent) CPU receipts; no execution authority."""
    require(type(plan) is dict and callable(read), 'plan and data-only reader')
    for key, expected in PINS.items():
        require(key in plan and same(pin(plan[key]), expected), 'fixed observed plan pin: ' + key)
    receipts, projects, predecessors, bases = {}, {}, {}, {}
    source_predecessor = document(read, SOURCE_PREDECESSOR)
    for role in ('runtime', 'worker', 'parent'):
        root, fixed = ROOTS[role], FIXED[role]
        value = document(read, PINS[role + '_cpu'])
        healthy(value)
        require(value['schema'] == 'ferric-readiness40-layer-phases-cpu-v1'
                and value['role'] == role and value['mode'] == 'diagnostic'
                and all(value[k] is False for k in FALSE_FLAGS)
                and value['runtime_source_changed'] is True
                and value['runtime_tests_repeated'] is (role == 'runtime'), 'new CPU-only role/mode contract')
        limits = dict(address_space_bytes=12 << 30, affinity=[8, 9], cargo_jobs=2,
            cleanup_reserve_seconds=50, cpu_seconds=1200, gpu_hidden=True,
            initial_free_bytes=40 << 30, leaf_seconds=1200 if role == 'parent' else 1800,
            live_free_bytes=38 << 30, nice=10, scratch_bytes=6 << 30,
            stream_bytes=64 << 20, whole_seconds=3600)
        require(same(value['limits'], limits), 'unchanged CPU resource/lifecycle bounds')
        sources = document(read, PINS[role + '_sources'])
        require(same(sources, value['final_sources']), 'original final map equals receipt')
        closed = source_map(sources, root)
        inputs = document(read, fixed['input-manifest.json'])
        require(same(value['input_manifest'], fixed['input-manifest.json'])
                and inputs['schema'] == 'ferric-layer-phases-cpu-input-v1'
                and inputs['root'] == root and inputs['role'] == role
                and inputs['mode'] == 'diagnostic' and inputs['attempt'] == ('v3' if role == 'runtime' else 'v1')
                and same(inputs['files'], closed), 'exact sealed input identity and source closure')
        for name in ('run_cpu.py', 'supervisor.py', 'worker_support.py'):
            require(same(sources[name], fixed[name]), 'qualified controller/helper source')
            blob(read, fixed[name])
        proposal = document(read, fixed['proposal.json'])
        baseline = document(read, fixed['base-manifest.json'])
        previous = document(read, fixed['inputs/base-complete.json'])
        healthy(previous)
        require(previous['schema'] == ('ferric-guarded-mlp-currentness-duration-cpu-v1' if role != 'parent'
                else 'ferric-guarded-mlp-currentness-duration-parent-cpu-v1')
                and previous['source_generation'] == ('currentness-duration-diagnostic-coupled-v2'
                if role != 'parent' else 'currentness-duration-diagnostic-parent-v2')
                and previous['qualification_mode'] == 'diagnostic', 'exact qualified predecessor kind')
        require(same(value['predecessor'], compact(fixed['inputs/base-complete.json']))
                and same(inputs['predecessor'], value['predecessor'])
                and inputs['predecessor_root'] == OLD_ROOTS[role]
                and same(inputs['tool_pins'], previous['tool_pins'])
                and same(value['tool_pins'], previous['tool_pins']), 'fixed predecessor/tool lineage')
        require(same(value['proposal'], compact(fixed['proposal.json']))
                and same(inputs['proposal'], value['proposal'])
                and same(proposal['base_manifest'], compact(fixed['base-manifest.json']))
                and proposal['schema'] == 'ferric-readiness40-layer-phases-source-v1'
                and proposal['feature'] == FEATURE
                and all(proposal[k] is False for k in ('compiled', 'tests_executed',
                    'kernel_math_changed', 'currentness_policy_changed',
                    'gpu_execution', 'native_admission', 'numerical_acceptance', 'performance_claim')),
                'sealed source proposal without invented qualification')
        require(proposal['runtime_source_changed'] is True
                and same(proposal['predecessor'], compact(SOURCE_PREDECESSOR)), 'actual source predecessor chain')
        project = {n: p for n, p in closed.items() if n.startswith(('ferric/', 'fe2o3/'))}
        require(len(project) == 2138 and same(project, proposal['files']), 'exact qualified project roster')
        for p in project.values():
            pin(p, compact_only=True)
        old = {n: compact(p) for n, p in baseline['sources'].items()}
        require(baseline['schema'] == 'ferric-forward-phases-authoring-baseline-v1'
                and baseline['source_bodies'] == 2128 and len(old) == 2128
                and baseline['shared_worker_bodies'] == 236
                and all(baseline[k] is False for k in ('gpu_execution', 'native_admission', 'tests_executed'))
                and set(old) <= set(project), 'closed actual source baseline')
        changed = sorted(n for n in project if not same(project[n], old.get(n)))
        require(changed == proposal['overlay'] and len(changed) == 30
                and all(n.startswith((WP, PP, 'fe2o3/crates/fe2o3-kfd/')) and n.endswith('.rs') for n in changed),
                'only thirty cumulative qualified Rust postimages; Cargo/locks preserved')
        prior_files = source_predecessor['files']
        delta = {n for n in project if not same(project[n], prior_files.get(n))}
        require(len(prior_files) == 2132 and set(prior_files) <= set(project) and len(delta) == 24
                and sum(n.startswith('fe2o3/') for n in delta) == 12, 'twenty-four qualified changes after forward phases')
        phases(value, previous, proposal, role)
        names(value, previous, proposal, role)
        products(value, previous, role)
        metadata(read, value, previous, role)
        if role != 'runtime':
            selected = value['artifacts']['worker' if role == 'worker' else PARENT_NAME]
            require(same(selected['pin'], PINS[role])
                    and selected['cargo_artifact']['target']['name'] == (WORKER_NAME if role == 'worker' else PARENT_NAME)
                    and selected['cargo_artifact']['target']['kind'] == ['bin']
                    and selected['cargo_artifact']['profile']['test'] is False, 'selected actual native CLI product')
            elf = blob(read, PINS[role], 64 << 20)
            require(elf[:6] == b'\x7fELF\x02\x01' and elf[18:20] == b'\x3e\x00',
                    'actual selected ELF64 little-endian x86-64 bytes')
        receipts[role], projects[role], predecessors[role], bases[role] = value, project, previous, old
    require(all(same(projects['runtime'], projects[r]) and same(bases['runtime'], bases[r])
                for r in ('worker', 'parent')), 'whole runtime/worker/parent project postimages equal')
    shared = {n: p for n, p in projects['worker'].items() if n.startswith(WP)}
    runtime = {n: p for n, p in projects['worker'].items() if n.startswith('fe2o3/')}
    require(len(shared) == 242 and len(runtime) == 833, '242 shared worker and 833 requalified runtime bodies')
    original_runtime = {n: compact(p) for n, p in predecessors['worker']['final_sources'].items()
                        if n.startswith('fe2o3/')}
    original_parent = {n: compact(p) for n, p in predecessors['parent']['final_sources'].items()
                       if n.startswith('ferric/')}
    require(same(bases['worker'], original_runtime | original_parent),
            'entire baseline joins actually qualified runtime and parent maps')
    return receipts['runtime'], receipts['worker'], receipts['parent']

