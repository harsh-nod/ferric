"""Synthetic three-record retention workflows, not native observations.

The immutable legacy fixture builder authenticates its 152 original inputs and
passes the legacy predicates first. This module only derives data and source
bindings in memory. All new validate/verify/retain predicates remain real; no
native process, model input, or project executable is run by these tests.
"""
import copy
from contextlib import contextmanager
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch

import retention_tool as E
from legacy import retention_tool as old_retainer
from legacy import test_retention_workflows as old_fixture

DIRECTORY = Path(__file__).resolve().parent
FIXTURE_ROOT = Path('/synthetic/forward-phase-retention-only')
CASE = 'tail_forward'
FLAGS = dict(forward_phase_durations=True, currentness_durations_nested=True,
             disjoint_forward_phases=True)
PHASES = ['input', 'metadata', 'embedding', 'bank', 'layers', 'tail', 'frame', 'fence', 'commit']
encoded = old_fixture.encoded
identity = old_fixture.identity
file_pin = old_fixture.file_pin


@contextmanager
def bindings(fixture):
    # Data/source identities only; no admission function is replaced.
    with patch.multiple(E, REMOTE=FIXTURE_ROOT, ROOT_PINS=fixture['root_pins'],
                        ADMISSION=fixture['admission'], CHECKER=fixture['checker']):
        yield


@contextmanager
def fixture_helpers():
    # Reuse only the byte-accounting fixture utilities under explicit data names.
    with patch.multiple(old_fixture, E=E, CASE=CASE, FIXTURE_ROOT=FIXTURE_ROOT):
        yield


def update_native(fixture, stderr=None, edit_summary=None):
    with fixture_helpers():
        old_fixture.update_native(fixture, stderr, edit_summary)


def reconcile(fixture):
    with fixture_helpers():
        old_fixture.reconcile(fixture)


def synthetic_forward(first, second):
    policy, callbacks = json.loads(first), json.loads(second)
    rows = []
    for position, old in enumerate(callbacks['forwards']):
        phases = [1] * 9
        if position >= 2:
            measured = old['measured']
            phases[3] = max(1, measured['bank_guarded_body_ns'])
            phases[4] = max(1, sum(row['elapsed_ns'] for row in measured['layers'].values()))
            phases[5] = max(1, sum(row['elapsed_ns'] for row in measured['tail'].values()))
        rows.append(dict(position=position, phase_ns=phases, forward_body_ns=sum(phases)))
    return dict(schema='FerricReadiness40ForwardPhaseDurationsV1', instrumented=True,
        policy_sha256=list(hashlib.sha256(first).digest()),
        currentness_record_sha256=list(hashlib.sha256(second).digest()),
        session=policy['session'], worker_sha256=policy['worker_sha256'],
        transcript_sha256=policy['transcript_sha256'], phase_order=list(PHASES), forwards=rows,
        host_elapsed_nanoseconds=True, disjoint_phases=True, currentness_durations_nested=True,
        gpu_timing=False, numerical_acceptance=False, performance_claim=False, execution_authority=False)


def make_fixture():
    with patch.multiple(old_fixture, E=old_retainer,
            FIXTURE_DIRECTORY=DIRECTORY / 'fixtures' / 'tail-matched-v2'):
        prior = old_fixture.make_fixture()
        with old_fixture.bindings(prior):
            if old_retainer.verify(prior['bodies'], prior['outcomes'])['passed'] is not True:
                raise AssertionError('legacy fixture must pass unchanged original predicates')
    old_root = str(old_fixture.FIXTURE_ROOT)
    replacements = [
        (old_root + '/tail_duration/', str(FIXTURE_ROOT / CASE) + '/'),
        (old_root + '/tail_duration-', str(FIXTURE_ROOT / (CASE + '-'))),
        (old_root, str(FIXTURE_ROOT)),
        (str(old_retainer.WORKER_ROOT), str(E.WORKER_ROOT)),
        (str(old_retainer.PARENT_ROOT), str(E.PARENT_ROOT)),
        ('ferric-guarded-mlp-readiness40-tail-currentness-duration-',
         'ferric-guarded-mlp-readiness40-tail-forward-duration-'),
        ('bank_scoped_census_tail_duration', 'bank_scoped_census_tail_forward'),
        ('tail_duration', CASE),
    ]
    bodies = {}
    for name, raw in prior['bodies'].items():
        if name.startswith('baseline/'):
            bodies[name] = raw
            continue
        target = name.replace('tail_duration', CASE)
        if name.endswith('.json') or name == 'tail_duration/parent/stdout':
            raw = encoded(old_fixture.rewrite(json.loads(raw), replacements))
        bodies[target] = raw
    for name in E.ROOT_PINS:
        if name.endswith('.py'):
            bodies[name] = (DIRECTORY / name).read_bytes()
    bodies['retention_tool.py'] = Path(E.__file__).resolve().read_bytes()
    terminal = old_fixture.rewrite(prior['terminal'], replacements)
    terminal.update(FLAGS)
    terminal['controller'] = file_pin(FIXTURE_ROOT / 'run_model_gpu.py', bodies['run_model_gpu.py'])
    prepared = json.loads(bodies['prepared-inputs.json'])
    prepared.update(FLAGS)
    prepared['controller'] = file_pin(FIXTURE_ROOT / 'prepare_model_inputs.py',
                                      bodies['prepare_model_inputs.py'])
    plan_name = CASE + '-input.json'
    plan = json.loads(bodies[plan_name])
    plan['request'] = file_pin(FIXTURE_ROOT / (CASE + '-request.json'),
                               bodies[CASE + '-request.json'])
    bodies[plan_name] = encoded(plan)
    terminal['plan'] = file_pin(FIXTURE_ROOT / plan_name, bodies[plan_name])
    prepared['plans'] = {CASE: terminal['plan']}
    prepared['requests'] = {CASE: plan['request']}
    bodies['prepared-inputs.json'] = encoded(prepared)
    root_pins = {name: identity(bodies[name]) for name in E.ROOT_PINS}
    terminal['readset'] = {path: value for path, value in terminal['readset'].items()
                           if not path.startswith(str(FIXTURE_ROOT) + '/')}
    for name in root_pins:
        if ((name.endswith('.py') and name != 'prepare_model_inputs.py')
                or name in (plan_name, CASE + '-request.json')):
            row = file_pin(FIXTURE_ROOT / name, bodies[name])
            terminal['readset'][row['path']] = row
    fixture = dict(bodies=bodies, terminal=terminal, root_pins=root_pins,
        admission={key: E.compact(value) for key, value in terminal['admission'].items()},
        checker=copy.deepcopy(terminal['checker_cpu']))
    first, second, empty = bodies[CASE + '/native/child-stderr.bin'].split(b'\n')
    if empty != b'':
        raise AssertionError('unchanged canonical two-record fixture')
    prefix = first + b'\n' + second + b'\n'
    third = encoded(synthetic_forward(first + b'\n', second + b'\n')) + b'\n'
    update_native(fixture, prefix + third)
    with bindings(fixture):
        *_, forward = E.validation_modules(bodies)
        summary_raw = bodies[CASE + '/native/complete.json']
        summary = json.loads(summary_raw)
        request = json.loads(bodies[CASE + '-request.json'])
        read_body = lambda row: E.native_body(bodies, row)
        checked = forward.validate(CASE, bodies[CASE + '/parent/stdout'], summary_raw,
            request, FIXTURE_ROOT / CASE / 'native', read_body,
            summary['bootstrap']['sequence']['prompt_tokens'])
        baseline_raw, baseline_checked = E.verify_baseline(bodies, None)
        parity = forward.compare_same_side(summary_raw, baseline_raw, checked, baseline_checked, read_body)
    terminal.update(observation=checked['ordinary'], matched_timing=checked, same_side_parity=parity)
    for name, value in (('observation.json', checked['ordinary']),
                        ('matched.json', checked), ('parity.json', parity)):
        bodies[CASE + '/' + name] = encoded(value)
    reconcile(fixture)
    fixture['original_prefix'] = prefix
    return fixture


def write_archive(path, fixture, observation, extra=None):
    bodies = dict(fixture['bodies'])
    manifest = dict(schema='ferric-guarded-mlp-readiness40-tail-forward-duration-retention-v1',
        source_root=str(FIXTURE_ROOT), files={name: identity(raw) for name, raw in sorted(bodies.items())},
        observation=observation, outcomes=fixture['outcomes'])
    bodies['manifest.json'] = encoded(manifest)
    with tarfile.open(path, 'w:gz', format=tarfile.USTAR_FORMAT) as tar:
        for name, raw in sorted(bodies.items()):
            row = tarfile.TarInfo(name); row.size = len(raw); row.mode = 0o600
            tar.addfile(row, io.BytesIO(raw))
        if extra is not None:
            row = tarfile.TarInfo(extra); row.size = 0
            tar.addfile(row, io.BytesIO(b''))
    return identity(path.read_bytes())['sha256'], bodies


class ForwardRetentionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = make_fixture()
        with bindings(cls.fixture):
            checked = E.verify(cls.fixture['bodies'], cls.fixture['outcomes'])
        if not checked['passed']:
            raise AssertionError('positive fixture must pass every new retention predicate')

    def fresh(self):
        return copy.deepcopy(self.fixture)

    def verify(self, fixture):
        with bindings(fixture):
            return E.verify(fixture['bodies'], fixture['outcomes'])

    def roundtrip(self, fixture):
        observation = self.verify(fixture)
        with tempfile.TemporaryDirectory(prefix='synthetic-forward-retention-') as directory:
            archive = Path(directory) / 'fixture.tar.gz'
            destination = Path(directory) / 'retained'
            sha, expected = write_archive(archive, fixture, observation)
            with bindings(fixture):
                got = E.retain(archive, sha, destination)
            self.assertEqual(got['members'], len(expected))
            self.assertEqual(got['cases'], observation['cases'])
            self.assertEqual(got['passed'], observation['passed'])
            self.assertEqual({p.relative_to(destination).as_posix(): p.read_bytes()
                              for p in destination.rglob('*') if p.is_file()}, expected)
        return observation

    def test_forward_complete_verify_retain_preserves_three_original_records(self):
        fixture = self.fresh()
        raw = fixture['bodies'][CASE + '/native/child-stderr.bin']
        got = self.roundtrip(fixture)
        self.assertTrue(raw.startswith(fixture['original_prefix']))
        self.assertEqual(len(raw.splitlines()), 3)
        self.assertEqual((got['selected_original_bodies'], got['raw_files']), (168, 73))
        checked = got['cases'][CASE]['matched_timing']
        self.assertEqual(checked['policy']['file']['sha256'], identity(raw)['sha256'])
        self.assertEqual(checked['policy']['file']['bytes'], len(raw))
        self.assertEqual(checked['timing']['disjoint_spans'], 124)
        self.assertEqual(len(checked['policy']['forward_record']['forwards']), 40)
        self.assertEqual({key: got[key] for key in FLAGS}, FLAGS)
        self.assertFalse(got['native_rerun'] or got['gpu_execution']
                         or got['numerical_acceptance'] or got['performance_claim'])

    def test_forward_failed_prefix_remains_failed_after_retain(self):
        fixture = self.fresh(); terminal = fixture['terminal']
        labels = {'parent-readelf', 'after-0', 'after-1', 'after-2'}
        terminal['phases'] = [row for row in terminal['phases'] if row['label'] in labels]
        terminal['phases'][0]['exit_code'] = 101
        terminal.update(passed=False, errors=['synthetic forward prelaunch failure'], native_attempts=0,
            observation=None, matched_timing=None, same_side_parity=None, owned_worker_lineage_verified=False,
            native_spawn_observed=False, gpu_execution_requested=False, gpu_execution=False,
            gpu_execution_confirmed=False, partial_gpu_execution_possible=False,
            model_source_authenticated_by_qualified_parent=False)
        keep = {'initial-topology.json'} | {name + '-topology.json' for name in labels if name.startswith('after-')}
        keep |= {label + '/' + name for label in labels
                 for name in ('command.json', 'started.json', 'stdout', 'stderr', 'result.json')}
        fixture['bodies'] = {name: raw for name, raw in fixture['bodies'].items()
                            if not name.startswith(CASE + '/') or name[len(CASE) + 1:] in keep}
        reconcile(fixture)
        got = self.roundtrip(fixture)
        self.assertFalse(got['passed'] or got['original_owned_lineage_revalidated'])
        self.assertEqual(got['raw_files'], 24)
        self.assertEqual(got['cases'][CASE]['original_terminal']['name'], 'failed.json')

    def test_forward_late_failure_keeps_all_raw_without_success_promotion(self):
        fixture = self.fresh()
        fixture['terminal'].update(passed=False, errors=['synthetic forward posthash refusal'])
        reconcile(fixture)
        got = self.roundtrip(fixture)
        self.assertFalse(got['passed'] or got['cases'][CASE]['retained_success_revalidated'])
        self.assertEqual(got['raw_files'], 73)

    def test_forward_absent_case_has_no_invented_terminal(self):
        fixture = self.fresh()
        fixture['bodies'] = {name: raw for name, raw in fixture['bodies'].items()
                            if not name.startswith(CASE + '/')}
        fixture['outcomes'] = {CASE: None}
        got = self.roundtrip(fixture)
        self.assertEqual((got['selected_original_bodies'], got['raw_files']), (94, 0))
        self.assertFalse(got['passed'] or got['cases'][CASE]['present'])
        self.assertIsNone(got['cases'][CASE]['original_terminal'])

    def test_forward_requires_third_record_and_canonical_order(self):
        for mutation in ('two', 'duplicate', 'reordered', 'extra'):
            fixture = self.fresh()
            lines = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines(keepends=True)
            changed = (lines[:2] if mutation == 'two' else
                       lines + [lines[2]] if mutation == 'duplicate' else
                       [lines[0], lines[2], lines[1]] if mutation == 'reordered' else lines + [b'\n'])
            update_native(fixture, b''.join(changed)); reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_forward_third_identity_and_scope_mutations_reach_real_validator(self):
        for key in ('policy_sha256', 'currentness_record_sha256', 'worker_sha256',
                    'transcript_sha256', 'disjoint_phases', 'performance_claim'):
            fixture = self.fresh()
            first, second, third = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines()
            record = json.loads(third)
            if type(record[key]) is list:
                record[key][0] ^= 1
            else:
                record[key] = not record[key]
            update_native(fixture, first + b'\n' + second + b'\n' + encoded(record) + b'\n')
            reconcile(fixture)
            with self.subTest(key=key), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_forward_rows_sum_and_nested_callback_containment_are_checked(self):
        for mutation in ('position', 'sum', 'bank', 'layers', 'tail'):
            fixture = self.fresh()
            first, second, third = fixture['bodies'][CASE + '/native/child-stderr.bin'].splitlines()
            record = json.loads(third); row = record['forwards'][2]
            if mutation == 'position':
                row['position'] = 1
            elif mutation == 'sum':
                row['forward_body_ns'] += 1
            else:
                row['phase_ns'][{'bank': 3, 'layers': 4, 'tail': 5}[mutation]] = 0
                row['forward_body_ns'] = sum(row['phase_ns'])
            update_native(fixture, first + b'\n' + second + b'\n' + encoded(record) + b'\n')
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_forward_whole_stderr_pin_cannot_be_replaced_by_prefix_pin(self):
        fixture = self.fresh()
        def truncate_pin(summary):
            summary['files']['child_stderr'] = file_pin(
                FIXTURE_ROOT / CASE / 'native/child-stderr.bin', fixture['original_prefix'], True)
        update_native(fixture, edit_summary=truncate_pin); reconcile(fixture)
        with self.assertRaises((RuntimeError, ValueError)):
            self.verify(fixture)

    def test_forward_healthy_close_owned_lineage_and_capture_custody_remain_real(self):
        for mutation in ('close', 'lineage', 'capture'):
            fixture = self.fresh()
            if mutation == 'close':
                update_native(fixture, edit_summary=lambda value: value.update(native_closed=False))
            elif mutation == 'lineage':
                parent = next(row for row in fixture['terminal']['phases'] if row['label'] == 'parent')
                parent['lineage'][1]['identity']['ppid'] += 1
            else:
                fixture['bodies'][CASE + '/native/capture-5.bin'] += b'\0'
            reconcile(fixture)
            with self.subTest(mutation=mutation), self.assertRaises((RuntimeError, ValueError)):
                self.verify(fixture)

    def test_forward_closed_sources_require_both_new_helpers_and_old_duration(self):
        for name in ('validate_forward.py', 'forward_cpu_admission.py', 'validate_duration.py'):
            for mutation in ('missing', 'changed', 'readset'):
                fixture = self.fresh()
                if mutation == 'missing':
                    fixture['bodies'].pop(name)
                elif mutation == 'changed':
                    fixture['bodies'][name] += b'\n'
                else:
                    fixture['terminal']['readset'].pop(str(FIXTURE_ROOT / name))
                    reconcile(fixture)
                with self.subTest(name=name, mutation=mutation), self.assertRaises(RuntimeError):
                    self.verify(fixture)

    def test_forward_mode_flags_source_maps_and_outcome_custody_are_closed(self):
        for mutation in ('old_mode', 'flag', 'worker_sources', 'parent_sources', 'terminal_sha', 'extra'):
            fixture = self.fresh()
            if mutation == 'old_mode':
                fixture['terminal']['case'] = 'tail_duration'
            elif mutation == 'flag':
                fixture['terminal']['forward_phase_durations'] = False
            elif mutation.endswith('_sources'):
                row = fixture['terminal']['admission'][mutation]
                fixture['terminal']['readset'][row['path']] = dict(row, sha256='0' * 64)
            elif mutation == 'extra':
                fixture['bodies'][CASE + '/unlisted.txt'] = b'synthetic only'
            reconcile(fixture)
            if mutation == 'terminal_sha':
                fixture['outcomes'][CASE]['sha256'] = '0' * 64
            with self.subTest(mutation=mutation), self.assertRaises(RuntimeError):
                self.verify(fixture)

    def test_forward_retain_refuses_hash_duplicate_escape_and_observation_drift(self):
        fixture = self.fresh(); observation = self.verify(fixture)
        with tempfile.TemporaryDirectory(prefix='synthetic-forward-refusal-') as directory:
            root = Path(directory)
            for mutation in ('sha', 'duplicate', 'escape', 'observation'):
                archive = root / (mutation + '.tar.gz')
                changed = copy.deepcopy(observation)
                if mutation == 'observation':
                    changed['forward_phase_durations'] = False
                extra = 'prepared-inputs.json' if mutation == 'duplicate' else '../outside' if mutation == 'escape' else None
                sha, _ = write_archive(archive, fixture, changed, extra)
                if mutation == 'sha':
                    sha = '0' * 64
                destination = root / (mutation + '-retained')
                with self.subTest(mutation=mutation), bindings(fixture), self.assertRaises(RuntimeError):
                    E.retain(archive, sha, destination)
                self.assertFalse(destination.exists())


if __name__ == '__main__':
    unittest.main()
