"""Prepare one three-record Tail diagnostic from matching CPU products; no native execution."""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import stat
import struct
import sys
import time
import types

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
ROOT = E / 'guarded-mlp-readiness40-tail-layer-duration-gpu-v228-v1'
ORDER = ('tail_layer',)
OLD_REQUEST = (9338, '526f0c30630edb83114cfa763ffb98b9242154371250797b9ed55bf8747bed1d')
CPU_ADMISSION_SHA = "b4011260a76746c60320f8d485783114c7c6b7507e307b187084759aa15a1ecd"
IMAGES = {
    'projection_image': (10864, '25338beac39121cf81adfdc5c82c6f39bcfc82c0f7effaa2166bf8a2a9598a25'),
    'guarded_image': (28440, 'de880dcebf79425ccb555c1a2bdca3ff78b926f7b2062d06b918763da4de0f66'),
    'prefix_image': (54344, '29fd58e7b09fee003ed31660e6201c20a7eb5da4b873d0b4d954993f7018f2f8'),
    'tiles_image': (33320, 'b0d1766fdb0fda17ab09496d1120ba3cee29100692b48fcc5b05cf0db0a8d589'),
}
PROMPT = {
    'manifest': (21318, '30d047aafbd7de2b94647154680b0b9d9fb75aae2fd90b081afe0de595a88600'),
    'text': (11224, 'a43ef3619cb96c9c23d020e07630493ced7a588088033a53f1d612448375751a'),
    'tokens': (8192, '2e81cc60562760f972450ef9205a4e764fa3cce6289d85754e7dfbd7de4d4d02'),
}
INPUTS = {}
DEADLINE = float('inf')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def parse(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            require(key not in value, 'duplicate JSON key')
            value[key] = item
        return value
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda _: require(False, 'nonfinite JSON'))

def read(path, expected=None, limit=16 << 20, retain=True):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, 'canonical data input')
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'bounded ordinary data input')
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    digest = hashlib.sha256(); parts = []
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        require(stamp(os.fstat(stream.fileno())) == stamp(before), 'input changed at open')
        while True:
            require(time.monotonic() < DEADLINE, 'data-only whole deadline')
            chunk = stream.read(1 << 20)
            if not chunk: break
            digest.update(chunk)
            if retain: parts.append(chunk)
        require(stamp(os.fstat(stream.fileno())) == stamp(before), 'input changed while read')
    require(stamp(path.lstat()) == stamp(before), 'input changed after read')
    pin = dict(path=str(path), bytes=before.st_size, sha256=digest.hexdigest())
    if expected is not None:
        require(pin == expected, 'exact data input pin')
    require(str(path) not in INPUTS or INPUTS[str(path)] == pin, 'conflicting data pin')
    INPUTS[str(path)] = pin
    return b''.join(parts), pin

def extent(pin, expected):
    require((pin['bytes'], pin['sha256']) == expected, 'qualified extent/hash')

def rust(pin):
    return dict(path=pin['path'], bytes=pin['bytes'], sha256=list(bytes.fromhex(pin['sha256'])))

def from_rust(value):
    require(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'}
            and type(value['bytes']) is int and value['bytes'] > 0
            and type(value['sha256']) is list and len(value['sha256']) == 32
            and all(type(v) is int and 0 <= v <= 255 for v in value['sha256']), 'Rust FilePin')
    return dict(path=value['path'], bytes=value['bytes'], sha256=bytes(value['sha256']).hex())

def load_cpu_admission():
    require(type(CPU_ADMISSION_SHA) is str and re.fullmatch('[0-9a-f]{64}', CPU_ADMISSION_SHA),
            'layer CPU admission source binding remains pending')
    path = Path(__file__).resolve().parent / 'layer_cpu_admission.py'
    raw, pin = read(path, limit=1 << 20)
    require(pin['sha256'] == CPU_ADMISSION_SHA, 'reviewed layer CPU admission source')
    module = types.ModuleType('layer_cpu_admission_bound')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


def bytes_json(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()

def write(path, raw):
    require(len(raw) <= 65536, 'bounded generated data body')
    with path.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    pin = dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    read(path, pin)
    return pin


def main():
    global DEADLINE
    start = time.monotonic(); DEADLINE = start + 120
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 5,
            'python3 -B prepare_layer_model_inputs.py PARENT_RECEIPT SHA PARENT_ELF HISTORICAL_REQUEST')
    require(Path(__file__).resolve().parent == ROOT and ROOT.resolve(strict=True) == ROOT
            and os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == 'smci350-rck-g03-b19-03', 'exact unprivileged deployment root')
    os.umask(0o077); os.sched_setaffinity(0, {8, 9})
    priority = os.getpriority(os.PRIO_PROCESS, 0); require(priority in (0, 10), 'unexpected nice')
    if priority == 0: os.nice(10)
    for kind, cap in ((resource.RLIMIT_AS, 512 << 20), (resource.RLIMIT_FSIZE, 1 << 20), (resource.RLIMIT_CORE, 0)):
        soft, hard = resource.getrlimit(kind)
        ceiling = min([cap] + [v for v in (soft, hard) if v != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (ceiling, ceiling))
    def timeout(_number, _frame): raise RuntimeError('data-only preparation deadline')
    for number in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(number, timeout)
    signal.setitimer(signal.ITIMER_REAL, 120)
    require(re.fullmatch('[0-9a-f]{64}', sys.argv[2]), 'actual parent SHA')
    require(not any(os.path.lexists(ROOT / n) for n in
            ('tail_layer-request.json', 'tail_layer-input.json', 'prepared-inputs.json', *ORDER)),
            'fresh one-shot preparation and native namespace')
    contract = load_cpu_admission()
    admission = copy.deepcopy(contract.PINS)
    require(set(admission) == {'worker_cpu', 'parent_cpu', 'worker_sources', 'parent_sources',
                              'worker', 'parent', 'runtime_cpu', 'runtime_sources'}, 'closed layer CPU binding plan')
    require(admission['parent_cpu']['path'] == str(Path(sys.argv[1]))
            and admission['parent_cpu']['sha256'] == sys.argv[2]
            and admission['parent']['path'] == str(Path(sys.argv[3])),
            'supplied actual layer parent receipt and ELF')
    contract.admit(admission, read)
    parent_pin, worker_pin = admission['parent_cpu'], admission['worker_cpu']
    parent_elf, worker_elf = admission['parent'], admission['worker']
    source_pins = {name: admission[name + '_sources'] for name in ('runtime', 'parent', 'worker')}
    old_raw, old_pin = read(sys.argv[4], limit=16384); extent(old_pin, OLD_REQUEST)
    old = parse(old_raw)
    require(set(old) == {'schema', 'decode', 'projection_image', 'guarded_image'}
            and old['schema'] == 'FerricFiniteGuardedMlpDecodeRequestV1', 'authentic historical input container only')
    d = old['decode']; source = Path(d['source'])
    require(source.is_dir() and source.resolve(strict=True) == source, 'canonical authentic model source')
    prompt = {}
    for name, value in d['prompt'].items():
        pin = from_rust(value); extent(pin, PROMPT[name]); prompt[name] = read(pin['path'], pin)[0]
    require(set(prompt) == set(PROMPT), 'three original prompt bodies')
    tokens = list(struct.unpack('<2048I', prompt['tokens']))
    require(tokens == parse(prompt['manifest'])['input_token_ids']
            and all(type(v) is int and 0 <= v < 151936 for v in tokens), 'all2048 authentic token encodings')
    for value in d['images'].values():
        pin = from_rust(value); read(pin['path'], pin, retain=False)
    images = {name: copy.deepcopy(old[name] if name in old else d[name]) for name in IMAGES}
    for name, value in images.items():
        pin = from_rust(value); extent(pin, IMAGES[name]); read(pin['path'], pin, retain=False)
    requests = {}; plans = {}; sessions = []
    generator = read(Path(__file__).resolve(), retain=False)[1]
    for pin in list(INPUTS.values()): read(pin['path'], pin, retain=False)
    for case in ORDER:
        session = os.urandom(32)
        require(session != bytes(32) and list(session) != d['session']
                and list(session) not in sessions, 'fresh diagnostic readiness session')
        sessions.append(list(session))
        base = {k: copy.deepcopy(v) for k, v in d.items() if k not in ('mode', 'prefix_image', 'tiles_image')}
        base.update(schema='FerricFiniteLongRequestV1', worker=rust(worker_elf), session=list(session),
                    evidence_directory=str(ROOT / case / 'native'))
        require(set(base) == {'schema', 'source', 'worker', 'images', 'expected_bundle_id', 'expected_model_id',
            'device_ids', 'session', 'prompt', 'evidence_directory', 'dispatch_timeout_ms', 'child_deadline_ms'},
            'no four-forward selector transferred into closed readiness config')
        require(base['device_ids'] == [16366993098680759275, 10838076764495710945]
                and base['dispatch_timeout_ms'] == 10000 and base['child_deadline_ms'] == 3600000,
                'unchanged device/deadline bounds')
        request = dict(schema='FerricGuardedMlpReadiness40Position5RequestV1', base=base, **images)
        requests[case] = write(ROOT / (case + '-request.json'), bytes_json(request))
        plan = dict(schema='ferric-guarded-mlp-readiness40-tail-layer-duration-gpu-input-v1',
                    case=case, profile='readiness40_position5', parent_cpu=parent_pin, worker_cpu=worker_pin,
                    parent=parent_elf, worker=worker_elf, parent_sources=source_pins['parent'],
                    worker_sources=source_pins['worker'], runtime_cpu=admission['runtime_cpu'],
                    runtime_sources=source_pins['runtime'], request=requests[case])
        plans[case] = write(ROOT / (case + '-input.json'), bytes_json(plan))
    for pin in list(INPUTS.values()): read(pin['path'], pin, retain=False)
    receipt = dict(schema='ferric-guarded-mlp-readiness40-tail-layer-duration-input-preparation-v1', passed=True,
        controller=generator, historical_request=old_pin, parent_cpu=parent_pin, worker_cpu=worker_pin,
        runtime_cpu=admission['runtime_cpu'],
        readset=INPUTS, requests=requests, plans=plans, prompt_tokens=2048, prompt_positions_requested=40,
        generated_tokens_requested=0, capture_positions=[0, 5, 16, 39], sessions=sessions,
        modes=list(ORDER), instrumented=True, matched_speed_comparison=False, fresh_case_namespaces=True,
        forward_phase_durations=True, disjoint_forward_phases=True, currentness_durations_nested=True,
        layer_phase_durations=True, paired_mlp_durations_nested=True,
        elapsed_seconds=time.monotonic() - start, data_only=True, cpu_tests_executed=False,
        parent_host_timing_requested=True, gpu_timing=False,
        currentness_policies=dict(tail_layer='bank_scoped_census_tail_layer'),
        allocation_preflights_changed=True, allocation_preflights_changed_only_for_candidate=False,
        scoped_tail_requested=True, tail_counters_are_independent=True, bank_guarded_body_includes_callbacks=True,
        census_counters_are_layer_subset=True,
        temporal_equivalent_to_full=False, shared_full_currentness_requested=False,
        cache_kernel_admission_requested=False, operational_currentness_requested=False,
        paired_read_requested=False, paired_terminal_requested=False,
        ordinary_wire_schema_changed=False, ordinary_observation_schema_changed=False,
        native_execution=False, gpu_execution=False, full_long_workload=False,
        numerical_acceptance=False, performance_claim=False, production_authority=False)
    result = write(ROOT / 'prepared-inputs.json', bytes_json(receipt))
    signal.setitimer(signal.ITIMER_REAL, 0)
    print(json.dumps(dict(receipt=result, requests=requests, plans=plans), sort_keys=True)); return 0


if __name__ == '__main__':
    raise SystemExit(main())

