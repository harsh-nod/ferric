"""Bounded V2 admission tests alongside unchanged predecessors; no GPU launch."""
import ast
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import signal
import stat
import sys
import time
import types

E = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220")
ROOT = Path(__file__).resolve().parent
OUT, TMP = ROOT / "evidence", ROOT / "tmp"
SUPERVISOR_SHA = "8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"
SIGNALS = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP, signal.SIGALRM)
WHOLE_SECONDS, LEAF_SECONDS, CLEANUP_SECONDS = 1000, 120, 50
PREDECESSOR_COUNTS = {"legacy-tests": 171, "forward-cpu-tests": 29,
                      "forward-retention-tests": 12, "forward-preparation-tests": 15}
NEW_LEAVES = ("layer-cpu-tests", "layer-retention-tests", "layer-preparation-tests")
LEAF_ORDER = (*PREDECESSOR_COUNTS, *NEW_LEAVES)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def read(path, cap=16 << 20):
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_nlink == 1 and before.st_size <= cap, "bounded ordinary input")
    with path.open("rb") as stream:
        raw = stream.read(cap + 1)
        opened = os.fstat(stream.fileno())
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
                       s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stamp(before) == stamp(opened) == stamp(path.lstat())
            and len(raw) == before.st_size, "input changed")
    return raw


def compact(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def interrupted(number, _frame):
    raise RuntimeError("controller signal " + str(number))


def test_names(path):
    names = []
    for node in ast.parse(read(path)).body:
        if isinstance(node, ast.ClassDef):
            names.extend(path.stem + "." + node.name + "." + item.name for item in node.body
                         if isinstance(item, ast.FunctionDef) and item.name.startswith("test_"))
    return sorted(names)


def main():
    start = time.monotonic()
    deadline = start + WHOLE_SECONDS

    def arm_deadline():
        remaining = deadline - time.monotonic()
        require(remaining > 0, "whole CPU deadline exhausted; retain failed prefix only")
        signal.setitimer(signal.ITIMER_REAL, remaining)

    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 2
            and re.fullmatch("[0-9a-f]{64}", sys.argv[1]), "python3 -B run_cpu.py INPUT_SHA")
    require(ROOT.parent == E
            and re.fullmatch("guarded-mlp-readiness40-tail-layer-duration-native-admission-cpu-v228-v[1-9][0-9]?", ROOT.name)
            and ROOT.resolve(strict=True) == ROOT
            and not os.path.lexists(OUT) and not os.path.lexists(TMP), "fresh exact root")
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == "smci350-rck-g03-b19-03", "exact unprivileged host")
    input_raw = read(ROOT / "input-manifest.json", 1 << 20)
    require(compact(input_raw)["sha256"] == sys.argv[1], "bound input manifest")
    spec = json.loads(input_raw)
    require(spec["schema"] == "ferric-layer-native-admission-input-v1"
            and spec["root"] == str(ROOT)
            and spec["gpu_execution"] is False, "closed input contract")
    require(set(spec["leaves"]) == set(LEAF_ORDER) and spec["leaf_order"] == list(LEAF_ORDER),
            "exact ordered old and new leaves")
    leaf_counts = {label: spec["leaves"][label]["count"] for label in LEAF_ORDER}
    require(all(leaf_counts[k] == v for k, v in PREDECESSOR_COUNTS.items())
            and all(type(leaf_counts[k]) is int and 0 < leaf_counts[k] <= 128 for k in NEW_LEAVES),
            "retained227 cases and bounded new reviewed rosters")
    total_tests = sum(leaf_counts.values())
    require(type(spec["total_tests"]) is int and spec["total_tests"] == total_tests,
            "sealed total test count")
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    priority = os.getpriority(os.PRIO_PROCESS, 0)
    require(priority in (0, 10), "unexpected nice level")
    if priority == 0:
        os.nice(10)
    for kind, cap in ((resource.RLIMIT_AS, 512 << 20), (resource.RLIMIT_FSIZE, 16 << 20),
                      (resource.RLIMIT_CORE, 0)):
        soft, hard = resource.getrlimit(kind)
        limit = min([cap] + [v for v in (soft, hard) if v != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (limit, limit))
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, "subreaper setup")
    supervisor_raw = read(ROOT / "supervisor.py", 1 << 20)
    require(compact(supervisor_raw)["sha256"] == SUPERVISOR_SHA, "frozen supervisor")
    h = types.ModuleType("layer_native_admission_owned")
    h.__file__ = str(ROOT / "supervisor.py")
    exec(compile(supervisor_raw, h.__file__, "exec"), h.__dict__)
    h.ROOT, h.OUT, h.TMP, h.TARGET = ROOT, OUT, TMP, ROOT / "target"
    h.AS_LIMIT, h.FILE_LIMIT, h.STREAM_LIMIT = 512 << 20, 16 << 20, 4 << 20
    h.CACHE_LIMIT, h.CPU_LIMIT, h.CLEANUP_RESERVE = 64 << 20, LEAF_SECONDS, CLEANUP_SECONDS
    require(h.shutil.disk_usage(ROOT).free >= h.START_FREE, "initial40GiB free floor")
    paths = {}
    directories = set()
    for name in spec["sources"]:
        parts = Path(name).parts
        require(parts and not Path(name).is_absolute() and all(p not in ("", ".", "..") for p in parts)
                and Path(name).as_posix() == name and parts[0] not in ("evidence", "tmp"),
                "closed source-relative name")
        paths[name] = ROOT / name
        directories.update((ROOT / name).parents)
    directories.discard(ROOT)
    directories = {p for p in directories if ROOT in p.parents}

    def sources():
        observed, seen_dirs = set(), set()
        for path in ROOT.rglob("*"):
            relative = path.relative_to(ROOT)
            if relative.parts[0] in ("evidence", "tmp"):
                continue
            require(path.resolve(strict=True) == path, "canonical input tree")
            mode = path.lstat().st_mode
            if stat.S_ISDIR(mode):
                seen_dirs.add(path)
            else:
                require(stat.S_ISREG(mode), "ordinary input body")
                observed.add(relative.as_posix())
        require(observed == set(paths) | {"input-manifest.json"}
                and seen_dirs == directories, "closed staged namespace")
        return {name: h.pin(paths[name]) for name in sorted(paths)}

    h.sources = sources
    before = sources()
    require(all({k: before[n][k] for k in ("bytes", "sha256")} == p
                for n, p in spec["sources"].items()), "exact staged source bytes")
    require(spec["source_files"] == len(before) and 364 < len(before) < 400
            and spec["original_fixture_files"] == 152
            and spec["fixture_copies"] == 2, "closed source and fixture census")
    expected_names = []
    for label, count in leaf_counts.items():
        leaf = spec["leaves"][label]
        directory = ROOT / leaf["directory"]
        require(leaf["directory"] == ("legacy" if label == "legacy-tests" else ".")
                and leaf["count"] == count, "private leaf namespace")
        names = sorted(n for module in leaf["modules"]
                       for n in test_names(directory / (module + ".py")))
        require(names == leaf["names"] and len(names) == len(set(names)) == count,
                "closed AST test roster")
        expected_names.extend(names)
    require(len(expected_names) == len(set(expected_names)) == total_tests, "disjoint named tests")
    python = Path("/usr/bin/python3").resolve(strict=True)
    prlimit = Path("/usr/bin/prlimit").resolve(strict=True)
    tools = dict(python=h.pin(python), prlimit=h.pin(prlimit))
    environment = dict(PATH="/usr/bin:/bin", HOME="/home/harmenon", LANG="C.UTF-8", LC_ALL="C.UTF-8",
        TZ="UTC", PYTHONPATH="", PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", TMPDIR=str(TMP),
        HIP_VISIBLE_DEVICES="", ROCR_VISIBLE_DEVICES="", CUDA_VISIBLE_DEVICES="", CARGO_BUILD_JOBS="2",
        OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    OUT.mkdir(mode=0o700)
    TMP.mkdir(mode=0o700)
    phases, errors, leaf_tests = [], [], {}
    failure = census = after = None
    handlers = {n: signal.getsignal(n) for n in SIGNALS}
    for number in handlers:
        signal.signal(number, interrupted)
    try:
        arm_deadline()
        h.save("sources-before.json", before)
        for label, count in leaf_counts.items():
            leaf = spec["leaves"][label]
            directory = ROOT / leaf["directory"]
            script = ("import sys,unittest;sys.path.insert(0," + repr(str(directory)) + ");"
                      "suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in "
                      + repr(leaf["modules"]) + ");"
                      "result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())")
            h.run(label, [str(python), "-I", "-B", "-c", script], environment, phases, deadline,
                  before, seconds=LEAF_SECONDS, cwd=directory)
            require(read(OUT / (label + ".stdout"), 4 << 20) == b"", "unexpected test stdout")
            stderr = read(OUT / (label + ".stderr"), 4 << 20).decode("utf-8")
            expression = r"^(test_[A-Za-z0-9_]+) \(([A-Za-z0-9_]+\.[A-Za-z0-9_]+)\.\1\) \.\.\. ok$"
            found = [prefix + "." + name for name, prefix in re.findall(expression, stderr, re.M)]
            require(sorted(found) == leaf["names"] and len(found) == len(set(found)) == count,
                    "exact named successes")
            tail = "\n".join(line for line in re.sub(expression, "", stderr, flags=re.M).splitlines() if line)
            require(re.fullmatch(r"-{70}\nRan " + str(count) + r" tests in [0-9]+\.[0-9]+s\nOK", tail),
                    "exact unittest summary without skips")
            leaf_tests[label] = dict(names=sorted(found), passed=count, failed=0, errors=0, skipped=0)
            require(not any(TMP.iterdir()), "all private test temporary files retired")
        census = dict(names=sorted(expected_names), passed=total_tests, failed=0, errors=0, skipped=0)
    except BaseException as error:
        failure = type(error).__name__ + ": " + str(error)
    finally:
        for number in handlers:
            signal.signal(number, interrupted if number == signal.SIGALRM else signal.SIG_IGN)
        arm_deadline()
        try:
            after = sources()
            require(after == before, "source or original fixture drift")
            h.save("sources-after.json", after)
            require(read(ROOT / "input-manifest.json", 1 << 20) == input_raw, "input manifest drift")
            require(Path("/usr/bin/python3").resolve(strict=True) == python
                    and Path("/usr/bin/prlimit").resolve(strict=True) == prlimit
                    and h.pin(python) == tools["python"] and h.pin(prlimit) == tools["prlimit"], "tool drift")
            require(not any(TMP.iterdir()), "private temporary files remain")
            require(len(phases) <= len(LEAF_ORDER) and all(row["reaped"] and row["process_group_absent"] for row in phases),
                    "all recorded children retired")
            require(time.monotonic() < deadline, "whole CPU bound")
        except BaseException as error:
            if time.monotonic() >= deadline:
                raise
            errors.append(type(error).__name__ + ": " + str(error))
    arm_deadline()
    raw = {p.name: h.pin(p) for p in sorted(OUT.iterdir()) if p.is_file()}
    try:
        require([row["label"] for row in phases] == list(LEAF_ORDER)[:len(phases)], "owned phase prefix")
        for row in phases:
            for key in ("command", "stdout", "stderr"):
                require(raw[Path(row[key]["path"]).name] == row[key], "final raw phase pin join")
            require(json.loads(read(OUT / (row["label"] + ".result.json"))) == row, "original result join")
            started = json.loads(read(OUT / (row["label"] + ".started.json")))
            require(started == dict(pid=row["pid"], pgid=row["pgid"], argv=row["argv"]), "child registration join")
        allowed = {"sources-before.json", "sources-after.json"} | {
            label + "." + suffix for label in LEAF_ORDER
            for suffix in ("command.json", "started.json", "result.json", "stdout", "stderr")}
        require(set(raw) <= allowed, "closed original raw prefix")
    except BaseException as error:
        if time.monotonic() >= deadline:
            raise
        errors.append("raw reconciliation: " + repr(error))
    failure = failure or ("postcheck failed" if errors else None)
    value = dict(schema="ferric-layer-native-admission-cpu-v1",
        passed=failure is None and census is not None, failure=failure, postcheck_errors=errors,
        input_manifest=dict(path=str(ROOT / "input-manifest.json"), **compact(input_raw)),
        controller=before["run_cpu.py"], supervisor=before["supervisor.py"],
        sources_before=before, sources_after=after, source_unchanged=after == before,
        tool_pins=tools, environment=environment, phases=phases, tests=census, leaf_tests=leaf_tests, raw=raw,
        limits=dict(whole_seconds=WHOLE_SECONDS, leaf_seconds={n: LEAF_SECONDS for n in LEAF_ORDER},
            cleanup_reserve_seconds=CLEANUP_SECONDS, address_space_bytes=512 << 20, file_bytes=16 << 20,
            stream_bytes=4 << 20, temporary_bytes=64 << 20, affinity=[8, 9], nice=10, cargo_jobs=2,
            initial_free_bytes=40 << 30, live_free_bytes=38 << 30),
        elapsed_seconds=time.monotonic() - start, inherited_tests=171, forward_cpu_tests=29,
        forward_retention_tests=12, forward_preparation_tests=15, original_fixture_files=152,
        layer_cpu_tests=leaf_counts["layer-cpu-tests"],
        layer_retention_tests=leaf_counts["layer-retention-tests"],
        layer_preparation_tests=leaf_counts["layer-preparation-tests"],
        synthetic_and_actual_artifact_backed_tests=True, synthetic_data_tests_only=False,
        actual_cpu_artifact_reads=True, model_shard_reads=False, gpu_execution=False,
        native_parent_execution=False, model_execution=False, numerical_acceptance=False,
        full_model_acceptance=False, performance_claim=False, production_authority=False)
    arm_deadline()
    h.save("complete.json" if value["passed"] else "failed.json", value)
    signal.setitimer(signal.ITIMER_REAL, 0)
    for number, handler in handlers.items():
        signal.signal(number, handler)
    print(json.dumps({k: value[k] for k in ("passed", "failure", "postcheck_errors", "tests")}, sort_keys=True))
    return 0 if value["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
