"""Real entrypoint tests using authenticated MI350 data, without native execution.

Only temporary deployment identities and process-global host effects are isolated.
The actual CPU contract, preparer reader, hashing, writes, and runner wrapper run
unchanged. These tests require the retained qualified artifacts on MI350.
"""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import patch

import layer_cpu_admission as A

HERE = Path(__file__).resolve().parent
ADMISSION_SHA = "b4011260a76746c60320f8d485783114c7c6b7507e307b187084759aa15a1ecd"
HISTORICAL = Path(A.E) / 'guarded-mlp-peer-read-pair-gpu-v228-v2/control-0-request.json'


def load(path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module


def pin(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


class LayerPreparationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='layer-preparation-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        for name in ('prepare_layer_model_inputs.py', 'layer_cpu_admission.py', 'run_layer_model_gpu.py'):
            body = (HERE / name).read_bytes()
            (self.root / name).write_bytes(body)
            self.assertEqual((self.root / name).read_bytes(), body)
        self.assertEqual(pin(self.root / 'layer_cpu_admission.py')['sha256'], ADMISSION_SHA)
        self.prep = load(self.root / 'prepare_layer_model_inputs.py', 'layer_preparation_under_test')
        self.prep.ROOT = self.root
        self.prep.CPU_ADMISSION_SHA = ADMISSION_SHA
        self.runner = load(self.root / 'run_layer_model_gpu.py', 'layer_runner_under_test')
        self.runner.CPU_ADMISSION_SHA = ADMISSION_SHA
        self.argv = [str(self.root / 'prepare_layer_model_inputs.py'),
                     A.PINS['parent_cpu']['path'], A.PINS['parent_cpu']['sha256'],
                     A.PINS['parent']['path'], str(HISTORICAL)]
        self.outputs = ['tail_layer-request.json', 'tail_layer-input.json', 'prepared-inputs.json']

    @contextlib.contextmanager
    def host(self, argv=None):
        # Do not lower the enclosing test process's limits or replace its handlers.
        # UID, hostname, nice, actual clocks and all data predicates remain real.
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.prep.sys, 'argv', list(self.argv if argv is None else argv)))
            stack.enter_context(patch.object(self.prep.os, 'umask', return_value=0o077))
            stack.enter_context(patch.object(self.prep.os, 'sched_setaffinity', return_value=None))
            stack.enter_context(patch.object(self.prep.os, 'nice', return_value=10))
            stack.enter_context(patch.object(self.prep.resource, 'setrlimit', return_value=None))
            stack.enter_context(patch.object(self.prep.signal, 'signal', return_value=None))
            stack.enter_context(patch.object(self.prep.signal, 'setitimer', return_value=(0.0, 0.0)))
            yield

    def prepare(self):
        stdout, stderr = io.StringIO(), io.StringIO()
        with self.host(), patch.object(self.prep, 'read', wraps=self.prep.read) as reads:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                self.assertEqual(self.prep.main(), 0)
        self.assertEqual(stderr.getvalue(), '')
        return json.loads(stdout.getvalue()), reads.call_args_list

    def assert_no_outputs(self):
        self.assertFalse(any((self.root / name).exists() for name in self.outputs))

    def audit(self):
        return types.SimpleNamespace(read=self.prep.read)

    def test_full_preparation_keeps_original_inputs_caps_and_closed_rehashed_readset(self):
        result, calls = self.prepare()
        receipt = json.loads((self.root / 'prepared-inputs.json').read_bytes())
        plan = json.loads((self.root / 'tail_layer-input.json').read_bytes())
        request = json.loads((self.root / 'tail_layer-request.json').read_bytes())
        old = json.loads(HISTORICAL.read_bytes())
        self.assertEqual(pin(HISTORICAL)['bytes'], 9338)
        self.assertEqual(pin(HISTORICAL)['sha256'],
                         '526f0c30630edb83114cfa763ffb98b9242154371250797b9ed55bf8747bed1d')
        self.assertEqual(receipt['schema'],
                         'ferric-guarded-mlp-readiness40-tail-layer-duration-input-preparation-v1')
        self.assertEqual(plan['schema'], 'ferric-guarded-mlp-readiness40-tail-layer-duration-gpu-input-v1')
        self.assertEqual(plan['case'], 'tail_layer')
        self.assertEqual(plan['profile'], 'readiness40_position5')
        self.assertEqual({key: plan[key] for key in A.PINS}, A.PINS)
        self.assertEqual(receipt['runtime_cpu'], A.PINS['runtime_cpu'])
        self.assertEqual(request['schema'], 'FerricGuardedMlpReadiness40Position5RequestV1')
        self.assertEqual(receipt['prompt_tokens'], 2048)
        self.assertEqual(receipt['prompt_positions_requested'], 40)
        self.assertEqual(receipt['generated_tokens_requested'], 0)
        self.assertEqual(receipt['capture_positions'], [0, 5, 16, 39])
        self.assertEqual(receipt['modes'], ['tail_layer'])
        self.assertEqual(receipt['currentness_policies'], {'tail_layer': 'bank_scoped_census_tail_layer'})
        for key in ('passed', 'data_only', 'instrumented', 'forward_phase_durations',
                    'disjoint_forward_phases', 'currentness_durations_nested', 'parent_host_timing_requested',
                    'layer_phase_durations', 'paired_mlp_durations_nested'):
            self.assertIs(receipt[key], True)
        for key in ('cpu_tests_executed', 'native_execution', 'gpu_execution', 'gpu_timing',
                    'numerical_acceptance', 'performance_claim', 'production_authority',
                    'full_long_workload', 'matched_speed_comparison', 'temporal_equivalent_to_full'):
            self.assertIs(receipt[key], False)
        base = request['base']
        session = base['session']
        self.assertEqual(len(session), 32)
        self.assertTrue(all(type(v) is int and 0 <= v <= 255 for v in session))
        self.assertNotEqual(session, [0] * 32)
        self.assertNotEqual(session, old['decode']['session'])
        self.assertEqual(receipt['sessions'], [session])
        expected = {key: value for key, value in old['decode'].items()
                    if key not in ('mode', 'prefix_image', 'tiles_image')}
        expected.update(schema='FerricFiniteLongRequestV1', worker=self.prep.rust(A.PINS['worker']),
                        session=session, evidence_directory=str(self.root / 'tail_layer/native'))
        self.assertEqual(base, expected)
        for name in self.prep.IMAGES:
            self.assertEqual(request[name], old[name] if name in old else old['decode'][name])
        self.assertEqual(base['device_ids'], [16366993098680759275, 10838076764495710945])
        self.assertEqual(base['dispatch_timeout_ms'], 10000)
        self.assertEqual(base['child_deadline_ms'], 3600000)
        counts = {}
        for call in calls:
            name = str(call.args[0])
            counts[name] = counts.get(name, 0) + 1
        self.assertEqual(set(receipt['readset']), set(self.prep.INPUTS) - {str(self.root / 'prepared-inputs.json')})
        self.assertLessEqual(len(self.prep.bytes_json(receipt)), 65536)
        self.assertFalse(any(name.startswith(base['source'].rstrip('/') + '/') for name in receipt['readset']))
        self.assertFalse(any('/registry/' in name for name in receipt['readset']))
        for name, expected_pin in receipt['readset'].items():
            self.assertGreaterEqual(counts[name], 2, name)
            self.assertEqual(pin(Path(name)), expected_pin)
        for name in self.outputs:
            self.assertLessEqual((self.root / name).stat().st_size, 65536)
        self.assertEqual(result['receipt'], pin(self.root / 'prepared-inputs.json'))
        self.assertEqual(result['requests']['tail_layer'], pin(self.root / 'tail_layer-request.json'))
        self.assertEqual(result['plans']['tail_layer'], pin(self.root / 'tail_layer-input.json'))
        self.assertFalse((self.root / 'tail_layer').exists())

    def test_real_runner_wrapper_admits_exact_prepared_eight_pins(self):
        self.prepare()
        plan = json.loads((self.root / 'tail_layer-input.json').read_bytes())
        before = dict(self.prep.INPUTS)
        actual = self.runner.cpu_admission(plan, self.audit())
        self.assertEqual(actual, A.PINS)
        self.assertTrue(set(before) <= set(self.prep.INPUTS))
        self.assertEqual(pin(self.root / 'layer_cpu_admission.py'),
                         self.prep.INPUTS[str(self.root / 'layer_cpu_admission.py')])

    def test_pending_helper_binding_refuses_both_wrappers(self):
        self.prep.CPU_ADMISSION_SHA = self.runner.CPU_ADMISSION_SHA = None
        with self.host(), self.assertRaisesRegex(RuntimeError, 'binding remains pending'):
            self.prep.main()
        with self.assertRaisesRegex(RuntimeError, 'binding remains pending'):
            self.runner.cpu_admission(copy.deepcopy(A.PINS), self.audit())
        self.assert_no_outputs()

    def test_stale_helper_hash_refuses_both_wrappers(self):
        self.prep.CPU_ADMISSION_SHA = self.runner.CPU_ADMISSION_SHA = '0' * 64
        with self.host(), self.assertRaisesRegex(RuntimeError, 'reviewed layer CPU admission source'):
            self.prep.main()
        with self.assertRaisesRegex(RuntimeError, 'reviewed layer CPU admission source'):
            self.runner.cpu_admission(copy.deepcopy(A.PINS), self.audit())
        self.assert_no_outputs()

    def test_changed_helper_bytes_refuse_before_admission_or_output(self):
        path = self.root / 'layer_cpu_admission.py'
        path.write_bytes(path.read_bytes() + b'\n# changed temporary source\n')
        with self.host(), self.assertRaisesRegex(RuntimeError, 'reviewed layer CPU admission source'):
            self.prep.main()
        with self.assertRaisesRegex(RuntimeError, 'reviewed layer CPU admission source'):
            self.runner.cpu_admission(copy.deepcopy(A.PINS), self.audit())
        self.assert_no_outputs()

    def test_wrong_supplied_parent_receipt_sha_refuses(self):
        argv = list(self.argv); argv[2] = '0' * 64
        with self.host(argv), self.assertRaisesRegex(RuntimeError, 'supplied actual layer parent'):
            self.prep.main()
        self.assert_no_outputs()

    def test_wrong_supplied_parent_elf_refuses(self):
        argv = list(self.argv); argv[3] = A.PINS['worker']['path']
        with self.host(argv), self.assertRaisesRegex(RuntimeError, 'supplied actual layer parent'):
            self.prep.main()
        self.assert_no_outputs()

    def test_default_parent_receipt_namespace_refuses(self):
        argv = list(self.argv); argv[1] = argv[1].replace('-diagnostic-', '-default-')
        with self.host(argv), self.assertRaisesRegex(RuntimeError, 'supplied actual layer parent'):
            self.prep.main()
        self.assert_no_outputs()

    def test_each_reused_output_or_native_namespace_refuses(self):
        for name in [*self.outputs, 'tail_layer']:
            path = self.root / name
            path.mkdir() if name == 'tail_layer' else path.write_bytes(b'preserved')
            try:
                with self.subTest(name=name), self.host(), self.assertRaisesRegex(RuntimeError, 'fresh one-shot'):
                    self.prep.main()
                if path.is_file():
                    self.assertEqual(path.read_bytes(), b'preserved')
            finally:
                path.rmdir() if path.is_dir() else path.unlink()

    def test_extra_argv_refuses_without_creating_outputs(self):
        with self.host(self.argv + ['extra']), self.assertRaisesRegex(RuntimeError, 'python3 -B'):
            self.prep.main()
        self.assert_no_outputs()

    def test_exact_generated_body_cap_is_not_relaxed(self):
        limit = self.root / 'limit.json'
        value = self.prep.write(limit, b'x' * 65536)
        self.assertEqual(value, pin(limit))
        too_large = self.root / 'too-large.json'
        with self.assertRaisesRegex(RuntimeError, 'bounded generated data body'):
            self.prep.write(too_large, b'x' * 65537)
        self.assertFalse(too_large.exists())

    def test_rehashed_historical_request_copy_cannot_change_original_authority(self):
        changed = self.root / 'changed-historical.json'
        changed.write_bytes(HISTORICAL.read_bytes() + b' ')
        argv = list(self.argv); argv[4] = str(changed)
        with self.host(argv), self.assertRaisesRegex(RuntimeError, 'qualified extent/hash'):
            self.prep.main()
        self.assert_no_outputs()

    def test_runner_rejects_default_or_mixed_plan_with_real_contract(self):
        plan = copy.deepcopy(A.PINS)
        plan['worker_cpu']['path'] = plan['worker_cpu']['path'].replace('-diagnostic-', '-default-')
        with self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
            self.runner.cpu_admission(plan, self.audit())
        plan = copy.deepcopy(A.PINS)
        plan['worker'], plan['parent'] = plan['parent'], plan['worker']
        with self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
            self.runner.cpu_admission(plan, self.audit())

    def test_runner_rejects_noncanonical_pin_without_reader_trust(self):
        plan = copy.deepcopy(A.PINS)
        plan['worker_sources']['bytes'] = True
        with self.assertRaisesRegex(RuntimeError, 'typed bounded pin'):
            self.runner.cpu_admission(plan, self.audit())

    def test_preparation_reread_detects_temporary_source_drift(self):
        real_read = self.prep.read
        changed = False
        target = self.root / 'layer_cpu_admission.py'
        def drift_after_original_read(path, *args, **kwargs):
            nonlocal changed
            result = real_read(path, *args, **kwargs)
            if Path(path) == target and not changed:
                changed = True
                target.write_bytes(target.read_bytes() + b'\n# fault after authenticated read\n')
            return result
        with self.host(), patch.object(self.prep, 'read', side_effect=drift_after_original_read):
            with self.assertRaisesRegex(RuntimeError, 'exact data input pin'):
                self.prep.main()
        self.assertTrue(changed)
        self.assert_no_outputs()


    def test_real_preparation_retains_runtime_receipt_map_and_source_predecessor(self):
        self.prepare()
        receipt = json.loads((self.root / 'prepared-inputs.json').read_bytes())
        for expected in (A.PINS['runtime_cpu'], A.PINS['runtime_sources'], A.SOURCE_PREDECESSOR):
            self.assertEqual(receipt['readset'][expected['path']], expected)
        self.assertEqual(receipt['runtime_cpu'], A.PINS['runtime_cpu'])
        self.assertLessEqual(len(self.prep.bytes_json(receipt)), 65536)

    def test_runner_refuses_omitted_or_default_runtime_admission(self):
        for key in ('runtime_cpu', 'runtime_sources'):
            plan = copy.deepcopy(A.PINS)
            del plan[key]
            with self.subTest(key=key), self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
                self.runner.cpu_admission(plan, self.audit())
        plan = copy.deepcopy(A.PINS)
        plan['runtime_cpu']['path'] = plan['runtime_cpu']['path'].replace('-diagnostic-', '-default-')
        with self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
            self.runner.cpu_admission(plan, self.audit())

    def test_runner_refuses_runtime_worker_receipt_swap(self):
        plan = copy.deepcopy(A.PINS)
        plan['runtime_cpu'], plan['worker_cpu'] = plan['worker_cpu'], plan['runtime_cpu']
        with self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
            self.runner.cpu_admission(plan, self.audit())


if __name__ == '__main__':
    unittest.main(verbosity=2)


