"""Actual-artifact-backed data mutations, not portable synthetic qualification.

The first fixture load authenticates the fixed MI350 JSON/source/ELF originals.
Each test uses isolated in-memory bytes and explicitly rebound fixture pins;
production predicates remain intact. No ELF, project helper, or child is run.
"""
import copy
import hashlib
import json
import stat
import unittest
from pathlib import Path
from unittest.mock import patch

import layer_cpu_admission as A


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def pinned(path, raw):
    return dict(path=path, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


class LayerCpuAdmissionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.originals = {}
        def original_read(path, expected=None, limit=16 << 20, retain=True):
            path = Path(path)
            before = path.lstat()
            if (path.resolve(strict=True) != path or not stat.S_ISREG(before.st_mode)
                    or before.st_size > limit or retain is not True):
                raise RuntimeError('bounded canonical fixture')
            raw = path.read_bytes()
            after = path.lstat()
            stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
            if stamp(before) != stamp(after):
                raise RuntimeError('fixture changed while read')
            actual = pinned(str(path), raw)
            if expected != actual:
                raise RuntimeError('fixed original fixture pin')
            cls.originals[str(path)] = raw
            return raw, actual
        A.admit(copy.deepcopy(A.PINS), original_read)

    def setUp(self):
        # Bytes are immutable and shared; only the one mutated JSON body is rebuilt.
        self.bodies = dict(self.originals)
        self.pins = copy.deepcopy(A.PINS)
        self.fixed = copy.deepcopy(A.FIXED)
        self.calls = []

    def read(self, path, expected=None, limit=16 << 20, retain=True):
        name = str(path)
        self.calls.append(name)
        raw = self.bodies[name]
        if len(raw) > limit or retain is not True:
            raise RuntimeError('fixture read cap')
        return raw, pinned(name, raw)

    def object(self, role, name=None):
        p = self.pins[role + '_cpu'] if name is None else self.fixed[role][name]
        return json.loads(self.bodies[p['path']])

    def replace(self, path, value):
        raw = encoded(value)
        self.bodies[path] = raw
        return pinned(path, raw)

    def receipt(self, role, value):
        self.pins[role + '_cpu'] = self.replace(self.pins[role + '_cpu']['path'], value)

    def run_admit(self, reader=None, plan=None):
        with patch.object(A, 'PINS', self.pins), patch.object(A, 'FIXED', self.fixed):
            return A.admit(copy.deepcopy(self.pins) if plan is None else plan, reader or self.read)

    def refuse_receipt(self, role, mutate):
        value = self.object(role)
        mutate(value)
        self.receipt(role, value)
        with self.assertRaises((RuntimeError, KeyError, TypeError, ValueError)):
            self.run_admit()

    def test_actual_triple_returns_cpu_only_originals_and_bounded_readset(self):
        runtime, worker, parent = self.run_admit()
        self.assertEqual(runtime['tests']['kfd-tests']['passed'], 1209)
        self.assertEqual(worker['tests']['worker-tests']['passed'], 911)
        self.assertEqual(sum(v['passed'] for v in parent['tests'].values()), 641)
        self.assertEqual(len(set(self.calls)), 39)
        self.assertLess(len(encoded({p: pinned(p, self.bodies[p]) for p in set(self.calls)})), 24576)
        for row in (runtime, worker, parent):
            for key in A.FALSE_FLAGS:
                self.assertIs(row[key], False)
        self.assertIs(runtime['runtime_tests_repeated'], True)
        self.assertIs(worker['runtime_tests_repeated'], False)
        self.assertIs(parent['runtime_tests_repeated'], False)
        self.assertFalse(any('/registry/' in p or '/ferric/' in p or '/fe2o3/' in p for p in self.calls))

    def test_default_worker_mode_refuses(self):
        self.refuse_receipt('worker', lambda t: t.update(mode='default'))

    def test_default_parent_mode_refuses(self):
        self.refuse_receipt('parent', lambda t: t.update(mode='default'))

    def test_mixed_roles_refuse(self):
        self.refuse_receipt('parent', lambda t: t.update(role='worker'))

    def test_old_schema_cannot_impersonate_new_qualification(self):
        self.refuse_receipt('worker', lambda t: t.update(schema='ferric-guarded-mlp-currentness-duration-cpu-v1'))

    def test_missing_plan_pin_and_extra_pin_fields_refuse(self):
        plan = copy.deepcopy(self.pins)
        del plan['parent_sources']
        with self.assertRaises(RuntimeError):
            self.run_admit(plan=plan)
        plan = copy.deepcopy(self.pins)
        plan['worker']['authority'] = True
        with self.assertRaises(RuntimeError):
            self.run_admit(plan=plan)

    def test_bool_extent_uppercase_digest_and_noncanonical_path_refuse(self):
        for field, wrong in (('bytes', True), ('sha256', 'A' * 64),
                             ('path', A.ROOTS['worker'] + '/target/../target/debug/x')):
            plan = copy.deepcopy(self.pins)
            plan['worker'][field] = wrong
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                self.run_admit(plan=plan)

    def test_reader_cannot_lie_about_bytes_or_returned_pin(self):
        def bad_bytes(path, expected=None, **kwargs):
            raw, pin = self.read(path, expected, **kwargs)
            return raw + b' ', pin
        with self.assertRaisesRegex(RuntimeError, 'independent raw byte pin'):
            self.run_admit(reader=bad_bytes)
        def bad_pin(path, expected=None, **kwargs):
            raw, pin = self.read(path, expected, **kwargs)
            return raw, dict(pin, sha256='0' * 64)
        with self.assertRaisesRegex(RuntimeError, 'independent raw byte pin'):
            self.run_admit(reader=bad_pin)

    def test_failed_or_postcheck_dirty_receipt_refuses(self):
        for key, value in (('passed', False), ('failure', 'late failure'), ('postcheck_errors', ['drift'])):
            with self.subTest(key=key):
                self.setUp()
                self.refuse_receipt('worker', lambda t: t.update({key: value}))

    def test_every_authority_runtime_or_policy_flag_refuses(self):
        for key in A.FALSE_FLAGS:
            with self.subTest(key=key):
                self.setUp()
                self.refuse_receipt('parent', lambda t: t.update({key: True}))

    def test_source_unchanged_boolean_is_not_sufficient(self):
        def mutate(t):
            name = next(iter(t['input_sources']))
            t['input_sources'][name]['sha256'] = '0' * 64
        self.refuse_receipt('worker', mutate)

    def test_rehashed_final_map_drift_refuses_sealed_input(self):
        role = 'worker'
        t = self.object(role)
        map_path = self.pins[role + '_sources']['path']
        sources = json.loads(self.bodies[map_path])
        sources['fe2o3/Cargo.lock']['sha256'] = '0' * 64
        self.pins[role + '_sources'] = self.replace(map_path, sources)
        t['input_sources'] = t['final_sources'] = sources
        self.receipt(role, t)
        with self.assertRaisesRegex(RuntimeError, 'sealed input'):
            self.run_admit()

    def test_input_predecessor_root_and_role_refuse(self):
        for field, value in (('predecessor_root', A.OLD_ROOTS['worker']), ('role', 'worker')):
            self.setUp()
            role = 'parent'
            t, inputs = self.object(role), self.object(role, 'input-manifest.json')
            inputs[field] = value
            new = self.replace(self.fixed[role]['input-manifest.json']['path'], inputs)
            self.fixed[role]['input-manifest.json'] = new
            t['input_manifest'] = new
            self.receipt(role, t)
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                self.run_admit()

    def test_predecessor_pin_substitution_refuses(self):
        self.refuse_receipt('worker', lambda t: t.update(predecessor=dict(bytes=1, sha256='0' * 64)))

    def test_controller_binding_uses_actual_source_map(self):
        self.fixed['worker']['run_cpu.py']['sha256'] = '0' * 64
        with self.assertRaisesRegex(RuntimeError, 'controller/helper'):
            self.run_admit()

    def test_raw_phase_pin_drift_refuses(self):
        def mutate(t):
            t['raw']['worker-tests.stdout']['sha256'] = '0' * 64
        self.refuse_receipt('worker', mutate)

    def test_each_retirement_failure_refuses(self):
        for key, value in (('exit_code', 1), ('exit_code', False), ('natural_exit', False),
                           ('reaped', False), ('process_group_absent', False),
                           ('timed_out', True), ('forced_cleanup', True),
                           ('observed_signals', [15]), ('adopted_reaped', [123]),
                           ('exception', 'failure'), ('storage_failure', 'floor')):
            with self.subTest(key=key, value=value):
                self.setUp()
                self.refuse_receipt('worker', lambda t: t['phases'][3].update({key: value}))

    def test_omitted_or_reordered_phase_refuses(self):
        self.refuse_receipt('worker', lambda t: t['phases'].pop())
        self.setUp()
        self.refuse_receipt('worker', lambda t: t['phases'].reverse())

    def test_changed_recipe_or_resource_bounds_refuse(self):
        self.refuse_receipt('worker', lambda t: t['phases'][2]['argv'].append('--no-default-features'))
        self.setUp()
        self.refuse_receipt('parent', lambda t: t['limits'].update(whole_seconds=4000))

    def test_preserved_old_names_and_new_names_are_both_required(self):
        for name_kind in ('old', 'new'):
            self.setUp()
            def mutate(t):
                names = t['tests']['worker-tests']['named']
                index = next(i for i, row in enumerate(names)
                             if ('forward_duration_' in row['name']) == (name_kind == 'new'))
                names[index]['name'] += '_forged'
            with self.subTest(name_kind=name_kind):
                self.refuse_receipt('worker', mutate)

    def test_ignored_tests_cannot_be_reclassified(self):
        def mutate(t):
            row = next(r for r in t['tests']['worker-tests']['named'] if r['outcome'] == 'ignored')
            row['outcome'] = 'ok'
            t['tests']['worker-tests']['ignored'] -= 1
            t['tests']['worker-tests']['passed'] += 1
        self.refuse_receipt('worker', mutate)

    def test_count_bool_or_inventory_omission_refuses(self):
        self.refuse_receipt('worker', lambda t: t['tests']['worker-tests'].update(passed=True))
        self.setUp()
        self.refuse_receipt('parent', lambda t: t['inventories'].pop())

    def test_missing_parent_new_scope_refuses(self):
        self.refuse_receipt('parent', lambda t: t['tests'].pop('parent-forward-phase-policy'))

    def test_each_product_feature_target_and_profile_drift_refuses(self):
        for field, value in (('features', []), ('manifest_path', '/tmp/Cargo.toml'),
                              ('target', {}), ('profile', {'test': True})):
            self.setUp()
            with self.subTest(field=field):
                self.refuse_receipt('worker', lambda t: t['artifacts']['worker']['cargo_artifact'].update({field: value}))

    def test_missing_product_or_replaced_cli_refuses(self):
        self.refuse_receipt('worker', lambda t: t['artifacts'].pop('worker-wire-test'))
        self.setUp()
        self.refuse_receipt('worker', lambda t: t.update(cli_executable_unchanged_across_tests=False))

    def test_selected_executable_bytes_and_magic_are_authenticated(self):
        path = self.pins['worker']['path']
        self.bodies[path] = b'NOPE' + self.bodies[path][4:]
        with self.assertRaisesRegex(RuntimeError, 'independent raw byte pin'):
            self.run_admit()
        for start, wrong in ((4, b'\x01'), (5, b'\x02'), (18, b'\x00\x00')):
            self.setUp()
            path = self.pins['worker']['path']
            raw = bytearray(self.bodies[path])
            raw[start:start + len(wrong)] = wrong
            self.bodies[path] = bytes(raw)
            changed = pinned(path, self.bodies[path])
            self.pins['worker'] = changed
            receipt = self.object('worker')
            receipt['artifacts']['worker']['pin'] = changed
            receipt['cli_executable_before_tests'] = changed
            self.receipt('worker', receipt)
            with self.subTest(start=start), self.assertRaisesRegex(RuntimeError, 'ELF64'):
                self.run_admit()

    def test_duplicate_json_and_missing_receipt_field_refuse(self):
        path = self.pins['worker_cpu']['path']
        raw = self.bodies[path].lstrip()
        self.bodies[path] = b'{"mode":"default",' + raw[1:]
        self.pins['worker_cpu'] = pinned(path, self.bodies[path])
        with self.assertRaisesRegex(RuntimeError, 'duplicate JSON'):
            self.run_admit()
        self.setUp()
        self.refuse_receipt('worker', lambda t: t.pop('mode'))

    def test_metadata_features_rechecked_beyond_terminal_claims(self):
        role = 'worker'
        t = self.object(role)
        path = t['raw']['metadata.stdout']['path']
        meta = json.loads(self.bodies[path])
        package = next(p for p in meta['packages'] if p['manifest_path'] == A.ROOTS[role] + '/' + A.WP + 'Cargo.toml')
        node = next(n for n in meta['resolve']['nodes'] if n['id'] == package['id'])
        node['features'] = []
        new = self.replace(path, meta)
        t['raw']['metadata.stdout'] = new
        next(p for p in t['phases'] if p['label'] == 'metadata')['stdout'] = new
        self.receipt(role, t)
        with self.assertRaisesRegex(RuntimeError, 'resolved Cargo graph'):
            self.run_admit()

    def test_actual_metadata_command_cannot_enable_gpu_or_change_request(self):
        for field, value in (('HIP_VISIBLE_DEVICES', '0'), ('CARGO_PROFILE_DEV_OPT_LEVEL', '0')):
            self.setUp()
            role = 'worker'
            t = self.object(role)
            path = t['raw']['metadata.command.json']['path']
            command = json.loads(self.bodies[path])
            command['env'][field] = value
            new = self.replace(path, command)
            t['raw']['metadata.command.json'] = new
            next(p for p in t['phases'] if p['label'] == 'metadata')['command'] = new
            self.receipt(role, t)
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                self.run_admit()


    def test_default_runtime_mode_refuses(self):
        self.refuse_receipt('runtime', lambda t: t.update(mode='default'))

    def test_missing_runtime_plan_receipt_and_source_pin_refuse(self):
        for key in ('runtime_cpu', 'runtime_sources'):
            plan = copy.deepcopy(self.pins)
            del plan[key]
            with self.subTest(key=key), self.assertRaises(RuntimeError):
                self.run_admit(plan=plan)

    def test_runtime_requalification_and_source_change_must_be_explicit(self):
        for key in ('runtime_tests_repeated', 'runtime_source_changed'):
            self.setUp()
            with self.subTest(key=key):
                self.refuse_receipt('runtime', lambda t: t.update({key: False}))

    def test_worker_and_parent_cannot_claim_runtime_test_execution(self):
        for role in ('worker', 'parent'):
            self.setUp()
            with self.subTest(role=role):
                self.refuse_receipt(role, lambda t: t.update(runtime_tests_repeated=True))

    def test_old_forward_schema_refuses_each_role(self):
        for role in ('runtime', 'worker', 'parent'):
            self.setUp()
            with self.subTest(role=role):
                self.refuse_receipt(role, lambda t: t.update(schema='ferric-readiness40-forward-phases-cpu-v1'))

    def test_runtime_retirement_failure_and_omitted_focus_refuse(self):
        self.refuse_receipt('runtime', lambda t: t['phases'][7].update(reaped=False))
        self.setUp()
        self.refuse_receipt('runtime', lambda t: t['phases'].pop())

    def test_runtime_primary_old_new_and_ignored_statuses_are_required(self):
        for kind in ('old', 'new', 'ignored'):
            self.setUp()
            def mutate(t):
                rows = t['tests']['kfd-tests']['named']
                if kind == 'ignored':
                    row = next(r for r in rows if r['outcome'] == 'ignored')
                else:
                    additions = self.object('runtime', 'proposal.json')['new_tests']['runtime']['diagnostic']
                    row = next(r for r in rows if (r['name'] in additions) == (kind == 'new'))
                row['name'] += '_forged'
            with self.subTest(kind=kind):
                self.refuse_receipt('runtime', mutate)

    def test_runtime_focused_and_doc_scopes_remain_required(self):
        self.refuse_receipt('runtime', lambda t: t['tests'].pop('scoped-layer-tests'))
        self.setUp()
        self.refuse_receipt('runtime', lambda t: t['tests']['interface-doc-tests'].update(passed=9))

    def test_runtime_target_features_and_missing_product_refuse(self):
        self.refuse_receipt('runtime', lambda t: t['artifacts']['kfd-lib']['cargo_artifact'].update(features=[]))
        self.setUp()
        self.refuse_receipt('runtime', lambda t: t['artifacts'].pop('kfd-lib'))

    def test_runtime_metadata_features_are_rechecked(self):
        role = 'runtime'
        t = self.object(role)
        path = t['raw']['runtime-metadata.stdout']['path']
        meta = json.loads(self.bodies[path])
        package = next(p for p in meta['packages'] if p['manifest_path'] ==
                       A.ROOTS[role] + '/fe2o3/crates/fe2o3-kfd/Cargo.toml')
        next(n for n in meta['resolve']['nodes'] if n['id'] == package['id'])['features'] = []
        new = self.replace(path, meta)
        t['raw']['runtime-metadata.stdout'] = new
        next(p for p in t['phases'] if p['label'] == 'runtime-metadata')['stdout'] = new
        self.receipt(role, t)
        with self.assertRaisesRegex(RuntimeError, 'resolved Cargo graph'):
            self.run_admit()

    def test_runtime_requested_features_match_exact_workspace_command(self):
        role = 'runtime'
        value = self.object(role)
        previous = self.object(role, 'inputs/base-complete.json')
        path = value['raw']['runtime-metadata.command.json']['path']
        original = json.loads(self.bodies[path])
        index = original['argv'].index('--features') + 1
        expected = 'fe2o3-kfd/' + A.FEATURE + ',fe2o3-kfd/engineering-gfx950'
        self.assertEqual(original['argv'][index], expected)
        A.metadata(self.read, value, previous, role)
        for requested in (A.FEATURE + ',engineering-gfx950',
                          'fe2o3-kfd/' + A.FEATURE + ',engineering-gfx950',
                          'other/' + A.FEATURE + ',fe2o3-kfd/engineering-gfx950'):
            command = copy.deepcopy(original)
            command['argv'][index] = requested
            value['raw']['runtime-metadata.command.json'] = self.replace(path, command)
            phase = next(p for p in value['phases'] if p['label'] == 'runtime-metadata')
            phase['argv'] = command['argv']
            phase['command'] = value['raw']['runtime-metadata.command.json']
            with self.subTest(requested=requested), self.assertRaisesRegex(
                    RuntimeError, 'original requested features and offline metadata command'):
                A.metadata(self.read, value, previous, role)

    def test_runtime_map_cannot_be_substituted_by_worker_map(self):
        plan = copy.deepcopy(self.pins)
        plan['runtime_sources'] = plan['worker_sources']
        with self.assertRaisesRegex(RuntimeError, 'fixed observed plan pin'):
            self.run_admit(plan=plan)

    def test_source_predecessor_original_bytes_cannot_drift(self):
        path = A.SOURCE_PREDECESSOR['path']
        self.bodies[path] += b' '
        with self.assertRaisesRegex(RuntimeError, 'independent raw byte pin'):
            self.run_admit()

    def test_parent_layer_codec_scope_is_mandatory(self):
        self.refuse_receipt('parent', lambda t: t['tests'].pop('parent-layer-phase-policy'))


if __name__ == '__main__':
    unittest.main(verbosity=2)

