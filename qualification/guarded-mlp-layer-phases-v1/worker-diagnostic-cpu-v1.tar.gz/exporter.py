"""Export closed original layer-stage CPU receipts; never execute or archive ELFs/cache."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import sys
import tarfile

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
AUTHOR = E / 'guarded-mlp-layer-phases-source-v228-v2'
PROPOSAL = dict(bytes=440584, sha256='937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f')
OLD_PROPOSAL = dict(bytes=441990, sha256='4ef4acd29a254a6b07c069b29eaa17ff21ab1ad28979f9f81c7688136f370823')
CONTROLLER = dict(bytes=32526, sha256='6735ed9c959704e58e18c26d86d7a7cb8e33c2654a93a8a5220c6187c316f770')
HELPERS = {
    'supervisor.py': dict(bytes=41485, sha256='8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc'),
    'worker_support.py': dict(bytes=41316, sha256='4d12ba86c4014adaaea1c5c49c3790dffcca78af8326ae09cb085840347a518a'),
}
FAILURES = {
    'v1': dict(bytes=3003633, sha256='89a95768d36e4dac9fcd61335ba10cd10b0671c4d53584290b4b0ad1c42567d1'),
    'v2': dict(bytes=3003608, sha256='4434ce2f285cd548b5ed16be7261c005657429784b46e22dc129ec87ae7a0a69'),
}
FAILED_CONTROLLERS = {
    'v1': dict(bytes=31983, sha256='d7882f1c1fc67bf11eb7cf02ab3c19cea7f399f6657693ff599f06daad90d5e5'),
    'v2': dict(bytes=31983, sha256='291a19d8f80dedb22fc8c5315ffecb5eec2f182d010528e355e6231dc299e8b5'),
}
PREFIX = ['/usr/bin/prlimit', '--as=12884901888', '--cpu=1200', '--fsize=1073741824', '--core=0', '--']
BODY_CAP = 64 << 20
READS = {}
LINKS = {}


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def compact(value):
    require(type(value) is dict and type(value.get('bytes')) is int and value['bytes'] >= 0
            and type(value.get('sha256')) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']),
            'canonical byte pin')
    return {k: value[k] for k in ('bytes', 'sha256')}


def stamp(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def read(path, expected=None, retain=True):
    path = Path(path)
    before = path.lstat()
    require(path.is_absolute() and path.resolve(strict=True) == path
            and stat.S_ISREG(before.st_mode) and before.st_size <= (BODY_CAP if retain else 512 << 20),
            'bounded canonical regular input')
    digest, chunks, count = hashlib.sha256(), [], 0
    with path.open('rb') as stream:
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'same opened input')
        while True:
            raw = stream.read(1 << 20)
            if not raw:
                break
            count += len(raw)
            require(count <= before.st_size, 'bounded input growth')
            digest.update(raw)
            if retain:
                chunks.append(raw)
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'opened input unchanged')
    require(stamp(before) == stamp(path.lstat()) and count == before.st_size, 'input unchanged')
    actual = dict(bytes=count, sha256=digest.hexdigest())
    if expected is not None:
        require(actual == compact(expected) and ('path' not in expected or expected['path'] == str(path)),
                'original input pin: ' + str(path))
    require(str(path) not in READS or READS[str(path)] == actual, 'readset identity drift')
    READS[str(path)] = actual
    return b''.join(chunks) if retain else actual


def tool(path, expected):
    path = Path(path)
    if not path.is_symlink():
        return read(path, expected, retain=False)
    before = path.lstat()
    target = os.readlink(path)
    require(path.name == 'libLLVM-22-rust-1.96.0-nightly.so'
            and target == 'libLLVM.so.22.1-rust-1.96.0-nightly'
            and path.parent.resolve(strict=True) == path.parent
            and path.resolve(strict=True) == path.parent / target
            and pin(target.encode()) == compact(expected)
            and stamp(before) == stamp(path.lstat()), 'only original toolchain link identity')
    require(str(path) not in LINKS or LINKS[str(path)] == expected, 'tool link drift')
    LINKS[str(path)] = expected


def statuses(value):
    rows = value['named']
    out = {}
    for row in rows:
        require(type(row) is dict and set(row) == {'name', 'outcome'}
                and type(row['name']) is str and row['name'] not in out
                and row['outcome'] in ('ok', 'ignored'), 'unique actual named status')
        out[row['name']] = row['outcome']
    require(value['failed'] == 0 and value['passed'] == sum(v == 'ok' for v in out.values())
            and value['ignored'] == sum(v == 'ignored' for v in out.values()), 'named status totals')
    return out


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 5,
            'python3 -B export_cpu.py ROLE MODE ATTEMPT OBSERVED_TERMINAL_SHA256')
    require(os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03',
            'exact unprivileged host')
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10
            and all(os.environ.get(k) == '' for k in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES')),
            'CPU8,9 nice10 hidden GPUs')
    require(shutil.disk_usage(E).free >= 40 << 30, 'initial40GiB floor')
    resource.setrlimit(resource.RLIMIT_AS, (512 << 20, 512 << 20))
    resource.setrlimit(resource.RLIMIT_FSIZE, (128 << 20, 128 << 20))
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    signal.alarm(180)
    role, mode, attempt, digest = sys.argv[1:]
    require(role in ('runtime', 'worker', 'parent') and mode in ('default', 'diagnostic')
            and re.fullmatch('[0-9a-f]{64}', digest), 'closed role/mode and observed terminal hash')
    failed = role == 'runtime' and mode == 'diagnostic' and attempt in FAILURES
    require(failed or attempt == ('v3' if role == 'runtime' and mode == 'diagnostic' else 'v1'),
            'only original failed attempts or fresh qualification roots')
    root = E / ('guarded-mlp-layer-phases-' + role + '-' + mode + '-cpu-v228-' + attempt)
    require(root.resolve(strict=True) == root, 'exact original root')
    terminal = 'failed.json' if failed else 'complete.json'
    require(not (root / 'evidence' / ('complete.json' if failed else 'failed.json')).exists(),
            'one original terminal')
    raw = read(root / 'evidence' / terminal, FAILURES[attempt] if failed else None)
    require(pin(raw)['sha256'] == digest, 'observed original terminal bytes')
    result = json.loads(raw)
    require(result['schema'] == 'ferric-readiness40-layer-phases-cpu-v1'
            and result['role'] == role and result['mode'] == mode
            and result['passed'] is (not failed) and result['postcheck_errors'] == []
            and result['source_unchanged'] is True and result['input_sources'] == result['final_sources']
            and result['runtime_source_changed'] is True and result['runtime_tests_repeated'] is (role == 'runtime')
            and all(result[k] is False for k in ('currentness_policy_changed', 'full2303_deadline_changed',
                'gpu_execution', 'native_admission', 'numerical_acceptance', 'performance_claim')),
            'honest exact CPU-only outcome')
    require(result['limits'] == dict(whole_seconds=3600, cleanup_reserve_seconds=50,
            leaf_seconds=1200 if role == 'parent' else 1800, affinity=[8, 9], nice=10,
            cargo_jobs=2, gpu_hidden=True, initial_free_bytes=40 << 30, live_free_bytes=38 << 30,
            address_space_bytes=12 << 30, cpu_seconds=1200, scratch_bytes=6 << 30,
            stream_bytes=64 << 20), 'original qualification bounds unchanged')
    expected_proposal = OLD_PROPOSAL if failed and attempt == 'v1' else PROPOSAL
    proposal_raw = read(root / 'proposal.json', expected_proposal)
    proposal = json.loads(proposal_raw)
    require(result['proposal'] == expected_proposal and len(proposal['files']) == 2138
            and len(proposal['overlay']) == 30, 'fixed cumulative source proposal')
    require(sum(n.startswith('fe2o3/') for n in proposal['files']) == 833
            and sum(n.startswith('ferric/adapters/tp-peer-finite-engineering-worker-v1/')
                    for n in proposal['files']) == 242, 'exact runtime and worker source census')
    inputs = json.loads(read(root / 'input-manifest.json', result['input_manifest']))
    require(inputs['schema'] == 'ferric-layer-phases-cpu-input-v1'
            and (inputs['role'], inputs['mode'], inputs['attempt'], inputs['root'])
                == (role, mode, attempt, str(root)) and inputs['proposal'] == expected_proposal,
            'exact original input')
    sources = result['final_sources']
    require(len(sources) == 2141 and set(sources) == set(proposal['files']) | {'run_cpu.py', *HELPERS},
            'closed 2138 project and3 helper sources')
    require(inputs['files'] == {n: compact(v) for n, v in sources.items()}, 'input/final source join')
    expected_sources = proposal['files'] | HELPERS | {
        'run_cpu.py': FAILED_CONTROLLERS[attempt] if failed else CONTROLLER}
    for name, row in sources.items():
        require(Path(name).as_posix() == name and not name.startswith('/') and '..' not in Path(name).parts
                and row['path'] == str(root / name), 'source-relative original identity')
        read(root / name, row, retain=False)
        require(compact(row) == expected_sources[name], 'qualified source/helper closure')
    require(inputs['tool_pins'] == result['tool_pins'], 'original tool pins')
    previous = json.loads(read(root / 'inputs/base-complete.json', inputs['predecessor']))
    require(previous['passed'] is True and result['predecessor'] == inputs['predecessor'], 'qualified predecessor')
    read(root / 'base-manifest.json', proposal['base_manifest'])
    read(root / 'cargo-cache-manifest.json', inputs['cache_manifest'])
    worker_labels = {'rustc-version', 'metadata', 'worker-tests-build', 'worker-list', 'worker-ignored', 'worker-tests', 'worker-build'}
    recipes = [p for p in previous['phases'] if (
        p['label'] in worker_labels if role == 'worker' else
        p['label'] not in (worker_labels - {'rustc-version'}) | {'rustfmt', 'rustfmt-check'} if role == 'runtime'
        else p['label'] not in ('rustfmt', 'rustfmt-check'))]
    labels = ['rustfmt-check'] + [p['label'] for p in recipes]
    if role == 'parent' and mode == 'diagnostic':
        labels += ['parent-forward-phase-policy', 'parent-layer-phase-policy']
    phases = result['phases']
    require([p['label'] for p in phases] == (labels[:8] if failed else labels), 'exact natural phase prefix/order')
    for index, phase in enumerate(phases):
        wanted_exit = 101 if failed and attempt == 'v1' and index == 7 else 0
        require(phase['exit_code'] == wanted_exit and phase['natural_exit'] is True
                and phase['reaped'] is True and phase['process_group_absent'] is True
                and phase['timed_out'] is False and phase['forced_cleanup'] is False
                and phase['observed_signals'] == [] and phase['adopted_reaped'] == []
                and phase['exception'] is None and phase['storage_failure'] is None
                and phase['pid'] > 0 and phase['pid'] == phase['pgid'], 'retired owned original phase')
        command = json.loads(read(Path(phase['command']['path']), phase['command']))
        require(command['argv'] == phase['argv'] and phase['argv'][:6] == PREFIX, 'original bounded command')
        for key, suffix in (('command', 'command.json'), ('stdout', 'stdout'), ('stderr', 'stderr')):
            name = phase['label'] + '.' + suffix
            require(phase[key] == result['raw'][name], 'phase/raw identity')
    if failed:
        require(result['tests'] == {} and result['failure'] == (
            "RuntimeError('kfd-tests did not finish naturally/reaped/successfully')" if attempt == 'v1'
            else "RuntimeError('malformed worker libtest result')"), 'original failure, never successful qualification')
    else:
        require(result['failure'] is None, 'successful original terminal')
        additions = set(proposal['new_tests'][role][mode])
        test_labels = {p['label'] for p in recipes if p['label'] in previous['tests']}
        if role == 'parent' and mode == 'diagnostic':
            test_labels |= {'parent-forward-phase-policy', 'parent-layer-phase-policy'}
        require(set(result['tests']) == test_labels, 'all original and new test scopes')
        phase_by_label = {p['label']: p for p in phases}
        selected = set()
        for label in test_labels:
            current = result['tests'][label]
            if label == 'interface-doc-tests':
                require(current == previous['tests'][label], 'unchanged selected doc outcomes')
                continue
            argv = phase_by_label[label]['argv']
            selector = argv[argv.index('--lib') + 1] if '--lib' in argv else None
            added = additions if label in ('kfd-tests', 'worker-tests') else {
                name for name in additions if selector is not None
                and (name == selector or ('--exact' not in argv and selector in name))}
            selected |= added
            old = statuses(previous['tests'][label]) if label in previous['tests'] else {}
            require(not set(old) & added and statuses(current) == old | {n: 'ok' for n in added},
                    'all inherited and new exact named outcomes: ' + label)
        require(selected == additions, 'all exact new test names exercised')
        if role in ('runtime', 'worker'):
            label = 'kfd-tests' if role == 'runtime' else 'worker-tests'
            actual = statuses(result['tests'][label])
            old = statuses(previous['tests'][label])
            additions = proposal['new_tests'][role][mode]
            require(actual == old | {name: 'ok' for name in additions}, 'all old and exact new primary outcomes')
            require(result['tests'][label]['passed'] == (
                (1209 if mode == 'diagnostic' else 1180) if role == 'runtime'
                else (911 if mode == 'diagnostic' else 838)), 'exact primary passed census')
        else:
            require(sum(v['passed'] for v in result['tests'].values()) == (641 if mode == 'diagnostic' else 584),
                    'exact selected parent census')
        required_products = {k for k in previous['artifacts'] if
            (k.startswith('worker') if role == 'worker' else not k.startswith('worker') if role == 'runtime' else True)}
        require(set(result['artifacts']) == required_products, 'all original product roles')
    for name, actual in result['artifacts'].items():
        old = previous['artifacts'][name]['cargo_artifact']
        product = actual['cargo_artifact']
        require(product['features'] == old['features'] and product['target']['name'] == old['target']['name']
                and product['target']['kind'] == old['target']['kind'] and product['profile'] == old['profile']
                and product['executable'] == actual['pin']['path']
                and Path(actual['pin']['path']).is_relative_to(root / 'target'), 'original target/features/profile')
        read(Path(actual['pin']['path']), actual['pin'], retain=False)
    for row in result['tool_pins'].values():
        tool(row['path'], row)
    for path, row in result['readset'].items():
        require(path == row['path'], 'original readset path')
        tool(path, row)
    paths = [root / n for n in ('run_cpu.py', 'supervisor.py', 'worker_support.py', 'input-manifest.json',
             'proposal.json', 'base-manifest.json', 'cargo-cache-manifest.json')]
    paths += sorted((root / 'inputs').iterdir())
    require({p.name for p in (root / 'evidence').iterdir()} == set(result['raw']) | {terminal},
            'closed original evidence directory')
    for name, row in result['raw'].items():
        require(row['path'] == str(root / 'evidence' / name), 'original raw path')
        read(Path(row['path']), row, retain=False)
    paths += sorted((root / 'evidence').iterdir())
    bodies = {str(p.relative_to(root)): read(p) for p in paths}
    require(len(bodies) == len(paths) <= 512 and sum(map(len, bodies.values())) <= 96 << 20
            and all(not v.startswith(b'\x7fELF') for v in bodies.values()), 'bounded original nonbinary capsule')
    source_raw = read(Path(__file__).resolve())
    bodies['exporter.py'] = source_raw
    manifest = dict(schema='ferric-layer-phases-cpu-export-v1', role=role, mode=mode, attempt=attempt,
        original_terminal=dict(name=terminal, **pin(raw)), proposal=expected_proposal,
        successful_cpu_qualification=not failed, runtime_tests_repeated=role == 'runtime',
        failure_preserved=failed, gpu_execution=False, native_admission=False,
        numerical_acceptance=False, performance_claim=False,
        originals={n: pin(v) for n, v in sorted(bodies.items())})
    bodies['export-manifest.json'] = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
    out = E / (root.name + '.tar.gz')
    require(not os.path.lexists(out) and shutil.disk_usage(E).free >= 38 << 30, 'fresh output and live floor')
    with out.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as tar:
            for name, body in sorted(bodies.items()):
                member = tarfile.TarInfo(name)
                member.size = len(body); member.mode = 0o600; member.mtime = 0
                tar.addfile(member, io.BytesIO(body))
    for path, expected in list(READS.items()):
        read(Path(path), expected, retain=False)
    for path, expected in list(LINKS.items()):
        tool(path, expected)
    require(shutil.disk_usage(E).free >= 38 << 30, 'final38GiB floor')
    signal.alarm(0)
    print(json.dumps(dict(archive=str(out), **read(out, retain=False), members=len(bodies),
        original_bodies=len(paths), expanded_bytes=sum(map(len, bodies.values())),
        successful_cpu_qualification=not failed), sort_keys=True))


if __name__ == '__main__':
    main()
