"""Stage the reviewed V2 checker beside unchanged V1 and legacy test leaves."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import sys

E = Path("/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220")
D = E / "guarded-mlp-layer-phases-native-source-v228-v1"
OLD = E / "guarded-mlp-readiness40-tail-forward-duration-checker-cpu-v228-v1"
OLD_INPUT_SHA = "ffc3d34d7913433ab83d373b1e36cd5f6f5e5592cb8ab13f79063074df84f2c7"
SUPERVISOR_SHA = "8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc"
NEW = {"validate_layer.py", "test_layer.py", "layer_checker_cpu_template.py"}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def read(path, cap=1 << 20):
    before = path.lstat()
    require(path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_nlink == 1 and before.st_size <= cap, "bounded ordinary source")
    with path.open("rb") as stream:
        raw = stream.read(cap + 1)
        opened = os.fstat(stream.fileno())
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_uid, s.st_gid,
                       s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(stamp(before) == stamp(opened) == stamp(path.lstat())
            and len(raw) == before.st_size, "source changed during read")
    return raw


def names(raw, module):
    found = []
    for node in ast.parse(raw, filename=module).body:
        if isinstance(node, ast.ClassDef):
            found.extend(module + "." + node.name + "." + item.name for item in node.body
                         if isinstance(item, ast.FunctionDef) and item.name.startswith("test_"))
    require(len(found) == len(set(found)), "duplicate test definitions")
    return sorted(found)


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 4
            and re.fullmatch("[0-9a-f]{64}", sys.argv[2])
            and re.fullmatch("[1-9][0-9]?", sys.argv[3]),
            "python3 -B stage_layer_checker.py SEAL_PATH SEAL_SHA ATTEMPT")
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == "smci350-rck-g03-b19-03", "exact unprivileged host")
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10,
            "CPU8/9 nice10")
    require(all(os.environ.get(k) == "" for k in
                ("HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "CUDA_VISIBLE_DEVICES")), "hidden GPUs")
    root = E / ("guarded-mlp-readiness40-tail-layer-duration-checker-cpu-v228-v" + sys.argv[3])
    require(not os.path.lexists(root) and shutil.disk_usage(E).free >= 40 << 30,
            "fresh output and initial storage floor")
    os.umask(0o077)
    for kind, cap in ((resource.RLIMIT_AS, 512 << 20), (resource.RLIMIT_CPU, 120),
                      (resource.RLIMIT_FSIZE, 16 << 20), (resource.RLIMIT_CORE, 0)):
        resource.setrlimit(kind, (cap, cap))
    signal.alarm(180)
    seal_path = Path(sys.argv[1])
    require(seal_path.is_absolute() and seal_path.parent == D, "authoring seal path")
    seal_raw = read(seal_path)
    require(pin(seal_raw)["sha256"] == sys.argv[2], "explicit reviewed seal")
    seal = json.loads(seal_raw)
    require(set(seal) == {"schema", "sources", "leaves"}
            and seal["schema"] == "ferric-layer-checker-source-seal-v1"
            and set(seal["sources"]) == NEW, "closed V2 seal")
    old_raw = read(OLD / "input-manifest.json")
    require(pin(old_raw)["sha256"] == OLD_INPUT_SHA, "qualified146 input ancestry")
    old = json.loads(old_raw)
    require(old["schema"] == "ferric-forward-checker-input-v1"
            and len(old["sources"]) == 28 and set(old["leaves"]) == {"legacy", "forward"},
            "predecessor source and leaf census")
    bodies, readset = {}, {}
    for name, expected in old["sources"].items():
        require(re.fullmatch(r"[A-Za-z0-9_]+\.py", name), "closed predecessor source name")
        raw = read(OLD / name)
        require(pin(raw) == expected, "qualified source: " + name)
        readset[str(OLD / name)] = pin(raw)
        if name != "run_cpu.py":
            bodies[name] = raw
    for name in sorted(NEW):
        raw = read(D / name)
        require(pin(raw) == seal["sources"][name], "reviewed V2 source: " + name)
        bodies["run_cpu.py" if name == "layer_checker_cpu_template.py" else name] = raw
        readset[str(D / name)] = pin(raw)
    require(len(bodies) == 30 and pin(bodies["supervisor.py"])["sha256"] == SUPERVISOR_SHA,
            "closed source packet and original supervisor")
    for name, raw in bodies.items():
        ast.parse(raw, filename=name)
    leaves = dict(old["leaves"])
    leaves["layer"] = dict(modules=["test_layer"], names=names(bodies["test_layer.py"], "test_layer"))
    require(len(leaves["legacy"]["names"]) == 126 and len(leaves["forward"]["names"]) == 20
            and len(leaves["layer"]["names"]) > 0 and leaves == seal["leaves"],
            "reviewed old and new exact test identities")
    for leaf in leaves.values():
        actual = sorted(n for module in leaf["modules"] for n in names(bodies[module + ".py"], module))
        require(actual == leaf["names"] and len(actual) == len(set(actual)), "unchanged test roster")
    combined = [n for leaf in leaves.values() for n in leaf["names"]]
    require(len(combined) == len(set(combined)), "disjoint leaf identities")
    readset[str(OLD / "input-manifest.json")] = pin(old_raw)
    readset[str(seal_path)] = pin(seal_raw)
    self_path = Path(__file__).resolve()
    readset[str(self_path)] = pin(read(self_path))
    spec = dict(schema="ferric-layer-checker-input-v1", root=str(root),
                sources={name: pin(raw) for name, raw in sorted(bodies.items())}, leaves=leaves,
                predecessor_input=dict(path=str(OLD / "input-manifest.json"), **pin(old_raw)),
                source_seal=dict(path=str(seal_path), **pin(seal_raw)), authoring_readset=readset,
                gpu_execution=False)
    input_raw = (json.dumps(spec, sort_keys=True, indent=2) + "\n").encode()
    require(len(input_raw) <= 1 << 20, "bounded staged manifest")
    for path, expected in readset.items():
        require(pin(read(Path(path))) == expected, "input drift before copying")
    root.mkdir(mode=0o700)
    for name, raw in bodies.items():
        with (root / name).open("xb") as stream:
            stream.write(raw)
        require(read(root / name) == raw, "exact source copy")
    with (root / "input-manifest.json").open("xb") as stream:
        stream.write(input_raw)
    require(read(root / "input-manifest.json") == input_raw, "exact manifest copy")
    require(shutil.disk_usage(E).free >= 38 << 30, "final storage floor")
    signal.alarm(0)
    print(json.dumps(dict(root=str(root), input_manifest=pin(input_raw), sources=len(bodies),
                         legacy_tests=146, layer_tests=len(leaves["layer"]["names"])), sort_keys=True))


if __name__ == "__main__":
    main()
