"""Export the fixed layer-stage Rust overlay, preimages and original failed-source lineage."""
import difflib
import hashlib
import io
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import sys
import tarfile

E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
ROOT = E / 'guarded-mlp-layer-phases-source-v228-v2'
OLD = E / 'guarded-mlp-layer-phases-source-v228-v1'
PROPOSAL = dict(bytes=440584, sha256='937393856017d088991e20df697b1b12df449b08a9151e65a968dbdf8603491f')
OLD_PROPOSAL = dict(bytes=441990, sha256='4ef4acd29a254a6b07c069b29eaa17ff21ab1ad28979f9f81c7688136f370823')
REPAIR_PATH = 'fe2o3/crates/fe2o3-kfd/src/engineering_gfx950_peer_scoped_layer_duration_v1_tests.rs'
FIXED = {
    'run_cpu.py': dict(bytes=32526, sha256='6735ed9c959704e58e18c26d86d7a7cb8e33c2654a93a8a5220c6187c316f770'),
    'run_cpu-before-nested-progress-v1.py': dict(bytes=31983, sha256='291a19d8f80dedb22fc8c5315ffecb5eec2f182d010528e355e6231dc299e8b5'),
    'seal_sources.py': dict(bytes=10207, sha256='9b00df3727538684ed2ea4610489b6e9d65d4c24e2add9e85a70649bd3cee243'),
    'seal-v1/format-command.json': dict(bytes=6742, sha256='0013c42e574788812440a4af111dde293084c84bfeef4bf89d4266ec18d94d60'),
    'seal-v1/format-result.json': dict(bytes=451, sha256='b0d25cf236958e37a24f7bba259a5d4e5be7e44a7d8ac972f40da5501e1fd0ae'),
}
FAILURES = {
    'v1': dict(bytes=3003633, sha256='89a95768d36e4dac9fcd61335ba10cd10b0671c4d53584290b4b0ad1c42567d1'),
    'v2': dict(bytes=3003608, sha256='4434ce2f285cd548b5ed16be7261c005657429784b46e22dc129ec87ae7a0a69'),
}
READS = {}


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def pin(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def compact(value):
    return {k: value[k] for k in ('bytes', 'sha256')}


def read(path, expected=None):
    path = Path(path)
    before = path.lstat()
    require(path.is_absolute() and path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
            and before.st_size <= 32 << 20, 'bounded canonical original')
    stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    with path.open('rb') as stream:
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'same opened original')
        raw = stream.read((32 << 20) + 1)
        require(stamp(before) == stamp(os.fstat(stream.fileno())), 'opened original unchanged')
    require(len(raw) == before.st_size and stamp(before) == stamp(path.lstat()), 'original unchanged')
    actual = pin(raw)
    require(expected is None or actual == compact(expected), 'original source pin')
    require(str(path) not in READS or READS[str(path)] == actual, 'source readset drift')
    READS[str(path)] = actual
    return raw


def main():
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 1, 'python3 -B export_source.py only')
    require(os.getuid() == os.geteuid() == 9661 and os.uname().nodename == 'smci350-rck-g03-b19-03',
            'exact unprivileged host')
    require(os.sched_getaffinity(0) == {8, 9} and os.getpriority(os.PRIO_PROCESS, 0) == 10
            and all(os.environ.get(k) == '' for k in ('HIP_VISIBLE_DEVICES', 'ROCR_VISIBLE_DEVICES', 'CUDA_VISIBLE_DEVICES')),
            'CPU8,9 nice10 hidden GPUs')
    require(shutil.disk_usage(ROOT).free >= 40 << 30, 'initial40GiB floor')
    resource.setrlimit(resource.RLIMIT_AS, (512 << 20, 512 << 20))
    resource.setrlimit(resource.RLIMIT_FSIZE, (64 << 20, 64 << 20))
    resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    signal.alarm(90)
    bodies = {}
    def keep(name, path, expected=None):
        require(name not in bodies and not name.startswith('/') and '..' not in Path(name).parts,
                'unique archive-relative body')
        bodies[name] = read(path, expected)
        return bodies[name]
    proposal = json.loads(keep('proposal.json', ROOT / 'proposal.json', PROPOSAL))
    base = json.loads(keep('base-manifest.json', ROOT / 'base-manifest.json', proposal['base_manifest']))
    previous = json.loads(keep('predecessor-proposal.json', ROOT / 'predecessor-proposal.json', proposal['predecessor']))
    failed_source = json.loads(keep('source-predecessor-v1.json', ROOT / 'source-predecessor-v1.json', OLD_PROPOSAL))
    keep('source-review-input-v1.json', ROOT / 'source-review-input-v1.json', proposal['review_input'])
    preformat = json.loads(keep('seal-v1/source-preformat.json', ROOT / 'seal-v1/source-preformat.json',
                              proposal['source_preformat']))
    require(proposal['schema'] == 'ferric-readiness40-layer-phases-source-v1'
            and proposal['runtime_source_changed'] is True
            and all(proposal[k] is False for k in ('compiled', 'tests_executed', 'gpu_execution',
                'native_admission', 'kernel_math_changed', 'currentness_policy_changed',
                'numerical_acceptance', 'performance_claim')), 'source-only seal claims')
    require(len(proposal['files']) == 2138 and len(base['sources']) == 2128
            and len(proposal['overlay']) == 30 and len(previous['files']) == 2132,
            'closed cumulative project and overlay census')
    require(sum(n.startswith('fe2o3/') for n in proposal['files']) == 833
            and sum(n.startswith('ferric/adapters/tp-peer-finite-engineering-worker-v1/')
                    for n in proposal['files']) == 242, 'runtime and worker source census')
    require(set(preformat) == set(proposal['files']), 'complete preformat source map')
    for name, expected in proposal['files'].items():
        require(name.startswith(('fe2o3/', 'ferric/')) and '..' not in Path(name).parts
                and Path(name).as_posix() == name, 'closed source path')
        read(ROOT / name, expected)
    changed = sorted(n for n, p in proposal['files'].items() if n in base['sources']
                     and p != compact(base['sources'][n]))
    changed += sorted(set(proposal['files']) - set(base['sources']))
    require(sorted(changed) == proposal['overlay'], 'only declared cumulative source changes')
    require(set(failed_source['files']) == set(proposal['files'])
            and [n for n in proposal['files'] if proposal['files'][n] != failed_source['files'][n]]
                == [REPAIR_PATH], 'one formatting-sensitive test repair only')
    keep('failed-source-v1/' + REPAIR_PATH, OLD / REPAIR_PATH, failed_source['files'][REPAIR_PATH])
    patches = {'fe2o3': [], 'ferric': []}
    for name in proposal['overlay']:
        require(name.endswith('.rs'), 'Rust-only source publication')
        after = keep(name, ROOT / name, proposal['files'][name])
        before = b''
        if name in base['sources']:
            row = base['sources'][name]
            before = keep('preimages/' + name, Path(row['source']), row)
        repository, relative = name.split('/', 1)
        patches[repository].extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
            fromfile='a/' + relative if before else '/dev/null', tofile='b/' + relative))
    for name, expected in FIXED.items():
        keep(name, ROOT / name, expected)
    result = json.loads(bodies['seal-v1/format-result.json'])
    require(result['exit_code'] == 0 and result['failure'] is None and result['reaped'] is True
            and result['owned_group_absent'] is True and result['spawn_observed'] is True
            and result['timed_out'] is False and result['cleanup_signalled'] is False
            and result['cleanup_errors'] == [] and result['interrupted_signals'] == [], 'original healthy formatting')
    for key in ('stdout', 'stderr'):
        keep('seal-v1/format.' + key, ROOT / ('seal-v1/format.' + key), result[key])
    command = json.loads(bodies['seal-v1/format-command.json'])
    read(Path(command['tool']['path']), command['tool'])
    require(command['affinity'] == [8, 9] and command['nice'] == 10, 'original formatter bounds')
    failed_receipts = {}
    for attempt, expected in FAILURES.items():
        path = E / ('guarded-mlp-layer-phases-runtime-diagnostic-cpu-v228-' + attempt) / 'evidence/failed.json'
        terminal = json.loads(keep('failed-attempts/' + attempt + '/failed.json', path, expected))
        require(terminal['passed'] is False and terminal['failure'] is not None
                and terminal['postcheck_errors'] == [] and terminal['source_unchanged'] is True
                and terminal['runtime_tests_repeated'] is True
                and terminal['proposal'] == (OLD_PROPOSAL if attempt == 'v1' else PROPOSAL),
                'failed attempt lineage receives no qualification credit')
        failed_receipts[attempt] = dict(path=str(path), **expected)
    for name in ('export_cpu.py', 'export_source.py'):
        keep(name, ROOT / name)
    for repository, lines in patches.items():
        bodies[repository + '.patch'] = ''.join(lines).encode()
    require(len(bodies) <= 128 and sum(map(len, bodies.values())) <= 32 << 20
            and all(not raw.startswith(b'\x7fELF') for raw in bodies.values()), 'bounded source-only archive')
    generated = {name: pin(bodies[name]) for name in ('fe2o3.patch', 'ferric.patch')}
    originals = {n: pin(raw) for n, raw in sorted(bodies.items()) if n not in generated}
    manifest = dict(schema='ferric-layer-phases-source-export-v1', proposal=PROPOSAL,
        original_failed_source=OLD_PROPOSAL, failed_attempts=failed_receipts, originals=originals,
        generated_patches=generated, source_changes_authored_on='mi350', overlay_bodies=30,
        runtime_source_bodies=833, worker_source_bodies=242, project_source_bodies=2138,
        cpu_qualification_claim=False, failed_attempts_credited=False, gpu_execution=False,
        native_admission=False, numerical_acceptance=False, performance_claim=False)
    bodies['export-manifest.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    out = E / 'guarded-mlp-layer-phases-source-v228-v2.tar.gz'
    require(not os.path.lexists(out) and shutil.disk_usage(ROOT).free >= 38 << 30, 'fresh archive and live floor')
    with out.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:gz') as tar:
            for name, raw in sorted(bodies.items()):
                member = tarfile.TarInfo(name); member.size = len(raw); member.mode = 0o600; member.mtime = 0
                tar.addfile(member, io.BytesIO(raw))
    for path, expected in list(READS.items()):
        read(Path(path), expected)
    require(shutil.disk_usage(ROOT).free >= 38 << 30, 'final38GiB floor')
    signal.alarm(0)
    print(json.dumps(dict(archive=str(out), **pin(read(out)), members=len(bodies),
        expanded_bytes=sum(map(len, bodies.values()))), sort_keys=True))


if __name__ == '__main__':
    main()
