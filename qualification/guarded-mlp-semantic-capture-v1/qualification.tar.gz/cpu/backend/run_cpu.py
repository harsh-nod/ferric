"""Opt-in paired diagnostic backend qualification with unchanged owned supervision."""

import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import sys
import time
import types


ROOT = Path(__file__).resolve().parent
E = Path('/home/harmenon/ferric-asrock-42/evidence/finite-resident-integration-v220')
EXPECTED_ROOT = E / 'guarded-mlp-semantic-capture-backend-cpu-v228-v1'
SOURCE = ROOT / 'fe2o3'
OUT, TARGET, TMP = (ROOT / name for name in ('evidence', 'target', 'tmp'))
BASE_CPU = E / 'guarded-mlp-memory-bounds-dag-cpu-v228-v1'
BASE_COMPLETE_SHA = 'bd1fa4827483cdf6ca6a0470aacd6826ddab007e8f129611b9725d3e0cdf8445'
BASE_SOURCES_SHA = '37355332ab519512f28ebe58f5d9f55f7c9774f8d14796db2519a5b5168f25ba'
CHANGED_SOURCES = {
    'fe2o3/crates/rustc-codegen-fe2o3/src/production_pipeline.rs',
    'fe2o3/crates/rustc-codegen-fe2o3/src/production_pipeline/diagnostic_semantic_capture_v1.rs',
    'fe2o3/crates/rustc-codegen-fe2o3/src/production_pipeline/diagnostic_semantic_capture_v1_tests.rs',
}
SUPERVISOR_SHA = '8824478a6415dee39d28ccefb0881fc0687ac724f5a9c5a4540310fb5196b9bc'
WHOLE_WALL, LEAF_WALL, CLEANUP_RESERVE = 3600, 1800, 50
PHASES = ('rustc-version', 'metadata', 'compiler-tests-build', 'compiler-list',
          'compiler-ignored', 'capture-tests', 'helper-controls', 'compiler-products')
CAPTURE_PREFIX = 'production_pipeline::diagnostic_semantic_capture_v1::tests::'
NEW_CAPTURE_TESTS = tuple(CAPTURE_PREFIX + name for name in (
    'source_map_capture_absent_failed_or_mismatched_semantic_is_inert',
    'source_map_capture_binds_exact_files_and_both_semantic_identities',
    'source_map_encoding_has_inclusive_byte_and_file_bounds',
    'source_map_publication_failure_keeps_semantic_and_existing_sidecar',
    'source_map_receipt_write_failure_does_not_change_capture_outcome',
))
OLD_CAPTURE_TESTS = tuple(CAPTURE_PREFIX + name for name in (
    'semantic_capture_absent_opt_in_is_inert',
    'semantic_capture_byte_cap_is_inclusive_and_rejects_before_creation',
    'semantic_capture_path_failures_are_bounded_and_do_not_create_parents',
    'semantic_capture_preserves_exact_canonical_bytes_identity_and_admission',
    'semantic_capture_receipt_write_failure_returns_without_panicking',
    'semantic_capture_refuses_overwrite_and_symlink_without_changing_old_bytes',
))
CAPTURE_TESTS = tuple(sorted(OLD_CAPTURE_TESTS + NEW_CAPTURE_TESTS))
HELPER_CONTROLS = tuple('production_ranked_projection_v1::tests::' + name for name in (
    'checked_scalar_helper_rejects_forged_carrier_shapes_and_projections',
    'defined_scalar_helper_admits_only_exact_fabs_compiler_intrinsic',
    'defined_scalar_helper_admits_only_proven_checked_scalar_carriers',
    'defined_scalar_helper_audits_unreachable_effects',
    'defined_scalar_helper_chain_has_an_exact_empty_effect_summary',
    'defined_scalar_helper_rejects_a_hidden_compiler_intrinsic',
    'defined_scalar_helper_rejects_a_transitive_memory_effect',
    'defined_scalar_helper_rejects_missing_function_ids_for_calls_and_tail_calls',
    'defined_scalar_helper_rejects_recursion',
    'defined_zero_sized_helper_requires_recursive_pointer_free_no_effect_body',
    'finite_join_ownership_cannot_hide_in_an_empty_scalar_helper',
    'finite_join_ownership_cannot_hide_in_an_empty_zero_sized_helper',
    'only_exact_deterministic_scalar_helpers_project_call_result_control',
    'wave_storage_ownership_rejects_ordinary_alias_and_empty_helper_shortcuts',
))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def load_exact(name, path, digest):
    require(path.resolve(strict=True) == path and path.is_file() and not path.is_symlink(),
            'helper must be canonical ordinary source')
    before = path.stat()
    require(before.st_size <= 1 << 20, 'helper size bound')
    body = path.read_bytes()
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
            and hashlib.sha256(body).hexdigest() == digest, 'helper source pin mismatch')
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(body, str(path), 'exec'), module.__dict__)
    return module


def compact(rows):
    return {name: {key: row[key] for key in ('bytes', 'sha256')} for name, row in rows.items()}


def selected_compiler(h, path, role, testing):
    rows = h.build_records(path)
    target, kind, filename, source = {
        'test': ('rustc_codegen_fe2o3', 'rlib', None, 'lib.rs'),
        'backend': ('rustc_codegen_fe2o3', 'dylib', '.so', 'lib.rs'),
        'extractor': ('fe2o3-rustc-extract', 'bin', None, 'bin/fe2o3-rustc-extract.rs'),
    }[role]
    artifact = h.select_artifact(rows, 'rustc-codegen-fe2o3', target, kind, testing, filename)
    row = artifact['cargo_artifact']
    kinds = ['bin'] if role == 'extractor' else ['rlib', 'dylib']
    require(row['target']['kind'] == kinds and row['target']['crate_types'] == kinds
            and row['target']['src_path'] == str(SOURCE / 'crates/rustc-codegen-fe2o3/src' / source)
            and row['filenames'].count(artifact['pin']['path']) == 1,
            'closed compiler Cargo target/filename required')
    if not testing:
        final_name = 'librustc_codegen_fe2o3.so' if role == 'backend' else 'fe2o3-rustc-extract'
        require(artifact['pin']['path'] == str(TARGET / 'debug' / final_name),
                'final compiler product path differs')
    return artifact


def main():
    started = time.monotonic()
    deadline = started + WHOLE_WALL
    require(__debug__ and sys.dont_write_bytecode and len(sys.argv) == 2
            and re.fullmatch(r'[0-9a-f]{64}', sys.argv[1]), 'python3 -B run_cpu.py INPUT_SHA')
    require(ROOT == EXPECTED_ROOT and ROOT.resolve(strict=True) == ROOT
            and not any(os.path.lexists(p) for p in (OUT, TARGET, TMP)), 'fresh exact outputs required')
    require(os.getuid() == os.geteuid() == 9661
            and os.uname().nodename == 'smci350-rck-g03-b19-03', 'host/UID mismatch')
    require(shutil.disk_usage(ROOT).free >= 40 << 30, '40 GiB setup floor')
    os.umask(0o077)
    os.sched_setaffinity(0, {8, 9})
    priority = os.getpriority(os.PRIO_PROCESS, 0)
    require(priority in (0, 10), 'unexpected nice level')
    if priority == 0:
        os.nice(10)
    for kind, cap in ((resource.RLIMIT_CORE, 0), (resource.RLIMIT_AS, 12 << 30),
                      (resource.RLIMIT_FSIZE, 1 << 30)):
        soft, hard = resource.getrlimit(kind)
        value = min([cap] + [x for x in (soft, hard) if x != resource.RLIM_INFINITY])
        resource.setrlimit(kind, (value, value))
    require(ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0, 'subreaper setup')
    h = load_exact('backend_owned_supervisor', ROOT / 'supervisor.py', SUPERVISOR_SHA)
    h.ROOT, h.SOURCE, h.OUT, h.TARGET, h.TMP = ROOT, SOURCE, OUT, TARGET, TMP
    h.ROLES = {'compiler-lib': ('rustc-codegen-fe2o3', 'rustc_codegen_fe2o3', 'rlib'),
               'extractor': ('rustc-codegen-fe2o3', 'fe2o3-rustc-extract', 'bin')}
    original_sources = h.sources
    def sources():
        return dict(original_sources(), **{name: h.pin(ROOT / name)
                    for name in ('supervisor.py',)})
    h.sources = sources
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
        signal.signal(sig, h.interrupted)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - CLEANUP_RESERVE - time.monotonic()))
    OUT.mkdir(mode=0o700)
    TMP.mkdir(mode=0o700)
    before = final = input_pin = base_complete_pin = base_source_pin = base_dependencies_pin = config = None
    tool_pins, external, external_after, local, artifacts, tests = {}, {}, {}, {}, {}, {}
    inventory, ignored, phases, errors, failure = [], [], [], [], None
    source_delta = {}
    try:
        input_pin = h.pin(ROOT / 'input-manifest.json')
        require(input_pin['sha256'] == sys.argv[1], 'literal input mismatch')
        inputs = json.loads((ROOT / 'input-manifest.json').read_bytes())
        require(set(inputs) == {'schema', 'base_complete_sha256', 'files', 'tool_pins'}
                and inputs['schema'] == 'ferric-guarded-mlp-semantic-capture-backend-cpu-input-v1'
                and inputs['base_complete_sha256'] == BASE_COMPLETE_SHA, 'input lineage/fields')
        before = sources()
        require(len(before) == 5810 and inputs['files'] == compact(before), 'closed exact source map')
        h.save('sources-before.json', before)
        base_complete_pin = h.pin(BASE_CPU / 'evidence/complete.json')
        base_source_pin = h.pin(BASE_CPU / 'evidence/sources-after.json')
        require(base_complete_pin['sha256'] == BASE_COMPLETE_SHA
                and base_source_pin['sha256'] == BASE_SOURCES_SHA, 'actual base CPU/source pins')
        base = json.loads((BASE_CPU / 'evidence/complete.json').read_bytes())
        base_sources = json.loads((BASE_CPU / 'evidence/sources-after.json').read_bytes())
        require(base['passed'] is True and base['failure'] is None and base['postcheck_errors'] == []
                and base['source_unchanged'] is True
                and base['raw']['sources-after.json'] == base_source_pin,
                'actual source-generation receipt join')
        expected = {name: row for name, row in base_sources.items() if name.startswith('fe2o3/')}
        actual = {name: row for name, row in before.items() if name.startswith('fe2o3/')}
        require(len(expected) == 5808 and set(expected) == set(actual),
                'fresh workspace roster differs from qualified backend')
        source_delta = {name: dict(before=compact(expected)[name], after=compact(actual)[name])
                        for name in expected if compact({name: expected[name]})
                        != compact({name: actual[name]})}
        require(set(source_delta) == CHANGED_SOURCES,
                'only three explicit backend diagnostic files may differ')
        base_dependencies_pin = h.pin(BASE_CPU / 'evidence/dependencies-after.json')
        require(base['raw']['dependencies-after.json'] == base_dependencies_pin,
                'actual base dependency receipt join')
        base_dependencies = json.loads((BASE_CPU / 'evidence/dependencies-after.json').read_bytes())
        config = h.configurations()
        tool_pins = {name: h.pin(h.TOOLCHAIN / name) for name in ('rustc', 'rustdoc', 'rustfmt', 'cargo')}
        tool_pins['prlimit'] = h.pin(Path('/usr/bin/prlimit'))
        for name, size in h.SHARED_LIBRARIES.items():
            path = h.TOOLCHAIN_LIB / name
            require(path.resolve(strict=True) == path, 'tool library alias')
            tool_pins[name] = h.pin(path)
            require(tool_pins[name]['bytes'] == size, 'tool library extent')
        require(tool_pins == inputs['tool_pins'] == base['tool_pins'], 'exact qualified tool pins')
        env = dict(HOME='/home/harmenon', PATH=str(h.TOOLCHAIN) + ':/usr/bin:/bin',
                   CARGO_HOME='/home/harmenon/.cargo', CARGO_TARGET_DIR=str(TARGET),
                   LD_LIBRARY_PATH=str(TARGET / 'debug/deps') + ':' + str(h.TOOLCHAIN_LIB),
                   TMPDIR=str(TMP), RUSTC=str(h.TOOLCHAIN / 'rustc'), RUSTDOC=str(h.TOOLCHAIN / 'rustdoc'),
                   CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
                   CARGO_CACHE_AUTO_CLEAN_FREQUENCY='never', MALLOC_ARENA_MAX='2', RUST_BACKTRACE='1',
                   CARGO_PROFILE_DEV_OPT_LEVEL='0', CARGO_PROFILE_DEV_DEBUG='0',
                   CARGO_PROFILE_DEV_DEBUG_ASSERTIONS='true', CARGO_PROFILE_DEV_OVERFLOW_CHECKS='true',
                   CARGO_PROFILE_TEST_OPT_LEVEL='0', CARGO_PROFILE_TEST_DEBUG='0',
                   CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true', CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
                   ROCR_VISIBLE_DEVICES='', HIP_VISIBLE_DEVICES='', CUDA_VISIBLE_DEVICES='')
        def leaf(label, argv, seconds=LEAF_WALL, package=False):
            cwd = SOURCE / 'crates/rustc-codegen-fe2o3' if package else ROOT
            selected_env = dict(env)
            if package:
                selected_env['CARGO_MANIFEST_DIR'] = str(cwd)
            h.run(label, argv, selected_env, phases, deadline, before, seconds, cwd)
        cargo = str(h.TOOLCHAIN / 'cargo')
        common = ['--offline', '--locked', '--manifest-path', str(SOURCE / 'Cargo.toml')]
        leaf('rustc-version', [str(h.TOOLCHAIN / 'rustc'), '--version', '--verbose'], 60)
        leaf('metadata', [cargo, 'metadata', *common, '--format-version', '1'], 120)
        external, local = h.metadata_contract()
        require(external == base_dependencies, 'dependency bodies differ from qualified backend')
        h.save('dependencies-before.json', external)
        leaf('compiler-tests-build', [cargo, 'test', *common, '--jobs', '2', '-p', 'rustc-codegen-fe2o3',
                                     '--lib', '--no-run', '--message-format=json'])
        artifacts['test'] = selected_compiler(h, OUT / 'compiler-tests-build.stdout', 'test', True)
        executable = artifacts['test']['pin']['path']
        leaf('compiler-list', [executable, '--list', '--format=terse'], 120, True)
        leaf('compiler-ignored', [executable, '--ignored', '--list', '--format=terse'], 120, True)
        inventory = h.inventory(OUT / 'compiler-list.stdout')
        ignored = h.inventory(OUT / 'compiler-ignored.stdout')
        require(len(inventory) == 1352
                and inventory == sorted(base['test_inventories']['compiler-lib'] + list(NEW_CAPTURE_TESTS))
                and ignored == base['ignored_inventories']['compiler-lib']
                and [name for name in inventory if name.startswith(CAPTURE_PREFIX)] == list(CAPTURE_TESTS),
                'compiled full/ignored/capture inventory mismatch')
        require(set(HELPER_CONTROLS) <= set(inventory)
                and not (set(CAPTURE_TESTS) | set(HELPER_CONTROLS)) & set(ignored),
                'focused controls must be present and nonignored')
        leaf('capture-tests', [executable, CAPTURE_PREFIX, '--test-threads=1'], package=True)
        tests['capture'] = h.outcomes(OUT / 'capture-tests.stdout', CAPTURE_TESTS, len(inventory))
        leaf('helper-controls', [executable, '--exact', *HELPER_CONTROLS, '--test-threads=1'], package=True)
        tests['helper-controls'] = h.outcomes(OUT / 'helper-controls.stdout', HELPER_CONTROLS, len(inventory))
        leaf('compiler-products', [cargo, 'build', *common, '--jobs', '2', '-p', 'rustc-codegen-fe2o3',
                                  '--lib', '--bin', 'fe2o3-rustc-extract', '--message-format=json'])
        for role in ('backend', 'extractor'):
            artifacts[role] = selected_compiler(h, OUT / 'compiler-products.stdout', role, False)
        require([row['label'] for row in phases] == list(PHASES), 'closed eight phases')
    except BaseException as error:
        failure = repr(error)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    def check(label, action):
        try:
            remaining = deadline - 5 - time.monotonic()
            require(remaining > 0, 'postcheck deadline')
            signal.setitimer(signal.ITIMER_REAL, remaining)
            action()
        except BaseException as error:
            errors.append(label + ': ' + repr(error))
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
    def source_check():
        nonlocal final
        final = sources()
        h.save('sources-after.json', final)
        require(final == before, 'source/lock mutation')
    check('sources', source_check)
    if input_pin is not None:
        check('input', lambda: require(h.pin(ROOT / 'input-manifest.json') == input_pin, 'input drift'))
    if config is not None:
        check('configuration', lambda: require(h.configurations() == config, 'configuration drift'))
    for label, expected in tool_pins.items():
        check('tool ' + label, lambda expected=expected: require(h.pin(Path(expected['path'])) == expected, 'tool drift'))
    for label, expected in [('base complete', base_complete_pin), ('base sources', base_source_pin),
                            ('base dependencies', base_dependencies_pin)]:
        if expected is not None:
            check(label, lambda expected=expected: require(h.pin(Path(expected['path'])) == expected, 'base drift'))
    for directory, expected in external.items():
        def dependency_check(directory=directory, expected=expected):
            path = Path(directory)
            actual = {str(p.relative_to(path)): h.pin(p) for p in h.files_below(path, packed=False)}
            external_after[directory] = actual
            require(actual == expected, 'external dependency drift')
        check('dependency ' + directory, dependency_check)
    check('dependency ledger', lambda: h.save('dependencies-after.json', external_after))
    for label, artifact in artifacts.items():
        check('artifact ' + label, lambda artifact=artifact: require(
            h.pin(Path(artifact['pin']['path'])) == artifact['pin'], 'selected artifact drift'))
    raw = {}
    def raw_check():
        nonlocal raw
        raw = {p.name: h.pin(p) for p in sorted(OUT.iterdir()) if p.is_file()}
        for row in phases:
            for key in ('command', 'stdout', 'stderr'):
                require(raw[Path(row[key]['path']).name] == row[key], 'raw phase join')
    check('raw evidence', raw_check)
    failure = failure or ('postcheck failed' if errors else None)
    if time.monotonic() >= deadline:
        failure = failure or 'whole deadline exceeded'
    result = dict(schema='ferric-guarded-mlp-semantic-capture-backend-cpu-v1', passed=failure is None,
                  failure=failure, postcheck_errors=errors,
                  source_delta=source_delta, diagnostic_default_enabled=False,
                  admission_changed=False, semantic_predicates_changed=False,
                  controller=h.pin(ROOT / 'run_cpu.py'), supervisor=h.pin(ROOT / 'supervisor.py'),
                  input_manifest=input_pin,
                  base_cpu_complete=base_complete_pin, base_cpu_sources=base_source_pin,
                  base_cpu_dependencies=base_dependencies_pin,
                  input_sources=before, final_sources=final, source_unchanged=before is not None and final == before,
                  phases=phases, artifacts=artifacts, tests=tests, inventory=inventory, ignored=ignored,
                  capture_tests=list(CAPTURE_TESTS), helper_controls=sorted(HELPER_CONTROLS),
                  full_compiler_tests_executed=False, tool_pins=tool_pins, raw=raw,
                  local_dependencies=local, configurations=config, elapsed_seconds=time.monotonic() - started,
                  final_artifact_phase='compiler-products', test_artifact_phase='compiler-tests-build',
                  limits=dict(whole_seconds=WHOLE_WALL, leaf_seconds=LEAF_WALL,
                              cleanup_reserve_seconds=CLEANUP_RESERVE, cpu_seconds=h.CPU_LIMIT,
                              address_space_bytes=h.AS_LIMIT, file_bytes=h.FILE_LIMIT,
                              cache_bytes=h.CACHE_LIMIT, stream_bytes=h.STREAM_LIMIT,
                              initial_free_bytes=h.START_FREE, live_free_bytes=h.LIVE_FREE,
                              affinity=[8, 9], nice=10, cargo_jobs=2),
                  gpu_execution=False, compiler_hsaco_reproduced=False, production_authority=False)
    signal.setitimer(signal.ITIMER_REAL, max(0.001, deadline - time.monotonic()))
    try:
        h.save('complete.json' if failure is None else 'failed.json', result)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    print(json.dumps(dict(passed=failure is None, failure=failure, phases=len(phases),
                          tests={k: {n: v[n] for n in ('passed', 'failed', 'ignored')}
                                 for k, v in tests.items()}, output=str(OUT)), sort_keys=True))
    return 0 if failure is None else 1


if __name__ == '__main__':
    raise SystemExit(main())
