"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-memory-bounds-dag-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-semantic-capture-backend-cpu-v228-v1'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == 'bd1fa4827483cdf6ca6a0470aacd6826ddab007e8f129611b9725d3e0cdf8445'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / 'run_cpu.py', ROOT / 'supervisor.py']
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5810
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
value = dict(schema='ferric-guarded-mlp-semantic-capture-backend-cpu-input-v1',
             base_complete_sha256=hashlib.sha256(body).hexdigest(),
             files=files, tool_pins=receipt['tool_pins'])
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
