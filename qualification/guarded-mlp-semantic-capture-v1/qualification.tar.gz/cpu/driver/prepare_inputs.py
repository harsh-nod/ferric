"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-inline-hint-driver-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-semantic-capture-driver-cpu-v228-v1'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == '237f3742f47464641584c65bf63526adf18ab0983d90ea2ee8526e8479c4c212'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / 'run_cpu.py', ROOT / 'supervisor.py']
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5299
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
value = dict(schema='ferric-guarded-mlp-semantic-capture-driver-cpu-input-v1',
             source_generation=receipt['source_generation'],
             files=files, tool_pins=receipt['tool_pins'])
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
