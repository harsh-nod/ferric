use super::*;
use fe2o3_mir_model::semantic_mir_v1::*;
use std::path::PathBuf;

struct CaptureScratch(PathBuf);

impl CaptureScratch {
    fn new() -> Self {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "fe2o3-semantic-capture-{}-{nonce}",
            std::process::id(),
        ));
        std::fs::create_dir(&path).unwrap();
        Self(path)
    }
}

impl Drop for CaptureScratch {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

fn admitted_capture_fixture() -> AdmittedInertSemanticMirV1 {
    // The canonical decoder's minimal request recipe, admitted through the
    // current production schema. This is not rustc-source or launch evidence.
    let ty = SemanticTypeIdV1::from_index(0);
    let source = SemanticSourceProvenanceV1::unavailable();
    let declaration = SemanticTypeDeclV1::new(
        SemanticTypeIdentityV1::from_sha256([1; 32]),
        SemanticLayoutIdentityV1::from_sha256([2; 32]),
        SemanticTypeLayoutV1::new_with_backend_repr(
            Some(4),
            4,
            SemanticBackendReprV1::scalar(SemanticBackendScalarV1::initialized(
                SemanticBackendPrimitiveV1::integer(false, 32, 4),
                SemanticScalarValidityRangeV1::new(0, u128::from(u32::MAX)),
            )),
            false,
        )
        .unwrap(),
        SemanticTypeShapeV1::Scalar(SemanticScalarTypeV1::Integer {
            signed: false,
            bits: 32,
        }),
    );
    let mode = SemanticAbiPassModeV1::Direct(
        SemanticAbiValueAttributesV1::new(
            SemanticAbiRegularAttributesV1::new(false, None, false, false, false, true),
            SemanticAbiExtensionV1::None,
            0,
            None,
        )
        .unwrap(),
    );
    let abi = SemanticFunctionAbiV1::new(
        SemanticAbiIdentityV1::from_sha256([3; 32]),
        SemanticLayoutIdentityV1::from_sha256([4; 32]),
        SemanticCanonAbiV1::Rust,
        false,
        false,
        vec![SemanticAbiValueV1::new(ty, mode.clone())],
        SemanticAbiValueV1::new(ty, mode),
    )
    .unwrap();
    let locals = [
        SemanticLocalRoleV1::Return,
        SemanticLocalRoleV1::Argument(0),
    ]
    .into_iter()
    .enumerate()
    .map(|(index, role)| {
        SemanticLocalDeclV1::new(
            SemanticLocalIdentityV1::from_sha256([5 + index as u8; 32]),
            ty,
            role,
            source,
        )
    })
    .collect();
    let block = SemanticBasicBlockV1::new(
        SemanticBlockIdentityV1::from_sha256([7; 32]),
        source,
        vec![],
        SemanticTerminatorV1::new(source, SemanticTerminatorKindV1::Return),
    )
    .unwrap();
    let function = SemanticFunctionDeclV1::new(
        SemanticFunctionIdentityV1::from_sha256([8; 32]),
        SemanticFunctionRoleV1::KernelRoot,
        SemanticItemDefinitionIdentityV1::from_sha256([9; 32]),
        SemanticMonomorphizationIdentityV1::from_sha256([10; 32]),
        SemanticGenericTypeArgumentsIdentityV1::from_sha256([11; 32]),
        SemanticConstGenericArgumentsIdentityV1::from_sha256([12; 32]),
        source,
        abi,
        locals,
        SemanticBlockIdV1::from_index(0),
        vec![block],
    )
    .unwrap();
    InertSemanticMirRequestV1::new(
        SemanticTargetDataLayoutV1::gfx942(SemanticLayoutIdentityV1::from_sha256([13; 32])),
        vec![declaration],
        vec![],
        vec![],
        vec![],
        vec![function],
        vec![SemanticFunctionIdV1::from_index(0)],
    )
    .unwrap()
    .admit_current_production(SemanticMirLimitsV1::default())
    .unwrap()
}

#[test]
fn semantic_capture_absent_opt_in_is_inert() {
    let scratch = CaptureScratch::new();
    let semantic = admitted_capture_fixture();
    let bytes = semantic.canonical_encoding().as_ptr();
    let identity = *semantic.semantic_sha256().as_bytes();
    assert!(capture_requested_semantic_v1(None, &semantic).is_none());
    assert_eq!(semantic.canonical_encoding().as_ptr(), bytes);
    assert_eq!(semantic.semantic_sha256().as_bytes(), &identity);
    assert_eq!(std::fs::read_dir(&scratch.0).unwrap().count(), 0);
}

#[test]
fn semantic_capture_preserves_exact_canonical_bytes_identity_and_admission() {
    let scratch = CaptureScratch::new();
    let path = scratch.0.join("semantic.mir");
    let semantic = admitted_capture_fixture();
    let bytes = semantic.canonical_encoding().as_ptr();
    let outcome = capture_requested_semantic_v1(Some(&path), &semantic).unwrap();
    assert_eq!(outcome.result, Ok(()));
    assert_eq!(outcome.bytes, semantic.canonical_encoding().len());
    assert_eq!(
        outcome.semantic_sha256,
        *semantic.semantic_sha256().as_bytes()
    );
    assert_eq!(semantic.canonical_encoding().as_ptr(), bytes);
    let captured = std::fs::read(&path).unwrap();
    assert_eq!(captured, semantic.canonical_encoding());
    let replay = AdmittedInertSemanticMirV1::decode_current_production_canonical(
        &captured,
        SemanticMirLimitsV1::default(),
    )
    .unwrap();
    assert_eq!(replay.canonical_encoding(), semantic.canonical_encoding());
    assert_eq!(replay.semantic_sha256(), semantic.semantic_sha256());
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt as _;
        assert_eq!(
            std::fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o600
        );
    }
    let mut receipt = Vec::new();
    write_capture_receipt_v1(&mut receipt, &outcome).unwrap();
    assert_eq!(
        String::from_utf8(receipt).unwrap(),
        format!(
            "fe2o3 diagnostic semantic MIR: stage=pre-ranked status=complete bytes={} semantic_sha256={} error_kind=None\n",
            captured.len(),
            crate::encode_hex(semantic.semantic_sha256().as_bytes()),
        ),
    );
}

#[test]
fn semantic_capture_byte_cap_is_inclusive_and_rejects_before_creation() {
    let scratch = CaptureScratch::new();
    // Short arbitrary bytes test only publication bounds, not MIR admission.
    let bytes = b"bounded bytes";
    let exact = scratch.0.join("exact");
    write_new_capture_bytes_v1(&exact, bytes, bytes.len()).unwrap();
    assert_eq!(std::fs::read(&exact).unwrap(), bytes);
    let over = scratch.0.join("over");
    assert_eq!(
        write_new_capture_bytes_v1(&over, bytes, bytes.len() - 1)
            .unwrap_err()
            .kind(),
        io::ErrorKind::InvalidInput,
    );
    assert!(!over.exists());
    let empty = scratch.0.join("empty");
    assert_eq!(
        write_new_capture_bytes_v1(&empty, b"", bytes.len())
            .unwrap_err()
            .kind(),
        io::ErrorKind::InvalidInput,
    );
    assert!(!empty.exists());
}

#[test]
fn semantic_capture_refuses_overwrite_and_symlink_without_changing_old_bytes() {
    let scratch = CaptureScratch::new();
    let path = scratch.0.join("existing");
    write_new_capture_bytes_v1(&path, b"original", 8).unwrap();
    assert_eq!(
        write_new_capture_bytes_v1(&path, b"replaced", 8)
            .unwrap_err()
            .kind(),
        io::ErrorKind::AlreadyExists,
    );
    assert_eq!(std::fs::read(&path).unwrap(), b"original");
    #[cfg(unix)]
    {
        let link = scratch.0.join("link");
        std::os::unix::fs::symlink(&path, &link).unwrap();
        assert_eq!(
            write_new_capture_bytes_v1(&link, b"replaced", 8)
                .unwrap_err()
                .kind(),
            io::ErrorKind::AlreadyExists,
        );
        assert_eq!(std::fs::read(&path).unwrap(), b"original");
    }
}

#[test]
fn semantic_capture_path_failures_are_bounded_and_do_not_create_parents() {
    assert_eq!(
        write_new_capture_bytes_v1(Path::new("relative/semantic.mir"), b"bytes", 5)
            .unwrap_err()
            .kind(),
        io::ErrorKind::InvalidInput,
    );
    let scratch = CaptureScratch::new();
    let parent = scratch.0.join("missing");
    let path = parent.join("untrusted-path\nmust-not-appear.mir");
    let semantic = admitted_capture_fixture();
    let outcome = capture_requested_semantic_v1(Some(&path), &semantic).unwrap();
    assert_eq!(outcome.result, Err(io::ErrorKind::NotFound));
    assert!(!parent.exists());
    let mut receipt = Vec::new();
    write_capture_receipt_v1(&mut receipt, &outcome).unwrap();
    let receipt = String::from_utf8(receipt).unwrap();
    assert_eq!(
        receipt,
        format!(
            "fe2o3 diagnostic semantic MIR: stage=pre-ranked status=failed bytes={} semantic_sha256={} error_kind=Some(NotFound)\n",
            semantic.canonical_encoding().len(),
            crate::encode_hex(semantic.semantic_sha256().as_bytes()),
        ),
    );
    assert_eq!(receipt.lines().count(), 1);
    assert!(receipt.len() < 256);
    assert!(!receipt.contains("untrusted-path"));
}

#[test]
fn semantic_capture_receipt_write_failure_returns_without_panicking() {
    struct UnavailableOutput;
    impl Write for UnavailableOutput {
        fn write(&mut self, _: &[u8]) -> io::Result<usize> {
            Err(io::ErrorKind::BrokenPipe.into())
        }
        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }
    let outcome = SemanticCaptureOutcomeV1 {
        bytes: 1,
        semantic_sha256: [7; 32],
        result: Err(io::ErrorKind::PermissionDenied),
    };
    assert_eq!(
        write_capture_receipt_v1(&mut UnavailableOutput, &outcome)
            .unwrap_err()
            .kind(),
        io::ErrorKind::BrokenPipe,
    );
}
