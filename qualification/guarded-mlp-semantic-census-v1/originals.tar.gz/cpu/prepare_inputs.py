"""Generate a closed input manifest; no build or GPU execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'guarded-mlp-semantic-call-inspect-cpu-v228-v1'
assert ROOT.name == 'guarded-mlp-semantic-call-census-cpu-v228-v2'
assert not (ROOT / 'input-manifest.json').exists()
body = (BASE / 'evidence/complete.json').read_bytes()
assert hashlib.sha256(body).hexdigest() == '862acab9993408c8303ba047219b2fca5c2c8a4d9c940807b22569b8f3257a7b'
receipt = json.loads(body)
assert receipt['passed'] and receipt['postcheck_errors'] == []
paths = [ROOT / 'run_cpu.py', ROOT / 'supervisor.py', ROOT / 'prepare_inputs.py']
paths += sorted(p for p in (ROOT / 'fe2o3').rglob('*') if p.is_file())
assert len(paths) == 5812
files = {}
for p in paths:
    assert p.resolve(strict=True) == p and not p.is_symlink()
    data = p.read_bytes()
    files[str(p.relative_to(ROOT))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
E = ROOT.parent
PAIR = E / 'guarded-mlp-early-stop-compile-v228-v8'
CAPTURE_FILES = {
    'captures/fixed/result.json': (PAIR / 'fixed-run/evidence/result.json', '91192072e44394fc8e808936572bdc5b3b37092aae37632365436f99caade77d'),
    'captures/fixed/compile.stderr': (PAIR / 'fixed-run/evidence/compile.stderr', 'ff1e3d1ad6117129e3acad5c2f7e6b32c52ea7af01df2da719d40f8559a2d2d7'),
    'captures/fixed/semantic-mir-v1.bin': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '72dfdc23aabf0eaac4f2809371131a853874f51609bf1e380476ce95eb0a1667'),
    'captures/fixed/semantic-source-map-v1.json': (PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '1c33e74ee9d15837276a82b687d40aa065957cc645df49b746f0c4cc379ef5a5'),
    'captures/early/result.json': (PAIR / 'early-run/evidence/result.json', '5206dc0347e1093ea04a983a73bb763bbf70def98ed9fd8e31fb75dbee693ceb'),
    'captures/early/compile.stderr': (PAIR / 'early-run/evidence/compile.stderr', '3942d375c48f1f8c05a1f321283b5058c01144c54b91a5b0ae776f48a00c7580'),
    'captures/early/semantic-mir-v1.bin': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'e29daedb54bb4428533a48a9342e1a1964ab3756b95fd875537fcb5803597f69'),
    'captures/early/semantic-source-map-v1.json': (PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '57d9ee61bc355f3debfb3c4828b87bfef487c04325b2af95db11e989f38fbc6e'),
}
HELPER = '00b15eaa5a80fc7f25e19c1c333fcde91f768f51097ae1c2c4f27ced27c66af0'
CALL_PAIR = E / 'guarded-mlp-early-stop-compile-v228-v12'
CALL_CAPTURE_FILES = {
    'call-captures/fixed/result.json': (CALL_PAIR / 'fixed-run/evidence/result.json', '8eeda87c5e60b46c2473ce59caacabe50ce5834b2020696f93a305d50094d9df'),
    'call-captures/fixed/compile.stderr': (CALL_PAIR / 'fixed-run/evidence/compile.stderr', 'f1320124bd68f601e42265128d6b0712805f6a72a82b9578d95137db61bc7f36'),
    'call-captures/fixed/semantic-mir-v1.bin': (CALL_PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'dfb4b64f370def38bd02042298476ec71ee56a53976000ddcb8e8ab5b6047723'),
    'call-captures/fixed/semantic-source-map-v1.json': (CALL_PAIR / 'fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '9a65300626378c82b5140139ea42625ad13fe9415926abc98a7432600000b663'),
    'call-captures/early/result.json': (CALL_PAIR / 'early-run/evidence/result.json', '747d0f1e63ccf9cae6769260da1112878e8255407f5f1f8ddb5d36fad86ecb21'),
    'call-captures/early/compile.stderr': (CALL_PAIR / 'early-run/evidence/compile.stderr', '1f58fd02cf60d0514ed63873d83532c5aff44855789e7f9be0af829cfccdded4'),
    'call-captures/early/semantic-mir-v1.bin': (CALL_PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '9dc891d206ed5317606b266706f20d2a161d16855b60227501eb88b962be7195'),
    'call-captures/early/semantic-source-map-v1.json': (CALL_PAIR / 'early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', 'f670805114318453baf51ef83d425009f0a1ab9c64d8f47268d3a5a059f97807'),
}
CAPTURE_FILES.update(CALL_CAPTURE_FILES)

CENSUS_CAPTURE_FILES = {
    'census-captures/v16/fixed/result.json': (E / 'guarded-mlp-early-stop-compile-v228-v16/fixed-run/evidence/result.json', 'fbb19a79bc1ffeb4bc655be38bc75d2ed04cbf0d74f30e56a1d808266dfa68d5'),
    'census-captures/v16/fixed/compile.stderr': (E / 'guarded-mlp-early-stop-compile-v228-v16/fixed-run/evidence/compile.stderr', '200710acdc31d1a9fd64ee78300c63901e8405c2a4ee68d7972fc4492405594e'),
    'census-captures/v16/fixed/semantic-mir-v1.bin': (E / 'guarded-mlp-early-stop-compile-v228-v16/fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '480fc64ba82d722350be7317a39c9fa3256cad56497963f23e76bf9a101afbd9'),
    'census-captures/v16/fixed/semantic-source-map-v1.json': (E / 'guarded-mlp-early-stop-compile-v228-v16/fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', 'af0ffa5d338a8f7dba186dcb865ec642f4971feb1810e20bbdaf7a66912c3e17'),
    'census-captures/v16/early/result.json': (E / 'guarded-mlp-early-stop-compile-v228-v16/early-run/evidence/result.json', '8a0e6d0e6c5f6291db35aa7b8e1b47f3ad439d15c92732961eaa1320b662db41'),
    'census-captures/v16/early/compile.stderr': (E / 'guarded-mlp-early-stop-compile-v228-v16/early-run/evidence/compile.stderr', 'a8be78ecbcb24cb966f50b7142a5818bde6192fdda82f3e5c54bb8ea15a35f83'),
    'census-captures/v16/early/semantic-mir-v1.bin': (E / 'guarded-mlp-early-stop-compile-v228-v16/early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', 'b3d1bcc64ee742b1629bfcce6758053be39c2594aeecfa61146ee1f872ba09be'),
    'census-captures/v16/early/semantic-source-map-v1.json': (E / 'guarded-mlp-early-stop-compile-v228-v16/early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', 'a59bee36eddac7cf2f36eb86ec94d97d4a8bb20456972079c2fa32b5d3ce7c89'),
    'census-captures/v17/fixed/result.json': (E / 'guarded-mlp-early-stop-compile-v228-v17/fixed-run/evidence/result.json', '3bfb5217df9af267686e81928d4f2c880acc13549e4d576ab0d11561f6805325'),
    'census-captures/v17/fixed/compile.stderr': (E / 'guarded-mlp-early-stop-compile-v228-v17/fixed-run/evidence/compile.stderr', '5c751c193441263c4626a3b7277f50348d1b2c035a462a1bc65bc28479bc5914'),
    'census-captures/v17/fixed/semantic-mir-v1.bin': (E / 'guarded-mlp-early-stop-compile-v228-v17/fixed-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '00bd3acfa96ad8dba9ef18c14b68f38419404288f43415a0c59c83ae1e339ca2'),
    'census-captures/v17/fixed/semantic-source-map-v1.json': (E / 'guarded-mlp-early-stop-compile-v228-v17/fixed-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '2a49d3b463d311ac2bb73713abe71bbd4d70fd94012d92856b1e4cb2ac663066'),
    'census-captures/v17/early/result.json': (E / 'guarded-mlp-early-stop-compile-v228-v17/early-run/evidence/result.json', 'a7ed70c4a3e4cc0af2b723dec128a33e620f9f7dfe250427028ec499fc96457e'),
    'census-captures/v17/early/compile.stderr': (E / 'guarded-mlp-early-stop-compile-v228-v17/early-run/evidence/compile.stderr', 'ed6774a0ec9c9de0ba07b2fb7100ef3808842df4f799bff175a9f6b7b68e5c3c'),
    'census-captures/v17/early/semantic-mir-v1.bin': (E / 'guarded-mlp-early-stop-compile-v228-v17/early-run/fe2o3-engineering-diagnostics-v1/semantic-mir-v1.bin', '50049cd27e6f5be0a69b3c0def9e2a6508a4a99633935dbe910adb7083b826ea'),
    'census-captures/v17/early/semantic-source-map-v1.json': (E / 'guarded-mlp-early-stop-compile-v228-v17/early-run/fe2o3-engineering-diagnostics-v1/semantic-source-map-v1.json', '6d7ccd35cfd03ea148a5ff411ce46705af7d852f872ac2adef413ccd0724983e'),
}
CAPTURE_FILES.update(CENSUS_CAPTURE_FILES)

for name, (path, digest) in CAPTURE_FILES.items():
    assert path.resolve(strict=True) == path and not path.is_symlink()
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == digest
    files[name] = dict(bytes=len(raw), sha256=digest)
assert len(files) == 5844
value = dict(schema='ferric-guarded-mlp-semantic-call-census-cpu-input-v1',
             base_complete_sha256=hashlib.sha256(body).hexdigest(),
             files=files, tool_pins=receipt['tool_pins'])
data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
with (ROOT / 'input-manifest.json').open('xb') as f:
    f.write(data)
print(json.dumps(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
